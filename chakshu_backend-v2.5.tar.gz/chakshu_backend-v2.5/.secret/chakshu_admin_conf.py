#!/usr/bin/python

#
# This is C-Chakshu configuration file to be filled by Administrator.   
#


## Name and Peak Performance of the cluster
CLUSTER_NAME = 'PARAM Clustername'
RPEAK = '0.0 PF'

## Partition details
HOME_PARTITION_NAME = '/home'
SCRATCH_PARTITION_NAME = '/scratch'


NO_OF_RACKS = 0
TOTAL_NODES = 0
# compute node details 
CPU_NODES = 0
CPU_SERIES_CODE = 'Skylake'
CPU_CORES = 0
# gpu node details
GPU_NODES = 0
GPU_SERIES_CODE = 'Tesla'
GPU_CORES =  0
# high memory node details
HM_NODES = 0
HM_CPU_SERIES_CODE = 'NA'
HM_CPU_CORES =  0


## Mention node ranges (seperated by comma if necessary )
CN_NODELIST = '001-100'
GPU_NODELIST = '001-100'
HM_NODELIST =  '001-100'


# Slave nodes Network IDs
CN_NETID = "10.1.40"
GPU_NETID = "10.1.45"
HM_NETID = "10.1.42"
# IPMI Network IDs
CN_IPMI_NETID = '10.6.140'
GPU_IPMI_NETID = '10.6.145'
HM_IPMI_NETID = '10.6.142'

# IPMI Credentials
__IPMI_USERNAME = 'ADMIN'
__IPMI_PASSWORD = 'ADMIN'



## Scheduler and resource manager details(slurm, pbspro, torque, etc.)
# Example, slurm_acct_db
# Example, if table name is linux_job_table prefix will be linux 
SCHEDULER =   'slurm'
SCHEDULER_DB_NAME =  'slurm_acct_db'
DB_TABLE_PREFIX = 'NA'
__DB_USERNAME = 'NA'
__DB_PASSWORD = 'NA'
DB_SERVER = 'NA'

# osTicketing database details
OST_DB_NAME = 'ost'
OST_DB_USER = 'ostuser'
OST_DB_PASSWORD = 'password'
OST_DB_SERVER = '172.10.2.1'



# LDAP Details
LDAP_SERVER = 'ldap://172.10.1.1'
BASE_DN = 'OU=NA,DC=NA,DC=NA'

ADMIN_USERS = ['root','cadmin']

# MongoDB information
MONGO_CONN_URI = "mongodb://chakshu:chakshumanager@localhost/chakshudb"
MONGO_DBNAME = "chakshudb"

# Billing
SENDER_EMAIL = "nsmsupport@cdac.in"
SENDER_PASSWD = 'NA'


# Enter Services to be monitored seperated by comma
# Example, SERVICES : [httpd, firewalld]
SERVICES = ["chronyd","crond","gmond","lnet","mdmonitor","munge","nrpe","nslcd","rsyslog","slapd","slurmd","snmpd","sshd","syslog"]


# Chakshu
CHAKSHU_HOME = '/home/apps/chakshu/'
PASSKEY = "1WaM9X@to9X/&*@#jhHJ#@*&^#hdkadaj1#3290JHhkj326)(*@tY827g#@^@(7"






