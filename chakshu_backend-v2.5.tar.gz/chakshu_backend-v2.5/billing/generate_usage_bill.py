#!/home/apps/chakshu/venv_chakshu/bin/python

from utilities import *
import argparse

# PDF generation tools
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# Emailing imports
import email
import smtplib
import ssl
from email import encoders
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from urllib.parse import quote
import json
import requests
from io import BytesIO
from PIL import Image
from os import system, path


# Registering font styles
pdfmetrics.registerFont(TTFont(
    'Ubuntu', chakshu_conf.CHAKSHU_HOME + 'billing/fonts/ubuntu/Ubuntu-R.ttf'))
pdfmetrics.registerFont(TTFont(
    'Ubuntu-Bold', chakshu_conf.CHAKSHU_HOME + 'billing/fonts/ubuntu/Ubuntu-B.ttf'))
pdfmetrics.registerFont(TTFont(
    'Silkscreen', chakshu_conf.CHAKSHU_HOME + 'billing/fonts/Silkscreen/slkscr.ttf'))

def parse_args():
    parser = argparse.ArgumentParser(
        prog='create_uasage_bill.py', description='Creates a usage bill for a user ')
    parser.add_argument(
        '-m', '--last_month', action='store_true', default=False, help="If specified last month usage will be calculated.")
#    parser.add_argument(
#        '-c', '--curent_month', action='store_true', default=False, help="If specified current month's till date usage will be calculated.")
    parser.add_argument(
        '-w', '--last_week', action='store_true', default=True, help="[DEFAULT] If specified last week usage will be calculated.")
    # parser.add_argument('--users', nargs='+',
    #                     help='Mention 1 or more usernames seperated by blank space.', required=False)
    parser.add_argument(
        '-u', '--username', action='store', help="[REQUIRED] Specify username for whom usage to be calculated.", required=True)

    return parser.parse_args()


args = parse_args()


# Date and time formatting
today = datetime.today()
today_str = str(today.strftime("%d %b %Y"))
today_short = str(today.strftime("%d%m%y"))
lm_start, lm_end = previous_month_range(today)
lw_start, lw_end = previous_week_range(today)


# Get MongoDB connection
db = mongo_connection()

SLURM_REPORT_CMD = None
report_duration = None
report_duration = 'Last Week ('+ str(lw_start.strftime("%d/%m")) +' - '+ str(lw_end.strftime("%d/%m")) +')'
lw_start = str( lw_start.strftime(start_slurmformat) )
lw_end = str( lw_end.strftime(end_slurmformat) )
SLURM_REPORT_CMD = f"sreport --tres=cpu,gres/gpu,billing cluster AccountUtilizationByUser user={args.username} start={lw_start}  end={lw_end} -P | grep -iw -e billing -e cpu -e gres/gpu"
NJOBS_CMD = f"sacct -u {args.username} --format=JobID -S {lw_start} -E {lw_end} -P | grep -v -e '.batch' -e 'JobID' | wc -l"
if args.last_month:
    report_duration = 'Last Month (' + str(lm_start.strftime("%b %Y")) + ')'
    lm_start = str(lm_start.strftime(start_slurmformat))
    lm_end = str(lm_end.strftime(end_slurmformat))
    SLURM_REPORT_CMD = f"sreport --tres=cpu,gres/gpu,billing cluster AccountUtilizationByUser user={args.username} start={lm_start} end={lm_end} -P | grep -iw -e billing -e cpu -e gres/gpu"
    NJOBS_CMD = f"sacct -u {args.username} --format=JobID -S {lm_start} -E {lm_end} -P | grep -v -e '.batch' -e 'JobID' | wc -l"



def users_utilization():
    tresmins, gresmins, billing_inr, njobs = 0, 0, 0, 0
    try:
        out = runStringCommand(SLURM_REPORT_CMD)
        njobout = runStringCommand(NJOBS_CMD)
    except Exception as e:
        logger.error(e)
    if out != 1:
        lines = out.split('\n')
        tresmins = int(lines[0].split('|')[-1].strip()) 
        billing_inr = int(lines[1].split('|')[-1].strip()) / 100
        gresmins = int(lines[2].split('|')[-1].strip()) 
    if njobout != 1:
        njobs = int(njobout.strip())
    return {'cpumins':tresmins, 'gpumins':gresmins, 'billing_inr':billing_inr, 'njobs':njobs}



def generate_usage_bill():
    user_usage = users_utilization()
    userdetails = getuserinfo(args.username)
    # Retrive previous bills count
    usage_bills = db['usage_bills']
    total_bills = usage_bills.count_documents({})
    billno = total_bills + 1
    bill_details = {'invoice_number': str(today.year) + '/' + str(today.month) + '/' + f'{ billno :04}',
                    'username': args.username,
                    'invoice_duration': report_duration,
                    'percpu': chakshu_conf.PERCPU,
                    'pergpu': chakshu_conf.PERGPU,
                    'cpumins': user_usage['cpumins'],
                    'gpumins': user_usage['gpumins'],
                    'njobs': user_usage['njobs'],
                    'emoney_consumed': user_usage['billing_inr'],
                    'email': userdetails['userinfo']['mail'][0].decode('utf-8'),
                    'account': userdetails['user_acct'].strip(),
                    'date': datetime.now(), }
    result = usage_bills.insert_one(bill_details)
    logger.info('Bill no : ' + str(billno) + " - " + str(result))
    return bill_details


# Generate invoice PDF using above data
def generate_invoice(bill_details, INVOICE_PATH):
    # Creating Canvas
    runStringCommand(
        'mkdir -p ' + chakshu_conf.CHAKSHU_HOME + 'billing/invoices')
    c = canvas.Canvas(INVOICE_PATH, pagesize=(400, 500), bottomup=0)

    # Logo Section
    c.translate(10, 50)
    # Inverting the scale for getting mirror Image of logo
    c.scale(1, -1)
    c.drawImage(chakshu_conf.CHAKSHU_HOME +
                "billing/images/logo.png", 0, 0, width=40, height=40)
    # Title Section
    c.scale(1, -1)
    # Again Setting the origin back to (0,0) of top-left
    c.translate(-10, -50)
    # Setting the font for Name title of company
    c.setFont("Ubuntu-Bold", 12.5)
    c.drawCentredString(
        200, 25, "Centre for Development of Advanced Computing")
    c.setFont("Ubuntu", 8)
    c.drawCentredString(210, 35, "Innovation Park, Mansarovar, Panchwati")
    c.drawCentredString(210, 45, "Pashan, Pune (IN) - 411008")
    c.line(10, 60, 390, 60)

    # Logo Section
    c.translate(350, 50)
    # Inverting the scale for getting mirror Image of logo
    c.scale(1, -1)
    c.drawImage(chakshu_conf.CHAKSHU_HOME +
                "billing/images/nsm-logo.png", 0, 0, width=40, height=40)

    # Title Section
    c.scale(1, -1)
    # Again Setting the origin back to (0,0) of top-left
    c.translate(-350, -50)
    # Document Information
    # Changing the font for Document title
    c.setFont("Ubuntu-Bold", 10)
    c.drawCentredString(200, 75, "INVOICE")

    c.setFont("Ubuntu", 8)
    c.drawString(10, 85, "Invoice No.: " + bill_details["invoice_number"])
    c.drawCentredString(350, 85, "Date: " + today_str)

    # FIRST Block Consist of User details
    c.roundRect(10, 90, 380, 105, 1, stroke=1, fill=0)
    #c.roundRect(285, 90, 105, 105, 1, stroke=1, fill=0)

    c.setFont("Ubuntu-Bold", 8)
    c.drawString(20, 110, 'Bill To')
    c.setFont("Ubuntu", 8)
    c.drawString(
        20, 120, bill_details['username'] + ' ('+bill_details['account']+'),')

    c.setFont("Ubuntu-Bold", 8)
    c.drawString(20, 130, 'Email : ')
    c.setFont("Ubuntu", 8)
    c.drawString(50, 130, bill_details['email'])

    # sEcoND Block Consist of consumption Details
    c.roundRect(10, 200, 270, 150, 1, stroke=1, fill=0)
    c.roundRect(285, 200, 105, 150, 1, stroke=1, fill=0)

    c.setFont("Ubuntu-Bold", 8)
    c.drawCentredString(
        135, 210, 'Usage Summary For - ' + bill_details['invoice_duration'])

    # Table
    c.line(10, 215, 280, 215)
    c.line(10, 250, 280, 250)
    c.line(10+54*3, 215, 10+54*3, 250)
    c.line(10, 285, 280, 285)
    c.line(10+54*3, 250, 10+54*3, 285)

    c.setFont("Ubuntu", 8)
    c.drawString(15, 235, 'CPU Compute Consumed')
    c.setFont("Ubuntu-Bold", 8)
    c.drawString(177, 235,str(bill_details['cpumins']))
    c.setFont("Ubuntu", 6)
    c.drawRightString(275, 235, '(CPU Core Mins.)')

    c.setFont("Ubuntu", 8)
    c.drawString(15, 270, 'GPU Compute Consumed')
    c.setFont("Ubuntu-Bold", 8)
    c.drawString(177, 270, str(bill_details['gpumins']))
    c.setFont("Ubuntu", 6)
    c.drawRightString(275, 270, '(GPU Card Mins.)')

    # Jobs Processed
    c.setFont("Ubuntu-Bold", 10)
    c.drawString(15, 340, 'No. of Jobs Proccessed : ' + str( bill_details['njobs'] ))

    # Consumption in INR
    c.setFont("Ubuntu", 8)
    c.drawString(295, 220, 'eMoney Consumed')
    c.line(285, 315, 390, 315)
    c.setFont("Ubuntu-Bold", 12)
    c.drawString(295, 330, inr_sym)
    c.setFont("Silkscreen", 12)
    c.drawString(305, 330,  str(bill_details['emoney_consumed']))
    c.setFont("Ubuntu", 6)

    # Signature
    c.setFont("Ubuntu", 8)
    c.drawString(
        10, 400, '(This is a computer generated invoice and no signature is required.)')
    c.setFont("Ubuntu-Bold", 8)
    c.drawString(10, 410, 'Authorized Signatory')

    c.line(10, 430, 390, 430)

    # References
    c.setFont("Ubuntu", 8)
    c.drawString(10, 440, f"Per CPU Core/Minutes Charges = {bill_details['percpu']} paisa")
    c.drawString(10, 450, f"Per GPU Card/Minutes Charges = {bill_details['pergpu']} paisa")

    # End the Page and Start with new
    c.showPage()
    # Saving the PDF
    c.save()
    logger.info(" Invoice saved successfully : "+INVOICE_PATH)


def build_chart(data):
    CHART_PATH = chakshu_conf.CHAKSHU_HOME+'billing/charts/chart_' + \
        today_short + '_' + data['username'] + '.png'
    # Build Chart for emailing
    doughnut_chart = {
	    "type": "doughnut",
	    "data": {
		"labels": ["CPU Mins.", "GPU Mins."],
		"datasets": [{
		    "data": [data["cpumins"], data["gpumins"]]
		}]
	    },
	    "options": {
		"plugins": {
		    "datalabels": {
		        "display": True,
		        "backgroundColor": "#ccc",
		        "borderRadius": 3,
		        "font": {
		            "color": "red",
		            "weight": "bold",
		        }
		    },
		    "doughnutlabel": {
		        "labels": [{
		            "text": data["emoney_consumed"]*100,
		            "font": {
		                "size": 20,
		                "weight": "bold"
		            }
		        }, {
		            "text": "Total Usage"
		        }]
		    }
		}
	    }
	}
    encoded_config = quote(json.dumps(doughnut_chart))
    chart_url = f'https://quickchart.io/chart?c={encoded_config}'
	
    # Get chart image and save in a file
    response = requests.get(chart_url)
    image_bytes = BytesIO(response.content)
    chart = Image.open(image_bytes)
    runStringCommand(
        'mkdir -p ' + chakshu_conf.CHAKSHU_HOME + 'billing/charts')
    chart.save(CHART_PATH, 'PNG')
    return chart_url
   




# Method for sending an email to the user with attached invoice pdf generated above
def email_usage_bill(invoicepath, bill_details):
    if not path.isfile(invoicepath):
        logger.warning("Invoice is not generated yet. File does not exists!")

    # Create chart URL using Chart.js
    chart_url = build_chart(bill_details)

    # Open chart file and covert it to MIME Type
    # try:
    #     fp = open(CHART_PATH, 'rb')
    #     chart_image = MIMEImage(fp.read())
    #     fp.close()
    #     chart_image.add_header('Content-ID', '<ChartImage>')
    # except Exception as e:
    #     logger.error(e)
    # Use As : <img src="cid:ChartImage" style="width:500px; height:300px;">

    # Email configuration
    sender_email = chakshu_conf.SENDER_EMAIL
    receiver_email = bill_details['email']
    password = chakshu_conf.SENDER_PASSWD

    message = MIMEMultipart("html")
    message["Subject"] = "HPC resource usage bill for - " + \
        bill_details['invoice_duration']
    message["From"] = sender_email
    message["To"] = receiver_email

    # Create the plain-text and HTML version of your message
    username = bill_details['username']
    html = f"""\
    <html>
    <body>
        <h3>Dear { username },</h3>
        <p style="font-size:16px;">
        We hope you are doing great!<br>
        Please find the attached invoice for your resource usage.
        </p>
        <h3>Observe the usage chart provided below.</h3>
        <div style="width:510px; height:310px; border-radius:5px; padding:10px;">
            <img src="{ chart_url }" style="width:500px; height:300px;">
        </div>
    </body>
    </html>
    """
    
    # Turn these into plain/html MIMEText objects
    body = MIMEText(html, "html")

    # Invoice file
    try:
        with open(invoicepath, "rb") as attachment:
            # Add file as application/octet-stream
            # Email client can usually download this automatically as attachment
            invoice = MIMEBase("application", "octet-stream")
            invoice.set_payload(attachment.read())
    except Exception as e:
        logger.error(e)
    # Encode file in ASCII characters to send by email
    encoders.encode_base64(invoice)
    # Add header as key/value pair to attachment part
    invoice.add_header(
        "Content-Disposition",
        "attachment; filename=invoice.pdf",
    )

    # Add HTML/plain-text parts to MIMEMultipart message
    # The email client will try to render the last part first
    message.attach(body)
    # message.attach(chart_image)
    message.attach(invoice)

    try:
        # Create secure connection with server and send email
        context = ssl.create_default_context()
        with smtplib.SMTP("smtp.cdac.in", 587) as server:
            # with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(
                sender_email, receiver_email, message.as_string()
            )
        logger.info('Email sent to ' + bill_details['email'])
    except Exception as e:
        logger.error(e)


def email_invoice():
    bill_details = generate_usage_bill()
    print(bill_details)
    invoice_number = bill_details['invoice_number'].replace('/', '')
    INVOICE_PATH = chakshu_conf.CHAKSHU_HOME+"billing/invoices/" + \
        today_short + '_' + str(invoice_number) + \
        '_' + bill_details['username'] + "_usage_invoice.pdf"
    generate_invoice(bill_details, INVOICE_PATH)
    email_usage_bill(INVOICE_PATH, bill_details)


email_invoice()