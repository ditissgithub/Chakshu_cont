#!/home/apps/chakshu/venv_chakshu/bin/python


from utilities import *

# Date and time formatting
today = datetime.today()
lm_start, lm_end = previous_month_range(today)
lw_start, lw_end = previous_week_range(today)


def user_job_utilization_data(userid):
    db_connection = mysqldb_connection()
    cursor = db_connection.cursor()

    query = ("SELECT id_job, partition, nodes_alloc, cpus_req, (time_end - time_start) AS runtime, tres_alloc, gres_alloc, exit_code "
        "FROM linux_job_table "
        "WHERE id_user=%s "
        "AND (tres_alloc != '' or gres_alloc != '') "
        "AND time_start between UNIX_TIMESTAMP(%s) AND UNIX_TIMESTAMP(%s)")
        #"WHERE hire_date BETWEEN %s AND %s")
    cursor.execute(query, (userid, lastMonthStart, lastMonthEnd))

    ncores, ngpucards, runtimesec = 0, 0, 0
    bill_inr = 0.0
    for row in cursor:
        partition, runtime, tres_alloc, gres_alloc, exitcode = row[1], row[4], row[5], row[6], row[7]
        # tres_alloc : 1=168,4=6,5=168,1001=12 ; gres_alloc : gpu:4
        runtimesec += runtime
        if tres_alloc:
            cores = tres_alloc.split(',')[0].split('=')[1].strip()
            ncores += int( cores )
        if gres_alloc:
            gpus = gres_alloc.split(':')[1].strip()
            ngpucards += int( gpus )
    #print( 'cores : ', ncores, 'gpuscards : ', ngpucards, 'runtime(sec) : ', runtimesec )
    jobs = cursor.rowcount
    cursor.close()
    db_connection.close()
    logger.info("Database connection closed!")
    return {'cores':ncores, 'gpuscards':ngpucards, 'runtime_sec': runtimesec }


#for userid in active_users(lastMonthStart, lastMonthEnd):
#    username = getuserinfo(userid)['uid'][0].decode('utf-8')
#    mail = getuserinfo(userid)['mail'][0].decode('utf-8')
#    print(userid, username, ' : \t', user_job_utilization_data(userid))

# print(1081, ' : \t', user_job_utilization_data(1081))

