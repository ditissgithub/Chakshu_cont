#!/home/apps/chakshu/venv_chakshu/bin/python

import subprocess
import ldap
import progressbar
from time import sleep
from datetime import date, timedelta, datetime
import mysql.connector
import pymongo
import imp
import logging


chakshu_conf = None
filepath = '/home/apps/chakshu/.secret/chakshu_admin_conf.py'
with open(filepath, 'rb') as fp:
    chakshu_conf = imp.load_module('chakshu_conf', fp, filepath, \
    ('.py', 'rb', imp.PY_SOURCE))


# Confguring logging
logging.basicConfig(filename='/var/log/chakshu/usage_billing.log',
                    format='%(asctime)s : %(levelname)s - %(message)s')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

start_sqlformat = '%Y-%m-%d 00:00:00'
end_sqlformat = '%Y-%m-%d 23:59:59'
start_slurmformat = '%Y-%m-%dT00:00:00'
end_slurmformat = '%Y-%m-%dT23:59:59'
db_table = chakshu_conf.DB_TABLE_PREFIX+'_job_table'
inr_sym = u"\u20B9"

def previous_month_range(date):
    firstday = date.replace(day=1)
    end = firstday - timedelta(days=1)
    end.replace(hour=23, minute=59, second=59, microsecond=0)
    start = end.replace(day=1)
    start.replace(hour=0, minute=0, second=0, microsecond=0)
    return start, end


def previous_week_range(date):
    start_date = date + timedelta(-date.weekday(), weeks=-1)
    start_date.replace(hour=0, minute=0, second=0, microsecond=0)
    end_date = date + timedelta(-date.weekday() - 1)
    end_date.replace(hour=23, minute=59, second=59, microsecond=0)
    return start_date, end_date


def runStringCommand(command):
    try:
        data = subprocess.check_output(
            command,  stderr=subprocess.STDOUT, shell=True)
        return data.decode('utf-8')
    except subprocess.CalledProcessError as e:
        return e.returncode


def mongo_connection():
    try:
        client = pymongo.MongoClient( chakshu_conf.MONGO_CONN_URI )
        db = client[chakshu_conf.MONGO_DBNAME]
        collections = db.list_collection_names()
        logger.info("Connected. " + str(db))
        return db
    except pymongo.errors.OperationFailure as e:
        logger.error(e)



def mysql_connection():
    try:
        # Connecting to configured database.
        db_connection = mysql.connector.connect(
            host=chakshu_conf.DB_SERVER,
            user=chakshu_conf.__DB_USERNAME,
            passwd=chakshu_conf.__DB_PASSWORD,
            database=chakshu_conf.SCHEDULER_DB_NAME )
        logger.info("Connected. "+ str(db_connection))
        return db_connection
    except mysql.connector.Error as e:
        logger.error(e)


def getuserinfo(username):
    connect = ldap.initialize(chakshu_conf.LDAP_SERVER)
    result = connect.search_s(chakshu_conf.BASE_DN,
                              ldap.SCOPE_SUBTREE, "(uid="+username+")")
    userinfo = None
    try:
        userinfo = result[0][1]
    except Exception as e:
        logger.error(e)
        exit()
    user_sacct = runStringCommand(
        "sacctmgr list user | grep "+username+" | awk '{print$2}'")
    return {'userinfo': userinfo, 'user_acct': user_sacct}


def getuserinfo_uidNum(userid):
    single_user = "ldapsearch -x -H "+ chakshu_conf.LDAP_SERVER +" 'uidNumber="+str(userid)+"' -LLL | grep -w -e mail -e uid:"
    out = runStringCommand(single_user)
    if out == 1:
        return None
    userdetails = {'userid':userid, 'mail':''}
    for l in out.split('\n'):
        print(l)
        details = [ d.strip() for d in l.split(':') ]
        if 'mail'in l:
            userdetails['mail'] = details[1]
        if 'uid' in l:      
            userdetails['username'] = details[1]
    return userdetails


# Retrieve all active users for mentioned period
def active_users(start, end):
    db_connection = mysql_connection()
    cursor = db_connection.cursor()
    query = ("SELECT DISTINCT id_user FROM "+ db_table +" WHERE time_start between UNIX_TIMESTAMP(%s) AND UNIX_TIMESTAMP(%s) AND id_user!=0")
    cursor.execute(query, ( start, end))
    users = [u[0] for u in cursor.fetchall() if u is not None]

    cursor.close()
    db_connection.close()
    return users