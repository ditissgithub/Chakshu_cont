import os
import imp

from chakshu_api import settings

__version__ = settings.VERSION
logger = settings.LOGGER
chakshu_conf = settings.chakshu_conf


# Log version information
logger.info("chakshu_api-" + __version__ + " started/restarted...")


