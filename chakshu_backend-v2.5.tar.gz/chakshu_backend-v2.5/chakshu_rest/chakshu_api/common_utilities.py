import json
import pandas
import subprocess
from os import environ
import re
import mysql.connector
from datetime import datetime, timedelta
import pymongo



from chakshu_api import settings
# Assigned chakshu configs and logger
chakshu_conf = settings.chakshu_conf
logger = settings.LOGGER


UNWANTED_STATES = ['drain','down','maint','comp','resv','drng']

def runStringCommand(command):
    try:
        data = subprocess.check_output(command,  stderr=subprocess.STDOUT, shell=True )
        return data.decode('utf-8')
    except subprocess.CalledProcessError as e:
        print("Unreachable: ",e)
        return e.returncode


def previous_month_range(date):
    firstday = date.replace(day=1)
    end = firstday - timedelta(days=1)
    end.replace(hour=23, minute=59, second=59, microsecond=0)
    start = end.replace(day=1)
    start.replace(hour=0, minute=0, second=0, microsecond=0)
    return start, end


#-- Executing commands
def runOsCommand1(commandarglist):
    return subprocess.check_output(commandarglist)

def runOsCommand(commandarglist):
    out = subprocess.check_output(commandarglist)
    outArr = out.decode('utf-8').split("\n")
    output = ""
    for out in outArr:
        output = output+"\n"+out
    return output.strip()


def jsontranslator(field,data):
    data = data.replace("{","")
    data = data.replace("}","")
    data = data.replace("\"","")
    result = ""
    result = result+"\n"+data
    df = pandas.DataFrame(sub.split("\t") for sub in result.strip().split("\n"))
    df.columns = field
    parsed = json.loads(df.reset_index().to_json(orient='records'))
    return json.loads(json.dumps(parsed, indent=4, sort_keys=True))



def parseBracketNodes(bracket):
    nodelist = []
    strings = bracket.split('(')
    nodetype = strings[0]
    ranges = strings[1]
    ranges = ranges.replace(")","")
    if "," in ranges:
        ranges = ranges.split(",")
        for rng in ranges:
            if '-' in rng:
                start, end  = rng.split('-')
                digits = len(start)
                start = int(start)
                end = int(end)
                for node in range(start, end+1):
                    if (node < 10 and digits == 2) or (node < 100 and digits == 3):
                        node = nodetype + "0" + str(node)
                    elif node < 10 and digits == 3:
                        node = nodetype + "00" + str(node)
                    else:
                        node = nodetype + str(node)
                    nodelist.append(node)   
            else:
                nodelist.append(nodetype+rng)
    if '-' in ranges:
        start, end  = ranges.split('-')
        digits = len(start)
        start = int(start)
        end = int(end)
        for node in range(start, end+1):
            if (node < 10 and digits == 2) or (node < 100 and digits == 3):
                node = nodetype + "0" + str(node)
            elif node < 10 and digits == 3:
                node = nodetype + "00" + str(node)
            else:
                node = nodetype + str(node)
            nodelist.append(node)
    return nodelist




def parseNodelists(nodelists):
    nodelist = []
    ranges = None
    for nodel in nodelists:
        nodes = nodel['nodelist']
        nodes = nodes.replace("[","(")
        nodes = nodes.replace("]",")")
        if ',' in nodes:
            ranges = re.split(r',\s*(?![^()]*\))', nodes)
            for a_range in ranges:
                if '(' in a_range:
                    nodelist = nodelist + parseBracketNodes(a_range)
                else:
                    nodelist.append(a_range)
        else:
            if '(' in nodes:
                nodelist = nodelist + parseBracketNodes(nodes)
            else:
                nodelist.append(nodes)
    return nodelist
    
    
def getUsersList():
    users = []
    uid_min = runStringCommand("cat /etc/login.defs | grep -w UID_MIN | awk '{print$2}'")
    uid_max = runStringCommand("cat /etc/login.defs | grep -w UID_MAX | awk '{print$2}'")
    command = "getent passwd | awk -F ':' -v 'min="+uid_min+"' -v 'max="+uid_max+"' '{if ($3 > min && $3 <=max ) print $0}' | cut -d ':' -f 1,3 --output-delimiter='=='  | awk '!x[$0]++'"
    out = runStringCommand(command)
    lines = out.split('\n')
    for l in lines:
        if not l:
            continue
        uname,uid = l.split('==')
        user = {}
        user['userid'] = uid.strip()
        user['username'] = uname.strip()
        users.append(user)
    return sorted(users, key=lambda i: i['userid'])
    

def getChakshuEnvVars():
    CHAKSHU_ROOT = environ['CHAKSHU_ROOT']
    return { 'CHAKSHU_ROOT' : CHAKSHU_ROOT }



def get_allnodes_states():
    """
    Return all the nodes with their resource states.
    """
    nodelist = []
    cmd = environ['SLURM_NODES']
    output = runStringCommand(cmd)
    for line in output.split('\n'):
        if line:
            node,state = line.split(' ')
            nodelist.append({ "node":node, "state":state })
    return sorted(nodelist, key=lambda i: i['node'])





def ost_mysql_connection(logger=None):
    """
    Conecting to ost(osticketing) mysql database.
    """
    db = None
    try:
        db = mysql.connector.connect(
            host=chakshu_conf.OST_DB_SERVER,
            user=chakshu_conf.OST_DB_USER,
            passwd=chakshu_conf.OST_DB_PASSWORD,
            database=chakshu_conf.OST_DB_NAME
        )
        if logger is not None:
            logger.info("Connected to ost database "+ str(db))
        return db
    except mysql.connector.Error as e:
        if logger is not None:
            logger.error(e)



##-- MongoDB Convinience Methods --##

def get_mongodb_connecion():
    """
    Mongodb connection utility method
    Conecting to database.
    """
    client = None
    db = None
    try:
        client = pymongo.MongoClient(chakshu_conf.MONGO_CONN_URI)
        db = client[ chakshu_conf.MONGO_DBNAME ]
        logger.info("Connected. "+ str(db))
        return db
    except pymongo.errors.OperationFailure as e:
        logger.error(e)
db = get_mongodb_connecion()


def starttime():
    return datetime.now() - timedelta(minutes=5)



def get_cpu_percent(nodename):
    """
    Retrive nodename's cpu_percent
    """
    cpu_percent = 0.0
    result = db.cpu_info.find( {'node':nodename, 'timestamp':{'$gt':starttime()}}, limit=1).sort('timestamp', pymongo.DESCENDING)[0]
    if result:
        cpu_percent = result['cpu_percent']
    return cpu_percent


def get_total_cpu_times(nodename):
    """
    Retrieve nodename's cpu time percentage in total
    """
    total_cpu_util = None
    result = db.cpu_info.find({'node':nodename, 'timestamp':{'$gt':starttime()}}, limit=1).sort('timestamp', pymongo.DESCENDING)[0]
    if result:
        total_cpu_util = result['total_cpu_util']
    return total_cpu_util


def get_per_core_utilizations(nodename):
    """
    Retrieve nodename's cpu time percentage per core
    """
    core_utilizations = None
    result = db.cpu_info.find({'node':nodename, 'timestamp':{'$gt':starttime()}}, limit=1).sort('timestamp', pymongo.DESCENDING)[0]
    if result:
        core_utilizations = result['core_utilizations']
    return core_utilizations


def get_temperature(nodename):
    """
    Retrive nodename's core temperature
    """
    avg_temp = 0.0
    result = db.temperature_info.find({'node':nodename, 'timestamp':{ '$gt':starttime() }}, limit=1).sort('timestamp', pymongo.DESCENDING)[0]
    if result:
        avg_temp = result['avg_temperature']
    return avg_temp



def get_memory_percent(nodename):
    """
    Retrive nodename's memory_percent
    """
    mem_percent = 0.0
    result = db.memory_info.find({'node':nodename})[0]
    if result:
        mem_percent = result['main_memory']['percent']
    return mem_percent



def get_loads(nodename):
    """
    Retrive nodename's loadavg
    """
    loads = None
    result = db.load_info.find({'node':nodename})[0]
    if result:
        loads = result['loadavg']
    return loads



def running_processes(nodename):
    """
    Retrieve nodename's running processes details
    """
    procs = None
    result = db.process_info.find({"node":nodename})[0]
    if result:
        procs = result['procs']
    return procs



def get_memory_info(nodename):
    """
    Retrieve nodename's memory info
    """
    meminfo = None
    result = db.memory_info.find({'node':nodename})[0]
    if result:
        meminfo = result['main_memory']
    return meminfo



def get_network_io(nodename):
    """
    # Retrieve nodename's network I/O info
    """
    netio = None
    result = db.network_info.find({'node':nodename})[0]
    if result:
        netio = result['netio']
    return netio



def get_service_info(nodename):
    """
    Retrieve nodename's services status
    """
    services = None
    result = db.services_info.find({'node':nodename})[0]
    if result:
        services = result['services']
    return services



def get_diskio_info(nodename):
    """
    Retrieve nodename's disk I/O info
    """
    diskio = None
    result = db.diskio_info.find({'node':nodename})[0]
    if result:
        diskio = result['diskio']
    return diskio



def get_gpu_info(nodename):
    """
    Retrieve nodename's gpu info
    """
    gpuinfo = None
    result = db.gpu_info.find({'node':nodename})[0]
    if result:
        gpuinfo = result['gpuinfo']
    return gpuinfo



def get_user_info(userid):
    """
    Retrive user details using userid
    """
    user = None
    result = db.users.find({'userid':userid},{'_id':False})[0]
    if result:
        user = result
    return user



