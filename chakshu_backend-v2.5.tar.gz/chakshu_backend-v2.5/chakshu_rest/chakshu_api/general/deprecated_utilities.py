import json
import psutil
from django.db.models import Case, CharField, Value, When
from pytz import timezone
import datetime
import time
import re

import common_utilities as utils
import node_details.utilities as node_utils

from chakshu_api import settings
# Assigned chakshu configs and logger
chakshu_conf = chakshu_conf = settings.chakshu_conf



################# DEPRECATED METHODS #######################


DATA_DIR = chakshu_conf.CHAKSHU_DATA_DIR
jsonify = True


# get_general_data()
def getAvgCpuMemUtil():
    mydict = {}
    system_name = chakshu_conf.CLUSTER_NAME
    tf_count =  chakshu_conf.RPEAK
    data = []
    with open(DATA_DIR + 'master/cpuMemUtil.json') as f:
        data = json.load(f)

    uptime = getUptime()
    mydict['cpu'] = round(data[0]['cpu'],2)
    mydict['mem'] = round(data[0]['mem'],2)
    mydict['system_name'] = system_name
    mydict['tf_count'] = tf_count
    mydict['uptime'] = uptime
    mydict["total_users"] = utils.getTotalUser()
    return mydict


# disk_partition_usage()
def diskPartitonUsage():
    data1 = psutil.disk_usage('/home')
    data2 = psutil.disk_usage('/scratch')
    mydict1 = {}
    mydict2 = {}
    final = []
    per1 = 0
    per2 = 0
    mydict1['name'] = "/home"
    mydict1['total']  = round(int(data1[0])/(1024*1024*1024*1024),1)
    mydict1['used']  = round(int(data1[1])/(1024*1024*1024*1024),1)
    per1 = (round(int(data1[1])/(1024*1024*1024*1024),1) / round(int(data1[0])/(1024*1024*1024*1024),1)) * 100
    mydict1['percent'] = round(per1,1)

    mydict2['name'] = "/scratch"
    mydict2['total']  = round(int(data2[0])/(1024*1024*1024),1)
    mydict2['used']  = round(int(data2[1])/(1024*1024*1024),1)
    per2 = (round(int(data2[1])/(1024*1024*1024),1) / round(int(data2[0])/(1024*1024*1024),1) ) * 100
    mydict2['percent'] = round(per2,1)

    final.append(mydict1)
    final.append(mydict2)
    return final


# server_info() 
def clusterview():
    outArr =  node_utils.getNodesList()        
    result = ""
    result_field = []
    cluster = chakshu_conf.CLUSTER_NAME	
    result_field.append("Name")
    result = result + "\t" + cluster
    total_nodes = chakshu_conf.TOTAL_NODES
    result_field.append("Total_Nodes")
    result = result+"\t"+str(total_nodes)
    state,partition = node_utils.getNodeStateInfo()
    nodestate_counter = {}

    for nodename, state in state.items():
        if nodename == "master":
            pass
        else:
            if nodename != "master" and state in nodestate_counter:
                nodestate_counter[state] = nodestate_counter[state]+1 
            else:
                nodestate_counter[state] =  1
    del nodestate_counter['STATE']
    result_field.append("Node_states")
    result = result+"\t"+json.dumps(nodestate_counter)
    
    currently_running_jobs = getNoOfAllRunning()
    result_field.append("running_jobs")
    result = result+"\t"+str(currently_running_jobs)

    if jsonify:
        return utils.jsontranslator(result_field,result)  
    return result


# system_info()
def systemInformation():
    kernel_version = utils.runOsCommand(['uname','-r'])
    architecture = utils.runOsCommand(['uname','-p'])
    resource_manager = utils.runOsCommand(['sinfo','-V'])
    cpu = chakshu_conf.CPU_NODES
    cpu_cores = chakshu_conf.CPU_CORES
    gpu = chakshu_conf.GPU_NODES 
    gpu_cores = chakshu_conf.GPU_CORES
    processor_series_cpu = chakshu_conf.CPU_SERIES_CODE
    processor_series_gpu =  chakshu_conf.GPU_SERIES_CODE

    final = []
    mydict = {}
    mydict['kernel'] = kernel_version
    mydict['architecture'] = architecture
    mydict['resource_manager'] = resource_manager
    mydict['cpu'] = cpu 
    mydict['cpu_cores'] = cpu_cores
    mydict['gpu'] = gpu
    mydict['gpu_cores'] = gpu_cores
    mydict['processor_series_cpu'] = processor_series_cpu
    mydict['processor_series_gpu'] = processor_series_gpu
    final.append(mydict) 
    return final


# node_cpu_mem_utilization()
def getNodesCpuMemUtil():
    nodelist = node_utils.plotNodeState()
    cpu_mem_utils = []
    unwanted_states = ['drain','down','maint','comp','resv','drng']
    for i,node in enumerate(nodelist):
        temp = {}
        nodename = node['value']
        temp['node'] = nodename
        nodeinfo = node_utils.getnodeinfo(nodename)
        if ('cpupercent' not in nodeinfo) or node['name'] in unwanted_states:
            temp['cpu'] = 0.0
        else:
        	temp['cpu'] = nodeinfo['cpupercent']
            
        if ('mempercent' not in nodeinfo) or node['name'] in unwanted_states:
            temp['memory'] = 0.0                
        else:   
            temp['memory'] = nodeinfo['mempercent']
        cpu_mem_utils.append(temp)
    return sorted(cpu_mem_utils, key=lambda i: i['node'])



# get_agg_loadavg_data() 
def getLoadVal():
    hello = utils.runOsCommand(['cat','/proc/loadavg'])
    one = hello.split(' ')
    return one

def plotLoadAvg():
    t=1
    list1 =[]
    list2= []
    list3= []

    for i in range(0,10):
        x = getLoadVal()
        IST = timezone('Asia/Calcutta')
        ti = datetime.datetime.now(IST)
        two = str(ti).split('.')
        three = two[0].split(' ')

        mydict1 = {}
        mydict2 = {}
        mydict3 = {}

        mydict1['name'] = three[1]
        mydict1['value'] = x[0]

        mydict2['name'] = three[1]
        mydict2['value'] = x[1]

        mydict3['name'] = three[1]
        mydict3['value'] = x[2]

        list1.append(mydict1)
        list2.append(mydict2)
        list3.append(mydict3)
        time.sleep(t)

    finalList =[]
    mydict1={}
    mydict2={}
    mydict3={}

    mydict1['series'] = list1
    mydict1['name'] = 'load1'

    mydict2['series'] = list2
    mydict2['name'] = 'load5'

    mydict3['series'] = list3
    mydict3['name'] = 'load15'

    finalList.append(mydict1)
    finalList.append(mydict2)
    finalList.append(mydict3)
    return finalList
    

#############################################################
