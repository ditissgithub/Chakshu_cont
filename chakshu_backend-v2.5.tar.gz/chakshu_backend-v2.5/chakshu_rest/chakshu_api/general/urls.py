from django.urls import path

from .views import (
    getGeneralInfoView,
    DiskPartitionView,
    getClusterStats,
    ServerInfoView,
    SystemInfoView,
    ReservationInfoView,
    PlotLoadAvg,
    UpTimeView,
    UserClusterStatsView,
    UserpartitionUsageApiView,
    UserQuotaView,
    PlotCurrentNodeStateCountView,
    NodeCpuMemUtilView,
    ClusterLoadAvgView,
    IbTopologyInfoView,
)

urlpatterns = [
    path('getgeneralinfo/', getGeneralInfoView.as_view()),
    path('diskpartition/',DiskPartitionView.as_view()),
    path('ClusterStats/',getClusterStats.as_view()),
    path('serverinfo/',ServerInfoView.as_view()),
    path('systeminfo/',SystemInfoView.as_view()),
    path('reservations/',ReservationInfoView.as_view()),
    path('plotloadavg/',PlotLoadAvg.as_view()),
    path('uptime/', UpTimeView.as_view()),
    path('userclusterstats/<int:userid>/', UserClusterStatsView.as_view()),
    path('userpartitionusage/<int:userid>/', UserpartitionUsageApiView.as_view()),
    path('diskquota/<int:userid>/', UserQuotaView.as_view()),
    path('current-node-states/', PlotCurrentNodeStateCountView.as_view()),
    path('nodes-cpu-mem-util/', NodeCpuMemUtilView.as_view()),
    path('cluster-load-avg/', ClusterLoadAvgView.as_view()),
    path('ib-topology/', IbTopologyInfoView.as_view()),
    

    ## Unused endpoints
    # path('loadstats/', LoadStatsApiView.as_view()),
    # path('chakshu-env/', ChakshuEnvVarView.as_view()),
    # path('dummy-rackdata/', DummyRackdataView.as_view())
     

]
