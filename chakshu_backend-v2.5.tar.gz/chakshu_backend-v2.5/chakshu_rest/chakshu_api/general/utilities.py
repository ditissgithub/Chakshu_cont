import json
import psutil
from django.db.models import Case, CharField, Value, When
from pytz import timezone
import datetime
import time
import re

from job_details.models import SlurmJobTable
import common_utilities as utils
import node_details.utilities as node_utils

from chakshu_api import settings
# Assigned chakshu configs and logger
chakshu_conf = settings.chakshu_conf
logger = settings.LOGGER

# deprecated utility methods
# from .deprecated_utilities import *

# Get database connection for operations
db = utils.get_mongodb_connecion()
from pymongo import DESCENDING


# /getgeneralinfo endpoint data
def get_general_data():
    try:
        # retrive data from database
        users_cnt = db.users.count_documents({}) 
        result = db.general_info.find({}, projection={'_id': False}, limit=1).sort('_id', DESCENDING)[0]
        generalinfo = {
            "system_name" : chakshu_conf.CLUSTER_NAME,
            "rpeak" : chakshu_conf.RPEAK,
            "uptime" : getUptime(),
            "total_users" : users_cnt,
            "cpu" : result['avg_cpu'],
            "mem" : result['avg_memory']
        }
        return generalinfo
    except Exception as e:
        logger.error(e)



def getUptime():
    up = utils.runOsCommand(['uptime'])
    uptime = up.split(',')[0]
    return uptime

# /diskpartition endpoint data
def disk_partition_usage():
    partitions = []
    tb_divider = 1024*1024*1024*1024
    try:
        home = psutil.disk_usage('/home')
        scratch = psutil.disk_usage('/scratch')
        home_usage = { 
            'name' : '/home',
            'total' : round( home.total/tb_divider, 2 ),
            'used' : round( home.used/tb_divider, 2 ),
            'percent' : round( home.percent, 2 )
        }
        partitions.append(home_usage)
        scratch_usage = { 
            'name' : '/scratch',
            'total' : round( scratch.total/tb_divider, 2 ),
            'used' : round( scratch.used/tb_divider, 2 ),
            'percent' : round( scratch.percent, 2 )
        }
        partitions.append(scratch_usage)
        return partitions
    except Exception as e:
        logger.error(e)

# /serverinfo endpoint data
def server_info():
    allnodes = utils.get_allnodes_states()
    nodestates_cnt = {}
    for n in allnodes:
        state = n['state']
        if state in nodestates_cnt:
            nodestates_cnt[state] += 1
        else:
            nodestates_cnt[state] = 1
    server_info = {
        "node_states" : nodestates_cnt,
        "cluster_name" : chakshu_conf.CLUSTER_NAME,
        "total_nodes" : chakshu_conf.TOTAL_NODES,
        "running_jobs" : getNoOfAllRunning()
    }
    return server_info

def getNoOfAllRunning():
    queryset = SlurmJobTable.objects.annotate(status=Case(When(state=3, then=Value('Completed')),When(state=5, then=Value('Failed')),When(state=1, then=Value('Running')),default=Value('Unknown'),output_field=CharField(),),).filter(status="Running")
    if len(queryset)>0:
        return len(queryset)
    else:
        return 0


# /systeminfo endpoint data
def system_info():
    sysinfo = {
        "kernel" : utils.runOsCommand(['uname','-r']),
        "architecture" : utils.runOsCommand(['uname','-p']),
        "resource_manager" : utils.runOsCommand(['sinfo','-V']),
        "cpu" : chakshu_conf.CPU_NODES,
        "cpu_cores" : chakshu_conf.CPU_CORES,
        "gpu" : chakshu_conf.GPU_NODES ,
        "gpu_cores" : chakshu_conf.GPU_CORES,
        "processor_series_cpu" : chakshu_conf.CPU_SERIES_CODE,
        "processor_series_gpu" : chakshu_conf.GPU_SERIES_CODE
    }
    return sysinfo



def sectohourMinSec(secs):
    days = secs//86400
    hours = (secs - days*86400)//3600
    minutes = (secs - days*86400 - hours*3600)//60
    seconds = secs - days*86400 - hours*3600 - minutes*60
    result = ("{0} day{1}, ".format(days, "s" if days!=1 else "") if days else "") + \
    ("{0} hour{1}, ".format(hours, "s" if hours!=1 else "") if hours else "") + \
    ("{0} minute{1}, ".format(minutes, "s" if minutes!=1 else "") if minutes else "") + \
    ("{0} second{1}, ".format(seconds, "s" if seconds!=1 else "") if seconds else "")
    return result



# /reservations endpoint data
def getReservations():
    string = utils.runOsCommand(['scontrol','show','res'])
    one = string.split('ReservationName')
    two = []
    three = []
    four = []
    final = []
    for i in range(1,len(one)):
        mydict = {}
        five = []
        two = one[i].split('\n')
        for j in range(0,2):
            three = two[j].split(' ')
            while '' in three:
                three.remove('')
            for l in range(0,len(three)):
                four = three[l].split('=')
                five.append(four[1])
        mydict['name'] = five[0]
        mydict['start_time'] = five[1]
        mydict['end_time'] = five[2]
        mydict['duration'] = five[3]
        mydict['nodes'] = five[4]
        mydict['node_count'] = five[5]
        final.append(mydict)      
    return final


# /cluster-load-avg endpoint data    
def getClusterLoadAvg():
    cluster_loads = []
    N = 200
    a_sec = 1
    now = datetime.datetime.now()
    # go back to N secs
    start_time = now - datetime.timedelta(0,N)
    for i in range(1,N+1):
        new_time = start_time
        # each iteration adds  one sec.
        new_time = new_time + datetime.timedelta(0,a_sec)
        str_time = new_time.strftime("%d/%m/%Y, %H:%M:%S")
        temp_dict = {}
        loads = getLoadVal()
        temp_dict['time'] = str_time
        temp_dict['load1'] = loads[0]
        temp_dict['load5'] = loads[1]
        temp_dict['load15'] = loads[2]
        cluster_loads.append(temp_dict)
    return cluster_loads
        
        
        


def getUserQuota(id):
    # username = os.popen('getent passwd '+id+' | cut -d: -f1').read().split('\n')[0]
    username = utils.runOsCommand(['getent','passwd',id ]).split(':')[0]
    final = []
    home = utils.runOsCommand(['lfs','quota','-hu',username.strip(),'/home'])
    #scratch = runOsCommand(['sudo','lfs','quota','-hu',username,'/scratch'])
    one = home.split('\n')
    two = one[1].split(' ')
    while '' in two:
        two.remove('')
    three = one[2].split(' ')
    while '' in three:
        three.remove('')
    mydict1 = {}
    mydict1['partition'] = three[0]
    mydict1['used'] = three[1]
    mydict1['quota'] = three[2]

    final.append(mydict1)
    #final.append(mydict2)
    return final




# /current-node-states endpoint data
def plotCurrentNodeStateCounts():
    state_nodecounts = []
    node_states = server_info()['node_states']
    #node_states = node_states_str.split(',')
    for ns in node_states:
        temp = {}
        #state,count = ns.split(':')
        count = node_states[ns]
        state = ns
        temp['name'] = state
        temp['value'] = count    
        temp['total'] = chakshu_conf.TOTAL_NODES
        state_nodecounts.append(temp)
    return state_nodecounts
    

# /nodes-cpu-mem-util endpoint data
def node_cpu_mem_utilization():
    unwanted_states = utils.UNWANTED_STATES
    nodes_utilization = []
    nodelist = list(db.nodes.find({}, {'_id':False, 'hostname':True, 'state':True}))
    for node in nodelist:
        temp_dict = { "node" : node['hostname'] }
        try:
            if node['state'] in unwanted_states:
                temp_dict['cpu'] = 0.0
                temp_dict['memory'] = 0.0
            else:
                temp_dict['cpu'] = utils.get_cpu_percent(node['hostname'])
                temp_dict['memory'] = utils.get_memory_percent(node['hostname'])
            nodes_utilization.append(temp_dict)
        except Exception as e:
            temp_dict['cpu'] = 0.0
            temp_dict['memory'] = 0.0
            nodes_utilization.append(temp_dict)
            logger.error(e)
    return nodes_utilization
            



# /plotloadavg/ endpoint data
def get_agg_loadavg_data():
    loadavgdata = []
    try:
        data = list(db.general_info.find({},{'_id':0, 'timestamp':1,'avg_load':1}, limit=240).sort('_id', DESCENDING))
        for d in data:
            loads = d['avg_load']
            temp = {
                'timestamp' : d['timestamp'].strftime("%Y-%m-%dT%H:%M:%S%Z"),
                'load1' : loads['load1'],
                'load5' : loads['load5'],
                'load15' : loads['load15']
            }
            loadavgdata.append(temp)
        return sorted(loadavgdata, key=lambda i: i['timestamp'])
    except Exception as e:
        logger.error(e)



def parseBracketSwitches(bracket):
    switchlist = []
    strings = bracket.split('(')
    swtype = strings[0]
    ranges = strings[1]
    ranges = ranges.replace(")","")
    if "," in ranges:
        ranges = ranges.split(",")
        for rng in ranges:
            if '-' in rng:
                start, end  = rng.split('-')
                start = int(start)
                end = int(end)
                for switch in range(start, end+1):
                    switch = swtype + str(switch)
                    switchlist.append(switch)
            else:
                switchlist.append(swtype+rng)
    if '-' in ranges:
        start, end  = ranges.split('-')
        start = int(start)
        end = int(end)
        for switch in range(start, end+1):
            switch = swtype + str(switch)
            switchlist.append(switch)
    return switchlist

def parseSwitchlists(swrange):
    switchlist = []
    ranges = None
    switches = swrange
    switches = switches.replace("[","(")
    switches = switches.replace("]",")")
    if ',' in switches:
        ranges = re.split(r',\s*(?![^()]*\))', switches)
        for a_range in ranges:
            if '(' in a_range:
                switchlist = switchlist + parseBracketSwitches(a_range)
            else:
                switchlist.append(a_range)
    else:
        if '(' in switches:
            switchlist = switchlist + parseBracketSwitches(switches)
        else:
            switchlist.append(switches)
    return switchlist


def getIbTopologyData():
    data = {}
    l2switches = []
    l1switches = []
    nodelist = []
    cmd1 = "cat /home/cadmin/iblatest | grep -e 'SwitchName=.*Switches=' | awk '{print$1}' | awk -F \"=\" '{print$2}'"
    cmd2 = "cat /home/cadmin/iblatest | grep -e 'SwitchName=.*Switches='| awk '{print$2}' | awk -F \"=\" '{print$2}'"
    cmd3 = "cat /home/cadmin/iblatest | grep -e 'SwitchName=.*Nodes='| awk '{print$2}' | awk -F \"=\" '{print$2}'"

    l1swrange = utils.runStringCommand(cmd2).split("\n")[0].strip()
    l1switches = parseSwitchlists(l1swrange)

    swlist = utils.runStringCommand(cmd1).split("\n")
    for sw in swlist:
        if not sw:
            continue
        l2switches.append(sw.strip())

    nodes = utils.runStringCommand(cmd3).split("\n")
    for node in nodes:
        if not node:
            continue
        nodelist.append(node.strip())

    data['l1switches'] = l1switches
    data['l2switches'] = l2switches
    data["nodeslist"] = nodelist
    return data


