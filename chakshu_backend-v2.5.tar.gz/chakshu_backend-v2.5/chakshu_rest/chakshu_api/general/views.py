from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics
from datetime import datetime, timedelta, time
from django.db.models import *
from rest_framework.permissions import AllowAny, IsAuthenticated

import common_utilities as utils
from job_details.models import SlurmJobTable
from .utilities import *

class getGeneralInfoView(APIView):
    '''
        Information at a glance of a selected cluster.
        Like average measure of important HPC system metrics(cpu, memory, etc).
    '''
    permission_classes = (AllowAny,)
    authentication_classes = ()

    def get(self, request):
        return Response(get_general_data())


class DiskPartitionView(APIView):
    '''
        Prodvide Disk partitions info (/home, /scratch, etc).
    '''
    permission_classes = (AllowAny,)
    authentication_classes = ()

    def get(self, request):
        return Response(disk_partition_usage())


class getClusterStats(APIView):
    permission_classes = (AllowAny,)
    authentication_classes = ()

    def get(self, request):
        stats_dict = {}

        totalJobs = SlurmJobTable.objects.count()
        stats_dict["JobsTotal"] = totalJobs

        successfully_completed = SlurmJobTable.objects.filter(Q(exit_code=0)).count()
        stats_dict["SuccessJobs"] = successfully_completed

        nodesallocated = SlurmJobTable.objects.aggregate(Sum('nodes_alloc'))
        stats_dict["total_nodes_allocated"] = nodesallocated["nodes_alloc__sum"]
        TotTime = SlurmJobTable.objects.filter(Q(state=3) | Q(state=5)).filter(time_start__lte=F('time_end')).filter(Q(state=3) | Q(
            state=5)).filter(~Q(time_start=0)).annotate(timespent=F('time_end')-F('time_start')).aggregate(Sum('timespent'))
        stats_dict["TotTime"] = sectohourMinSec(TotTime["timespent__sum"])
        return Response(stats_dict)


class ServerInfoView(APIView):
    permission_classes = (AllowAny,)
    authentication_classes = ()
    
    def get(self, request):
        return Response(server_info())


class SystemInfoView(APIView):
    def get(self, request):
        return Response(system_info())


class ReservationInfoView(APIView):
    def get(self, request):
        return Response(getReservations())


class PlotLoadAvg(APIView):
    def get(self, request):
        return Response(get_agg_loadavg_data())


class UpTimeView(APIView):
    def get(self, request):
        return Response(getUptime())


class UserClusterStatsView(APIView):

    def get(self, request, userid=None):

        #userid = self.kwargs('userid')
        stats_dict = {}
        queryset = SlurmJobTable.objects.all().filter(id_user=userid)

        totalJobs = len(queryset)
        stats_dict["JobsTotal"] = totalJobs

        successfully_completed = len(queryset.filter(Q(state=3) | Q(state=5)))
        stats_dict["SuccessJobs"] = successfully_completed

        nodesallocated = queryset.filter(
            Q(state=3) | Q(state=5)).aggregate(Sum('nodes_alloc'))
        stats_dict["total_nodes_allocated"] = nodesallocated["nodes_alloc__sum"]
        TotTime = queryset.filter(Q(state=3) | Q(state=5)).filter(time_start__lte=F('time_end')).filter(Q(state=3) | Q(
            state=5)).filter(~Q(time_start=0)).annotate(timespent=F('time_end')-F('time_start')).aggregate(Sum('timespent'))
        stats_dict["TotTime"] = sectohourMinSec(TotTime["timespent__sum"])
        return Response(stats_dict)


class UserpartitionUsageApiView(APIView):

    def get(self, request, userid=None):
        # Note the use of `get_queryset()` instead of `self.queryset`

        #userid = self.kwargs['userid']
        todays_date = datetime.today().replace(hour=0, minute=0, second=0)

        todays_date = datetime.combine(todays_date, time.max)
        last_day = todays_date - timedelta(days=30)

        till_day = int(todays_date.strftime('%s'))
        since_day = int(last_day.strftime('%s'))

        from django.db.models.functions import Extract
        from django.db.models.expressions import RawSQL

        queryset = SlurmJobTable.objects.filter(time_start__range=(since_day, till_day), id_user=userid).annotate(
            date=RawSQL('DATE(FROM_UNIXTIME(time_start))', [])).values('date', 'partition').annotate(jobs=Count('id_job'))

        # print "--------",queryset
        #serializer_class = CpuUsageSerializer

        typedict = {}

        mylist = []

        blamap = {"HAHA": "HUHU", "BLA": ["BLAAAA"]}
        _type = {"name": blamap}
        series = {"Bla": "Bla"}

        mylist.append(_type)
        mylist.append(series)

        for query in queryset:
            partition = query["partition"]
            if len(partition.strip()) > 0 and partition not in typedict:
                typedict[partition] = 0

        external_list = []
        for type in typedict:
            resultmap = {}
            resultmap["name"] = type
            _list = []
            for query in queryset:
                if query["partition"].strip() == type:
                    internal_map = {}
                    internal_map["name"] = query["date"]
                    internal_map["value"] = query["jobs"]
                    _list.append(internal_map)

            resultmap["series"] = _list
            external_list.append(resultmap)

        # print "--------------",typedict
        return Response(external_list)


class UserQuotaView(APIView):
    def get(self, request, userid):
        return Response(getUserQuota(userid))

class PlotCurrentNodeStateCountView(APIView):
    def get(self, request):
        return Response(plotCurrentNodeStateCounts())

class DummyRackdataView(APIView):
    def get(self, request):
        return Response(dummyRackData())
        
class TotalUsersView(APIView):
    def get(self, request):
        return Response({"total_users" : len(utils.getUsersList())})
        
class NodeCpuMemUtilView(APIView):
    def get(self, request):
        return Response(node_cpu_mem_utilization())
        
class ClusterLoadAvgView(APIView):
    def get(self, request):
        return Response(getClusterLoadAvg())


class ChakshuEnvVarView(APIView):
    def get(self, request):
        return Response(utils.getChakshuEnvVars())

class IbTopologyInfoView(APIView):
    def get(self, request):
        return Response(getIbTopologyData())


################# DEPRECATED Views ###################

# class LoadStatsApiView(generics.ListAPIView):
#     serializer_class = LoadStatsSerializer
#     def get_queryset(self):
#         return Nodestats.objects.all()
 
