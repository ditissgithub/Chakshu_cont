from django.apps import AppConfig


class JobDetailsConfig(AppConfig):
    name = 'job_details'
