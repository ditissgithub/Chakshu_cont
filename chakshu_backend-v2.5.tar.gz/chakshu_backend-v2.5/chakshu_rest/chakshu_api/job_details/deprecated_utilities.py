import json
from chakshu_api import settings


chakshu_conf = chakshu_conf = settings.chakshu_conf
DATA_DIR = chakshu_conf.CHAKSHU_DATA_DIR


####################### DEPRECATED METHODS ####################
# get_job_utilization() 
def getJobUtilizations(node):
    try:
        with open(DATA_DIR + node +'/job_details.json') as file:job_utilization = json.load(file)
        return job_utilization
    except Exception as e:
        print(e)
################################################################
