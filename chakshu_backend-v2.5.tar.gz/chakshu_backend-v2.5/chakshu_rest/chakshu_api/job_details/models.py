from django.db import models
from enum import Enum

from chakshu_api import settings
# Assigned chakshu configs and logger
chakshu_conf = settings.chakshu_conf

table_prefix = chakshu_conf.DB_TABLE_PREFIX


class JobState(Enum):
    PENDING = 0
    RUNNING = 1
    COMPLETED = 3
    CANCELLED = 4
    FAILED = 5
    TIMEOUT = 6


class SlurmJobTable(models.Model):
    job_db_inx = models.BigAutoField(primary_key=True)
    mod_time = models.BigIntegerField()
    deleted = models.IntegerField()
    account = models.TextField(blank=True, null=True)
    admin_comment = models.TextField(blank=True, null=True)
    array_task_str = models.TextField(blank=True, null=True)
    array_max_tasks = models.PositiveIntegerField()
    array_task_pending = models.PositiveIntegerField()
    constraints = models.TextField(blank=True, null=True)
    cpus_req = models.PositiveIntegerField()
    derived_ec = models.PositiveIntegerField()
    derived_es = models.TextField(blank=True, null=True)
    exit_code = models.PositiveIntegerField()
    flags = models.PositiveIntegerField()
    job_name = models.TextField()
    id_assoc = models.PositiveIntegerField()
    id_array_job = models.PositiveIntegerField()
    id_array_task = models.PositiveIntegerField()
    id_block = models.TextField(blank=True, null=True)
    id_job = models.PositiveIntegerField()
    id_qos = models.PositiveIntegerField()
    id_resv = models.PositiveIntegerField()
    id_wckey = models.PositiveIntegerField()
    id_user = models.PositiveIntegerField()
    id_group = models.PositiveIntegerField()
    kill_requid = models.IntegerField()
    state_reason_prev = models.PositiveIntegerField()
    mcs_label = models.TextField(blank=True, null=True)
    mem_req = models.BigIntegerField()
    nodelist = models.TextField(blank=True, null=True)
    nodes_alloc = models.PositiveIntegerField()
    node_inx = models.TextField(blank=True, null=True)
    partition = models.TextField()
    priority = models.PositiveIntegerField()
    state = models.PositiveIntegerField()
    timelimit = models.PositiveIntegerField()
    time_submit = models.BigIntegerField()
    time_eligible = models.BigIntegerField()
    time_start = models.BigIntegerField()
    time_end = models.BigIntegerField()
    time_suspended = models.BigIntegerField()
    gres_req = models.TextField()
    gres_alloc = models.TextField()
    gres_used = models.TextField()
    wckey = models.TextField()
    work_dir = models.TextField()
    system_comment = models.TextField(blank=True, null=True)
    track_steps = models.IntegerField()
    tres_alloc = models.TextField()
    tres_req = models.TextField()

    class Meta:
        managed = False
        db_table = table_prefix + '_job_table'
        unique_together = (('id_job', 'time_submit'),)

    def save(self, *args, **kwargs):
        return

    def delete(self, *args, **kwargs):
        return
