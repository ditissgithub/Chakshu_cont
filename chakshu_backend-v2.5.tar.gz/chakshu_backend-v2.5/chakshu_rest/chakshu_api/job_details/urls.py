from django.urls import path

from .views import (
    RunningJobsListApiView,
    JobDetailsView,
    SelectAllJobListApiView,
    UserRunningJobsListApiView,
    SelectedStateUserJobList,
    UserJobWithAllocNodesView,
    CompletedJobStatsView,
)

urlpatterns = [
    path('jobs/running/',  RunningJobsListApiView.as_view()),
    path('jobdetails/<int:id>/', JobDetailsView.as_view()),
    path('selectjobs/<str:state>/',  SelectAllJobListApiView.as_view()),
    path('selectuserjobs/', SelectedStateUserJobList.as_view()),
    path('userjobs/running/<int:userid>/', UserRunningJobsListApiView.as_view()),
    path('completed-job-stats/<int:jobid>/', CompletedJobStatsView.as_view()),
    path('user-jobs-alloc-nodes/<int:userid>/', UserJobWithAllocNodesView.as_view()),

    ## Unused endpoints
    # path('selectjobs/<int:id>/<str:state>/',  SelectedJobListApiView.as_view()),

]
