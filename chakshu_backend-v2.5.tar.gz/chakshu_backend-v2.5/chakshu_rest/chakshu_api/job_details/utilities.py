import common_utilities as utils
from node_details.utilities import all_nodes_quick_info
import json


from chakshu_api import settings
# Assigned chakshu configs and logger
chakshu_conf = settings.chakshu_conf
logger = settings.LOGGER

# Get database connection for operations
db = utils.get_mongodb_connecion()
from pymongo import DESCENDING





def getJobDetails(id):
    lines = utils.runStringCommand('scontrol show job ' + str(id))
    lines =  lines.split("\n")
    mylist = {}
    for l in lines:
        l = l.strip()
        if l == '' or 'Power' in l:
            continue
        if 'TRES' in l:
             mylist['TRES'] = str(l.split('=')[1:])
             continue
        if ' ' not in l:
             k,v = l.split('=')
             mylist[k] = v
             continue
        cols = l.split(' ')
        for c in cols:
            if '='in c:
                k,v = c.split('=')
                if k == 'CPUs/Task':
                    k = 'CPUTask'
                mylist[k] = v            
    return mylist


def jobStats(jobid):
    job_stat = {}
    cmd = "seff "+str(jobid)
    out = utils.runStringCommand(cmd)
    lines = out.split('\n')
    for l in lines:
        if l:
            k,v = l.split(': ')
            k = k.lower().replace(' ','_')
            job_stat[k] = v
    return job_stat

# Retrieve node memory info
def get_job_utilization(nodename):
    jobinfo = None
    result = db.job_utilizations.find({'node':nodename}, projection={'_id': False}, limit=1).sort('_id', DESCENDING)[0]
    if result:
        jobinfo = result['job_details']
    return jobinfo



def jobsWithNodeList(jobs):
    data = []
    allnodes = all_nodes_quick_info()
    for job in jobs:
        temp = {}
        details = getJobDetails(job['id_job'])
        temp['jobid'] = job['id_job']
        temp['jobname'] = job['job_name']
        nodelist = utils.parseNodelists([{"nodelist":job['nodelist']}])
        jobnodes = []
        job_util_aggr = {}
        job_util_aggr['avg_cpu'] = 0.0
        job_util_aggr['avg_memory'] = 0.0
        job_util_aggr['num_procs'] = 0
        job_util_aggr['num_threads'] = 0
        job_util_aggr['procs'] = []
        for node in allnodes:
             if any(n in node['hostname'] for n in nodelist):
                 n = {}
                 n['node'] = node['hostname']
                 n['state'] = node['state']
                 try:
                     # aggregating job utilization for node['host'] 
                     job_util = get_job_utilization(node['hostname'])
                     job_util_aggr['avg_cpu'] += job_util['cpupercent']
                     job_util_aggr['avg_memory'] += job_util['mempercent']
                     job_util_aggr['num_procs'] += job_util['num_procs']
                     job_util_aggr['num_threads'] += job_util['num_threads']

                     # merging process names without duplicating 
                     set1 = set(job_util_aggr['procs'])
                     set2 = set(job_util['procs'])
                     new_procs = set2 - set1
                     job_util_aggr['procs'] += list(new_procs)
                     n['temp'] = node['cpu_temp']
                     n['cpupercent'] = job_util['cpupercent'] #node['cpupercent']
                     jobnodes.append(n)
                 except Exception as e:
                     n['temp'] = 0.0
                     n['cpupercent'] = 0.0                     
                     jobnodes.append(n)
                     logger.error(e) 
        # combining data 
        temp['nodelist'] = jobnodes
        temp['state'] = job['status']
        temp['submit_time'] = details['SubmitTime']
        temp['start_time'] = details['StartTime']
        temp['command'] = details['Command']
        temp['cpus'] = details['NumCPUs']
        if 'StdErr' in details or 'StdOut' in details:
            temp['errfile'] = details['StdErr']
            temp['outfile'] = details['StdOut']
       
        # taking average for no of nodes allocated (cpu, memory only)
        job_util_aggr['avg_cpu'] /= len(nodelist)
        job_util_aggr['avg_memory'] /= len(nodelist)

        temp['aggr_jobutil'] = job_util_aggr
        data.append(temp)
    return data





