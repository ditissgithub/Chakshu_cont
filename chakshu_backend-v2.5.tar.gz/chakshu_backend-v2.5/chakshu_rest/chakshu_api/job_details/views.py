from django.shortcuts import render
from .utilities import * 
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics
from django.db.models import *

from .models import SlurmJobTable, JobState
from .serializers import SlurmJobTableSerializer


PD = JobState.PENDING.value
R = JobState.RUNNING.value
CD = JobState.COMPLETED.value
CA = JobState.CANCELLED.value
F = JobState.FAILED.value
TO = JobState.TIMEOUT.value


class RunningJobsListApiView(generics.ListAPIView):
    queryset = SlurmJobTable.objects.annotate(
        status=Case(When(state=3, then=Value('Completed')),
        When(state=5, then=Value('Failed')),
        When(state=1, then=Value('Running')),
        When(state=0, then=Value('Pending')),
        default=Value('Unknown'),
        output_field=CharField(),),).filter(status="Running")
    serializer_class = SlurmJobTableSerializer


class JobDetailsView(APIView):
    def get(self,request, id):
        return Response(getJobDetails(id))



class SelectAllJobListApiView(generics.ListAPIView):
        serializer_class = SlurmJobTableSerializer

        def get_queryset(self):
            state = self.kwargs['state']
            queryset = SlurmJobTable.objects.annotate(status=Case(When(state=3, then=Value('Completed')),When(state=0, then=Value('Pending')),When(state=5, then=Value('Failed')),When(state=4, then=Value('Failed')),When(state=1, then=Value('Running')),When(state=0, then=Value('Running')),default=Value('Unknown'),output_field=CharField(),),).filter(status=str(state))
            return queryset


class SelectedJobListApiView(generics.ListAPIView):
        serializer_class = SlurmJobTableSerializer
        def get_queryset(self):
                userid = self.kwargs['id']
                state = self.kwargs['state']
                if state == "Running":
                        serializer_class = SlurmJobTableSerializer
                        queryset = SlurmJobTable.objects.annotate(status=Case(
                            When(state=3, then=Value('Completed')),
                            When(state=0, then=Value('Pending')),
                            When(state=5, then=Value('Failed')),
                            When(state=4, then=Value('Failed')),
                            When(state=1, then=Value('Running')),
                            When(state=0, then=Value('Running')),
                            default=Value('Unknown'),output_field=CharField(),),).filter(status=str(state),id_user=userid)
                else:
                        queryset = SlurmJobTable.objects.annotate(status=Case(
                            When(state=3, then=Value('Completed')),
                            When(state=0, then=Value('Pending')),
                            When(state=5, then=Value('Failed')),
                            When(state=4, then=Value('Failed')),
                            When(state=1, then=Value('Running')),
                            When(state=0, then=Value('Running')),
                            default=Value('Unknown'),output_field=CharField(),),).filter(status=str(state),id_user=userid)
                return queryset

# Alternate method for SelectedJobListApiView
class SelectedStateUserJobList(APIView):
    def post(self, request):
        userid = request.data.get('userid')
        state =  request.data.get('state')
        jobs = SlurmJobTable.objects.annotate(status=Case(
            When(state=3, then=Value('Completed')),
            When(state=0, then=Value('Pending')),
            When(state=5, then=Value('Failed')),
            When(state=4, then=Value('Failed')),
            When(state=1, then=Value('Running')),
            When(state=0, then=Value('Running')),
            default=Value('Unknown'),
            output_field=CharField(),),).filter(status=str(state),id_user=userid)
        serializer = SlurmJobTableSerializer(jobs, many=True)
        return Response(serializer.data)


class UserRunningJobsListApiView(generics.ListAPIView):
    serializer_class = SlurmJobTableSerializer

    def get_queryset(self):
        userid = self.kwargs['userid']
        serializer = SlurmJobTable.objects.annotate(status=Case(When(state=3, then=Value('Completed')),When(state=5, then=Value('Failed')),When(state=1, then=Value('Running')),default=Value('Unknown'),output_field=CharField(),),).filter(status="Running",id_user=userid)
        return serializer
        
        
class UserJobWithAllocNodesView(APIView):

    def get(self, request, userid):
        jobs = SlurmJobTable.objects.annotate(status=Case(When(state=3, then=Value('Completed')),When(state=5, then=Value('Failed')),When(state=1, then=Value('Running')),default=Value('Unknown'),output_field=CharField(),),).filter(status="Running",id_user=userid)
        serializer = SlurmJobTableSerializer(jobs, many=True)
        data = jobsWithNodeList(serializer.data)
        return Response(data)


class CompletedJobStatsView(APIView):
    def get(self, request, jobid):
        return Response(jobStats(jobid))