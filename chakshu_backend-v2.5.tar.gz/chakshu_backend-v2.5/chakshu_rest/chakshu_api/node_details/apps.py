from django.apps import AppConfig


class NodeDetailsConfig(AppConfig):
    name = 'node_details'
