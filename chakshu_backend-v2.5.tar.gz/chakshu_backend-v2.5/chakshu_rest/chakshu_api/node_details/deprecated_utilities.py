import json
import datetime
import time
from datetime import timedelta
from pytz import timezone
import re
import os

import common_utilities as utils
from chakshu_api import settings
# Assigned chakshu configs and logger
chakshu_conf = settings.chakshu_conf


DATA_DIR = chakshu_conf.CHAKSHU_DATA_DIR
ipmi_net_id = chakshu_conf.IPMI_NETWORK_ID
ipmi_uname = chakshu_conf.__IPMI_USERNAME
ipmi_passwd = chakshu_conf.__IPMI_PASSWORD




# #################### DEPRECATED METHODS #######################

# not required
def getEntHosts():
    nodelist = []
    delim = "=="
    command = os.environ['HOSTS_CMD'] +" | awk '{print$1\"==\"$2}'"
    output = utils.runStringCommand(command)
    for line in output.split('\n'):
        if not line:
            continue
        ip, node = line.split('==')
        node = {"host": node.strip(), "ip": ip.strip()}
        nodelist.append(node)
    return sorted(nodelist, key=lambda i: i['host'])


# not required
def allNodesIpmiPowerStatus():
    try:
        with open(DATA_DIR + 'master/power_status.json') as file:nodes_power_info = json.load(file)
        return sorted(nodes_power_info, key=lambda i: i['host'])
    except:
        pass

#  all_nodes_quick_info()
def allNodesQuickInfo():
    unwanted_states = ['drain', 'maint', 'resv', 'down']
    nodes_info = getEntHosts()
    power_status = allNodesIpmiPowerStatus()
    resource_states = plotNodeState()
    for index in range(len(nodes_info)):
        node = nodes_info[index]['host']
        if power_status:
            nodes_info[index]["status"] = power_status[index]['power_status']
        else:
            nodes_info[index]["status"] = "Down"
        nodes_info[index]["state"] = resource_states[index]['name']
        nodeinfo = getnodeinfo(node)
        temp = cpuAvgTemp(node)
        if 'cpupercent' not in nodeinfo:
            cpu = 0.0
        else: 
            cpu = nodeinfo['cpupercent']
        if not temp:
            temp = 45.5

        #if ('down' in nodes_info[index]['state']) or ('drain'in nodes_info[index]['state']) or ('maint'in nodes_info[index]['state']) or ('resv'in nodes_info[index]['state']):
        if any(s in nodes_info[index]['state'] for s in unwanted_states):
            nodes_info[index]["cpupercent"] = 0.0
            nodes_info[index]["temp"] = 0
        else:
        	
            nodes_info[index]["cpupercent"] = cpu
            nodes_info[index]["temp"] = temp
    return nodes_info



def selectedNodesQuickInfo(status):
    allnodes = allNodesQuickInfo()
    sel_nodes_info = []
    for node in allnodes:
        if status in node['state']:
            sel_nodes_info.append(node)
    if status == 'all':
        return allnodes
    else:
        return sel_nodes_info


# unused
def singleNodeFpingStatus(hostname):
    command = "fping " + hostname
    output = utils.runStringCommand(command)
    if output == 1:
        return "Down"
    if 'is alive' in output:
        return "Up"
    else:
        return "Down"

# unused
def allNodesFpingStatus():
    all_nodes_status = []
    for node in getEntHosts():
        hostname = node['host']
        command = "fping " + hostname
        output = utils.runStringCommand(command)
        if output == 1:
            temp = {"host": hostname, "status": "Down"}
            all_nodes_status.append(temp)
            continue
        if 'is alive' in output:
            temp = {"host": hostname, "status": "Up"}
        else:
            temp = {"host": hostname, "status": "Down"}
        all_nodes_status.append(temp)
    return all_nodes_status


# unused endpoint data
def gpuUtilizations(node):
    with open(DATA_DIR + node + '/gpu_usage.json') as file:
        gpu_usage = json.load(file)
        return gpu_usage

# unsued
def getFanSpeeds():
    nodes_fanspeeds = []
    for node in getEntHosts():
        hostname = node['nodename']
        if 'gpu' in hostname:
            continue
        print(hostname)
        with open(DATA_DIR + hostname + '/fanspeeds.json') as file:
            host_data = json.loads(file.read())
            temp = {"host": hostname, "fans": host_data}
            nodes_fanspeeds.append(temp)
    return nodes_fanspeeds

# unused
def getChasisTemps():
    temperatures = []
    for node in getEntHosts():
        hostname = node['nodename']
        if 'gpu' in hostname:
            continue
        print(hostname)
        with open(DATA_DIR + hostname + '/chassis_temps.json') as file:
            host_data = json.loads(file.read())
            temp = {"host": hostname, "temperatures": host_data}
            temperatures.append(temp)
    return temperatures



# unused
def getNoOfCpuCores():
    cpus = chakshu_conf.CPU_CORES
    return cpus


# unused
def old_getUsersUtilizationStats(nodename, username):
    current_user_util = 0.0
    other_users_util = 0.0
    total_user_util = 0.0
    for proc in runningProcessInfo(nodename):
        if proc['username'] == username:
            current_user_util += proc["cpu_percent"]
        elif proc['username'] != username:
            other_users_util += proc["cpu_percent"]
        total_user_util += proc["cpu_percent"]
    return {"current": current_user_util, "others": other_users_util, "total": total_user_util}

# unused
def old_allocNodesUsersUtilStats(nodelists, username):
    cores = chakshu_conf.CPU_CORES
    alloc_nodes_users_util = []
    nodelist = utils.parseNodelists(nodelists)
    for node in nodelist:
        node_dict = {}
        utils_list = []
        node_dict["name"] = node
        data = getUsersUtilizationStats(node, username)
        utils_list.append({"name": "total", "value": round(data['total']/cores, 2) })
        utils_list.append({"name": username, "value": round(data['current']/cores, 2) })
        utils_list.append({"name": "others", "value": round(data['others']/cores, 2) })
        node_dict["series"] = utils_list
        alloc_nodes_users_util.append(node_dict)
    return alloc_nodes_users_util


# common_utilities.running_processes()
def runningProcessInfo(nodename):
    meminfo = []
    with open(DATA_DIR+nodename+'/running_proc.json') as f:
        data = json.load(f)

        for i in range(0, len(data)):
            mydict = {}
            mem_data = data[i]['memory_percent']
            temp = float(mem_data)
            float_mem = round(temp, 2)
            mydict['username'] = data[i]['username']
            mydict['name'] = data[i]['name']
            mydict['cpu_percent'] = data[i]['cpu_percent']
            mydict['memory_percent'] = float_mem
            mydict['status'] = data[i]['status']
            mydict['num_threads'] = data[i]['num_threads']
            mydict['pid'] = data[i]['pid']
            meminfo.append(mydict)
    return meminfo



def getUsersUtilizationStats(nodename, username):
    current_user_util = 0.0
    other_users_util = 0.0
    idle = 0.0
    for proc in runningProcessInfo(nodename):
        if proc['username'] == username:
            current_user_util += proc["cpu_percent"]
        elif proc['username'] != username:
            other_users_util += proc["cpu_percent"]
    return {"current": current_user_util, "others": other_users_util}

# alloc_nodes_users_utilization(nodelists, username))
def allocNodesUsersUtilStats(nodelists, username):
    cores = chakshu_conf.CPU_CORES
    alloc_nodes_users_util = []
    nodelist = utils.parseNodelists(nodelists)
    for node in nodelist:
        node_dict = {}
        utils_list = []
        node_dict["name"] = node
       	data = getUsersUtilizationStats(node, username)
        user_util = round(data['current']/cores, 2)
        others_util = round(data['others']/cores, 2)
        node_dict[username] = user_util
        node_dict["others"] = others_util
        node_dict["idle"] = round(100 - (user_util + others_util),2)
        alloc_nodes_users_util.append(node_dict)
    return alloc_nodes_users_util



# alloc_nodes_running_procs(nodelists)
def allocNodesRunningProcs(nodelists):
    alloc_nodes_procs = []
    nodelist = utils.parseNodelists(nodelists)
    for node in nodelist:
        sigle_node_proc = runningProcessInfo(node)
        temp = {"name": node, "procs": sorted(
            sigle_node_proc, key=lambda i: i['cpu_percent'], reverse=True)}
        alloc_nodes_procs.append(temp)
    return alloc_nodes_procs



# --------------------UNUSED: Methods to generate meaningfull data from config file-----------------

# Generated nodelist
def generateNodelist():
    cn_noderanges = chakshu_conf.CN_NODELIST
    gpu_noderanges = chakshu_conf.GPU_NODELIST
    final_nodelist = []
    cn_nodelist = splitNodeRanges(cn_noderanges, 'cn')
    gpu_nodelist = splitNodeRanges(gpu_noderanges, 'gpu')

    final_nodelist = cn_nodelist + gpu_nodelist
    return sorted(final_nodelist)


def splitNodeRanges(nodes, nodetype):
    nodelist = []
    noderanges = nodes.split(',')
    for noderange in noderanges:
        if '-' not in noderange:
            start = end = noderange
        else:
            start, end = noderange.split('-')
        digits = len(start)
        start = int(start)
        end = int(end)
        for node in range(start, end+1):
            if (node < 10 and digits == 2) or (node < 100 and digits == 3):
                node = nodetype + "0" + str(node)
            elif node < 10 and digits == 3:
                node = nodetype + "00" + str(node)
            else:
                node = nodetype + str(node)
            nodelist.append(node)
    return nodelist

# Generated ip list
def generateEthIPLists():
    eth_iplist = []
    eth_netwk_id = chakshu_conf.ETH_NETWORK_ID
    cn_ipranges = chakshu_conf.CN_IP_RANGE
    gpu_ipranges = chakshu_conf.GPU_IP_RANGE
    allnodes_ips = cn_ipranges + "," + gpu_ipranges

    eth_iplist = splitIPRanges(allnodes_ips, eth_netwk_id)
    return eth_iplist


def generateIpmiIPLists():
    ipmi_iplist = []
    ipmi_netwk_id = chakshu_conf.IPMI_NETWORK_ID
    cn_ipranges = chakshu_conf.CN_IP_RANGE
    gpu_ipranges = chakshu_conf.GPU_IP_RANGE
    allnodes_ips = cn_ipranges + "," + gpu_ipranges
    ipmi_iplist = splitIPRanges(allnodes_ips, ipmi_netwk_id)
    return ipmi_iplist


def splitIPRanges(hostids, netwk_id):
    iplist = []
    ipranges = hostids.split(',')
    for iprange in ipranges:
        if '-' not in iprange:
            start = end = iprange
        else:
            start, end = iprange.split('-')
        digits = len(start)
        start = int(start)
        end = int(end)
        for hostid in range(start, end+1):
            ip = netwk_id + "." + str(hostid)
            iplist.append(ip)
    return iplist


# --------------------------------------------------------------------------------------------- #


# unused
def getNodesList():
    findStart = False
    nodelist = []
    for line in utils.runOsCommand(["getent", "hosts"]).split("\n"):
        if findStart == True:
            node_arr = line.split("    ")
            nodenip = node_arr[0].strip()
            nodenames = node_arr[1]
            nodealias_length = 0
            isLeast = True
            lease = 0
            ifFirstiteration = True
            nodename = ""
            for nodealias in nodenames.split():
                if ifFirstiteration == True:
                    least = len(nodealias)
                    nodename = nodealias
                    ifFirstiteration = False
                nodealias_length = len(nodealias)
                if nodealias_length < least:
                    least = nodealias_length
                    nodename = nodealias
            if "ib" not in nodename:
                nodelist.append(nodename)

        # if(startingips in line):
        #     findStart = True
    return nodelist

# unused
def getNodeStateInfo():
    node_state = {}
    node_partition = {}
    outArr = utils.runOsCommand(["sinfo", "-N"]).split("\n")
    for nodeinfo in outArr:
        splitArr = nodeinfo.split()
        node_state[splitArr[0].strip()] = splitArr[3].strip()
        node_partition[splitArr[0].strip()] = splitArr[2].strip()
    node_state["master"] = "N/A"
    node_partition["master"] = "N/A"
    return node_state, node_partition


# not required
def getNodeList():
    lines = utils.runOsCommand(['sinfo', '-N'])
    one = lines.split('\n')
    mylist = []
    final = []
    for i in range(1, len(one)):
        two = one[i].split(' ')

        while '' in two:
            two.remove('')
        if two[0] not in mylist:
            mylist.append(two[0])
    return mylist

# not required
def getNodeCpuMemUtil():
    nodelist = getNodeList()
    cpulist = []
    memlist = []
    final = []
    for nodename in nodelist:
        cpudict = {}
        memdict = {}
        cpudict['name'] = nodename
        memdict['name'] = nodename
        nodeinfo = getnodeinfo(nodename)
        if 'cpupercent' not in nodeinfo:
            cpudict['value'] = 0.0
        else:
        	cpudict['value'] = nodeinfo['cpupercent']
        cpulist.append(cpudict)

        if 'mempercent' not in nodeinfo:
            memdict['value'] = 0.0                
        else:   
            memdict['value'] = nodeinfo['mempercent']
        memlist.append(memdict)

    final.append(cpulist)
    final.append(memlist)
    return final

# unused
def getLineChartNodeUtilData():
    data = getNodeCpuMemUtil()
    list1 = data[0]
    list2 = data[1]

    final = []
    mydict1 = {}
    mydict2 = {}

    mydict1['name'] = 'cpu'
    mydict1['series'] = list1

    mydict2['name'] = 'memory'
    mydict2['series'] = list2

    final.append(mydict1)
    final.append(mydict2)
    return final

# / not required
def getNodeStates():
    nodeName = list(utils.runStringCommand("sinfo -N | awk '{print $1}' | sed '1d'").split('\n'))
    nodeStatus = list(utils.runStringCommand("sinfo -N | awk '{print $4}' | sed '1d'").split('\n'))
    nodeNameStatus = []
    nodelist = []
    for i in range(len(nodeName)-1):
            temp = {}
            temp[nodeName[i]] = nodeStatus[i]
            nodeNameStatus.append(temp)
    seen = set()
    noDup = []
    for d in nodeNameStatus:
        t = tuple(d.items())
        if t not in seen:
            seen.add(t)
            noDup.append(d)
    for i,host in enumerate(noDup):
        for name, value in host.items():
    	    node = {}
    	    node['name'] = value
    	    node['value'] = name
    	    nodelist.append(node)
    return nodelist
# unused
def plotNodeState():
    #lines = utils.runOsCommand(['sinfo', '-N'])
    #one = lines.split('\n')
    #mylist = []
    #final = []
    #for i in range(1, len(one)):
    #    #print(one[i])
    #    two = one[i].split(' ')
    #    while '' in two:
    #        two.remove('')
    #    mydict = {}
    #    mydict['name'] = two[3]
    #    mydict['value'] = two[0]
    #    mylist.append(mydict)
    return getNodeStates()


# unused
def plotSelectedNodeState(state):
    list1 = plotNodeState()
    final = []
    for item in list1:
        mydict = {}
        if item['name'] == state or item['name'] == state+'*' or item['name'] == state+'$':
            mydict['name'] = item['name']
            mydict['value'] = item['value']
            final.append(mydict)
    if state == 'all':
        return list1
    else:
        return final


# node_load(nodename)
def nodeload(nodename):
    mydict = {}
    try:
    	with open(DATA_DIR+nodename+'/cpu_loadavg.json') as f:
        	data = json.load(f)
        	mydict = data[0]
        	return mydict
    except:
        pass

# unused
def getCpuTemp(nodename):
    with open(DATA_DIR+'master/clusterTemp.json') as f:data = json.load(f)
    for i in range(len(data)):
        if data[i]['name'] == nodename:
            return data[i]['value']

# not required
def getnodeinfo(nodename):
    mydict = {}
    final = []
    try:
        with open(DATA_DIR+nodename+'/mem_details.json') as f:data = json.load(f)
        mydict['available'] = round(data['available'],2)
        mydict['used'] = round(data['used'],2)
        mydict['total'] = round(data['total'],2)
        mydict['mempercent'] = data['percent']

        with open(DATA_DIR+nodename+'/cpu_percent.json') as f:data2 = json.load(f)
        mydict['cpupercent'] = data2['percentage']
    except:
        print(nodename, "error")
    return mydict

# cpu_avg_temp()
def cpuAvgTemp(nodename):
    try:
        with open(DATA_DIR+nodename+'/core_temp.json') as f:data = json.load(f)
        num = ((data[0][0]['Physical id 0'])+(data[1][0]['Physical id 1'])) / 2
        return num
    except:
        pass

# network_io()
def getNetworkIo(nodename):
    with open(DATA_DIR + nodename + '/net_io.json') as f:
        data = json.load(f)
        return data


# services_info()
def getServiceInfo(nodename):
    with open(DATA_DIR+nodename+'/services_status.json') as f:
        data = json.load(f)
        return data

# total_cpu_times_percentage()
def getCPUTime(nodename):
    cpuTime = []
    with open(DATA_DIR+nodename+'/cpu_total_util.json') as f:
        data = json.load(f)
        temp = data['cpu']

        for i in range(0, len(temp)):
            mydict = {}
            if temp[i]['name'] == 'user':
                mydict['name'] = 'user'
                mydict['value'] = temp[i]['value']
                cpuTime.append(mydict)
            if temp[i]['name'] == 'system':
                mydict['name'] = 'system'
                mydict['value'] = temp[i]['value']
                cpuTime.append(mydict)

            if temp[i]['name'] == 'idle':
                mydict['name'] = 'idle'
                mydict['value'] = temp[i]['value']
                cpuTime.append(mydict)
    return cpuTime


# disk_io()
def getDiskIo(nodename):

    with open(DATA_DIR+nodename+'/disk_io.json') as f:
        data = json.load(f)

        diskio = data[0]
        mylist = []
        mydict = {}
        mydict['read_count'] = diskio['read_count']
        mydict['write_count'] = diskio['write_count']
        mydict['read_bytes'] = diskio['read_bytes']
        mydict['write_bytes'] = diskio['write_bytes']
        mydict['read_time'] = diskio['read_time']
        mydict['write_time'] = diskio['write_time']

        return mydict

# gpu_cards_info()
def getGPUCardInfo(nodename):
    with open(DATA_DIR+nodename+'/gpu_info.json') as f:
        data = json.load(f)
        diskio = data
        final = []
        for item in diskio:
            mydict = {}
            mydict['id'] = item['id']
            mydict['display_active'] = item['display_active']
            mydict['name'] = item['name']
            mydict['memoryFree'] = item['memoryFree']
            mydict['memoryTotal'] = item['memoryTotal']
            mydict['memoryUtil'] = round(item['memoryUtil'], 2)
            final.append(mydict)
        return final


# unused
def old_getCoreUtilChartData(nodename):
    with open(DATA_DIR+nodename+'/cpu_core_util.json') as f:
        data = json.load(f)
        final = []
        coreutildata = data['multi']
        userdict = {}
        systemdict = {}
        idledict = {}

        userlist = []
        systemlist = []
        idlelist = []

        userdict['name'] = 'user'
        systemdict['name'] = 'system'
        idledict['name'] = 'idle'

        for item in coreutildata:
            usertempdict = {}
            systempdict = {}
            idletempdict = {}

            usertempdict['name'] = item['name']
            usertempdict['value'] = item['series'][0]['value']
            userlist.append(usertempdict)

            systempdict['name'] = item['name']
            systempdict['value'] = item['series'][1]['value']
            systemlist.append(systempdict)

            idletempdict['name'] = item['name']
            idletempdict['value'] = item['series'][2]['value']
            idlelist.append(idletempdict)

        userdict['series'] = userlist
        systemdict['series'] = systemlist
        idledict['series'] = idlelist

        final.append(userdict)
        final.append(systemdict)
        final.append(idledict)

        return final



# per_core_utilizations()        
def getCoreUtilChartData(nodename):
    with open(DATA_DIR+nodename+'/cpu_core_util.json') as f:data = json.load(f)
    final = []
    coreutildata = data['multi']
    for item in coreutildata:
        tempdict = {}
        tempdict['core'] = item['name']
        tempdict['user'] = item['series'][0]['value']
        tempdict['system'] = item['series'][1]['value']
        tempdict['idle'] = item['series'][2]['value']
        final.append(tempdict)
    return final


# Unused
def getRealTimeUtilizationData(nodename):
    data = getUserUtilization(nodename)
    length = len(data)
    final = []
    list1 = []
    list2 = []

    for i in range(0, 5):
        mydict1 = {}
        mydict2 = {}
        IST = timezone('Asia/Calcutta')
        ti = datetime.datetime.now(IST)
        two = str(ti).split('.')
        three = two[0].split(' ')
        mydict1['name'] = three[1]
        mydict1['value'] = data[2]['mempercent']
        list1.append(mydict1)
        mydict2['name'] = three[1]
        mydict2['value'] = data[2]['cpu']
        list2.append(mydict2)
        time.sleep(1)

    mydict_mem = {}
    mydict_cpu = {}

    mydict_mem['name'] = 'memory'
    mydict_mem['series'] = list1
    mydict_cpu['name'] = 'cpu'
    mydict_cpu['series'] = list2

    final.append(mydict_mem)
    final.append(mydict_cpu)

    return final

# Unused
def getParsedNodeList(nodelistToParse):
    check = nodelistToParse.split('],')
    if len(check) == 1:
        zero = nodelistToParse.split('[')
        nodelist = []
        if(len(zero) == 1):
            nodelist.append(zero[0])
        else:
            one = zero[1].split(',')
            length_1 = len(one)

            for i in range(0, length_1 - 1):
                check = one[i].split('-')
                if(len(check) == 1):
                    if int(check[0] < 10):
                        nodelist.append(zero[0]+"0"+check[0])
                    else:
                        nodelist.append(zero[0]+check[0])
                else:
                    num1 = check[0]
                    num2 = check[1]
                    for i in range(int(num1), int(num2)+1):
                        if i < 10:
                            nodelist.append(zero[0]+"0"+str(i))
                        else:
                            nodelist.append(zero[0]+str(i))

            five = one[length_1 - 1].split('-')
            three = []

            if len(five) == 1:
                three = one[length_1 - 1].split(']')
                nodelist.append(zero[0]+three[0])
            else:
                num1 = five[0]
                num2 = five[1].split(']')[0]
                for i in range(int(num1), int(num2)+1):
                    if i < 10:
                        nodelist.append(zero[0]+"0"+str(i))
                    else:
                        nodelist.append(zero[0]+str(i))

    else:
        nodelist = []
        one = nodelistToParse.split('],')
        if len(one) == 2:
            for i in range(0, len(one)):
                two = one[i].split('[')
                three = two[1].split(',')
            # if len(three) == 1:
            #     nodelist.append(two[0]+three[0])
                for j in range(0, len(three)):
                    four = three[j].split('-')
                    if len(four) == 1:
                        nodelist.append(two[0]+four[0])
                    else:
                        num1 = four[0]
                        num2 = four[1]
                        num3 = num2.split(']')
                        num2 = num3[0]
                        for k in range(int(num1), int(num2)+1):
                            if k < 10:
                                nodelist.append(two[0]+"0"+str(k))
                            else:
                                nodelist.append(two[0]+str(k))
    return nodelist


# user_processes(userid, nodename)
def getUserProcessList(id, nodename):
    with open(DATA_DIR + nodename+'/running_proc.json') as f:data = json.load(f)
    diskio = data
    final = []
    for i in range(len(diskio)):
        if diskio[i]['uids'][0] == int(id):
            diskio[i]['cpu_percent'] = round(diskio[i]['cpu_percent'], 2)
            diskio[i]['memory_percent'] = round(
                diskio[i]['memory_percent'], 2)
            final.append(diskio[i])
    return final


# user_node_utilizations()
def getUserUtilization(nodename):
    with open(DATA_DIR+nodename+'/running_proc.json') as f:data = json.load(f)
    processList = []
    userList = []
    final = []
    for i in range(0, len(data)):
        processList.append(data[i]['name'])
        userList.append(data[i]['username'])
    tempuser = getunique(userList)
    tempprocess = getunique(processList)

    for user in tempuser:
        #mydict = {}
        cpu = []
        mem = 0
        for process in tempprocess:
            cpupro = []
            mempro = 0
            mydict = {}
            for i in range(0, len(data)):
                if data[i]['username'] == user and data[i]['name'] == process:
                    mydict['username'] = data[i]['username']
                    mydict['process'] = data[i]['name']
                    mydict['uid'] = data[i]['uids'][0]

                    cpupro.append(data[i]['cpu_percent'])
                    mempro += data[i]['memory_percent']
            cpuavg = getcpuavg(cpupro)
            mydict['cpu'] = round(cpuavg, 2)

            memuse = round(getMemUse(mempro, nodename), 2)
            mydict['memgb'] = memuse
            mydict['mempercent'] = round(mempro, 2)
            final.append(mydict)
    return final
# not required
def getunique(elementList):
    unique = []
    for i in range(0, len(elementList)):
        if elementList[i] not in unique:
            unique.append(elementList[i])
    return unique
# not required
def getcpuavg(cpulist):
    total = 0
    for i in range(0, len(cpulist)):
        total += float(cpulist[i])
    retTotal = total / len(cpulist)
    return retTotal

# single_user_utilization(userid, nodename)
def getSingleUserUtilization(id, nodename):
    datalist = getUserUtilization(nodename)
    finalList = []
    for i in range(len(datalist)):
        if(datalist[i]['uid'] == int(id)):
            finalList.append(datalist[i])
    return finalList


# Unused


def getUserUtilChartData(id, nodename):
    data = getSingleUserUtilization(id, nodename)
    final = []

    for item in data:
        mydict1 = {}
        mydict2 = {}
        if item['cpu'] >= 0:
            mydict1['cpu'] = item['cpu']
        if item['mempercent'] >= 0:
            mydict1['mem'] = item['mempercent']
        if item['cpu'] >= 0 and item['mempercent'] >= 0:
            final.append(mydict1)
    return final




# def usersAllocNodesQuickInfo(alloc_nodes):
#     nodelist = []
#     allnodes = allNodesQuickInfo()
#     parsed_nodes = utils.parseNodelists(alloc_nodes)
#     for node in allnodes:
#         if any(n in node['host'] for n in parsed_nodes):
#             temp = {}
#             temp['node'] = node['host']
#             temp['state'] = node['state']
#             temp['temp'] = node['temp']
#             temp['cpupercent'] = node['cpupercent']
#             nodelist.append(temp)
#     return nodelist

# def splitNodelist(nodelist):
#     ranges = nodelist.split(',')
#     cn_ranges = None
#     gpu_ranges = None
#     for r in ranges:
#         if r.startswith('cn') and r.endswith(']'):
#             cn_ranges = r
#         elif r.startswith('gpu') and r.endswith(']'):
#             gpu_ranges = r
#     cnlist = parseNodelist(cn_ranges,'cn')
#     gpulist = parseNodelist(gpu_ranges, 'gpu')
#     allnodeslist = cnlist + gpulist
#     print(sorted(allnodeslist))

# def parseNodelist(nodelist, nodetype):
#     finallist = []
#     digits = 0;
#     print("Initial::-->", nodelist)
#     if '[' or ']' in nodelist:
#         nodelist.replace('[', '')
#         nodelist.replace(']', '')
#     print(nodelist)
#     nodelist = re.sub(r'[a-z]+', '', nodelist, re.I)
#     print("Hows that??-->",nodelist)
#     ranges = nodelist.split(',')
#     for r in ranges:
#         if '-' in r:
#             start,end = r.split('-')
#             digits = len(start)
#             print("Digits==",digits)
#             for i in range(int(start), int(end)+1):
#                 if i < 10 or (digits==3 and i<100 ):
#                     finallist.append( nodetype+'0'+str(i) )
#                 elif digits == 3 and i < 10:
#                     finallist.append( nodetype+'00'+str(i) )
#                 else:
#                     finallist.append( nodetype+str(i) )
#         else:
#             print('I was here too..!')
#             digits = len(r)
#             r = int(r)
#             if r < 10 or (digits==3 and r<100 ):
#                 finallist.append( nodetype+'0'+str(r) )
#             elif digits == 3 and r < 10:
#                 finallist.append( nodetype+'00'+str(r) )
#             else:
#                 finallist.append( nodetype+str(r) )
#     print('FINALLIST::-->', finallist)
################################################################
