from rest_framework import serializers



class IdleNodesSerializer(serializers.Serializer):
    Partition = serializers.CharField()
    Freenodes = serializers.CharField()
    Nodesname = serializers.CharField()
        

class NodesSerializer(serializers.Serializer):  
    NodeName = serializers.CharField()
    NodeType = serializers.CharField()  
    Partition = serializers.CharField()
    Status = serializers.CharField()


class UserNodesSerializer(serializers.Serializer):  
    nodelist = serializers.CharField()