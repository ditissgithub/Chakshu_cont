# deprecated utility methods
# from .deprecated_utilities import *

import common_utilities as utils
from chakshu_api import settings
# Assigned chakshu configs and logger
chakshu_conf = settings.chakshu_conf
logger = settings.LOGGER

# Get database connection for operations
db = utils.get_mongodb_connecion()

ipmi_uname = chakshu_conf.__IPMI_USERNAME
ipmi_passwd = chakshu_conf.__IPMI_PASSWORD

# /all-nodes-quick-info endpoint data
def all_nodes_quick_info():
    nodesinfo = []
    unwanted_states = utils.UNWANTED_STATES
    # db.nodes.find({}, { '_id':False, 'hostname':True, 'ip':True, 'power_status':True, 'state':True })) for all
    hosts = list(db.nodes.find({ 'hostname':{'$not': {'$regex':'^knl.*'} } }, { '_id':False, 'hostname':True, 'ip':True, 'power_status':True, 'state':True, 'ipmi_ip':True }))
    for host in hosts:
        nodename = host['hostname'] 
        try:
            if  any(s in host['state'] for s in unwanted_states):
                host['cpu_percent']  = 0.0
                host['cpu_temp'] = 0.0
            else:
                host['cpu_percent']  = utils.get_cpu_percent(nodename)
                host['cpu_temp'] = utils.get_temperature(nodename)
            nodesinfo.append(host)
        except Exception as e:
            host['cpu_percent']  = 0.0
            host['cpu_temp'] = 0.0
            nodesinfo.append(host)
            logger.error(e)
    return nodesinfo

# Called only when CLUSTER_NAME=sangam
def knl_nodes_quick_info():
    knlquickinfo =[]
    knlhosts = list(db.nodes.find({ 'hostname':{'$regex':'^knl.*'} }, { '_id':False, 'hostname':True, 'ip':True, 'power_status':True, 'state':True }))
    for host in knlhosts:
        host['cpu_percent']  = 0.0
        host['cpu_temp'] = 0.0
        knlquickinfo.append(host)
    return knlquickinfo

# selected-nodes-quick-info/ endpoint data
def selected_state_nodes_quick_info(state):
    allnodesinfo = all_nodes_quick_info()
    state_nodesinfo = []
    for node in allnodesinfo:
        if state in node['state']:
            state_nodesinfo.append(node)
    if state == 'all':
        return allnodesinfo
    else:
        return state_nodesinfo


# identify-chassis/ endpoint data
def identifyTheChassis(ipmi_ip):
    interval = 60
    command = "ipmitool -H "+ipmi_ip + \
        " -U "+ipmi_uname+" -P "+ipmi_passwd+" chassis identify "+str(interval)
    out = utils.runStringCommand(command)
    if out == 1:
        return {"status": "error"}
    else:
        return {"status": "ok", "interval": interval}

# chassis-identify-status/ endpoint data
def getChassisIdentifyStatus(ipmi_ip):
    status = ''
    command = "ipmitool -H "+ipmi_ip + \
        " -U "+ipmi_uname+" -P "+ipmi_passwd+" chassis status | grep -i identify"
    out = utils.runStringCommand(command)
    if out == 1:
        status = 'error'
    else:
        k, v = out.split(':')
        if ('off' or 'Off') in v:
            status = 'off'
        else:
            status = 'on'
    return {"status": status}



# alloc-node-users-util/ endpoint data
def users_node_utilization(nodename, username):
    node_procs = None
    try:
        node_procs = utils.running_processes(nodename)
        users_total_utilization = { username:0.0, "others":0.0 }
        for proc in node_procs:
            if username in proc['username']:
                users_total_utilization[username] += proc['cpu_percent']
            else:
                users_total_utilization['others'] += proc['cpu_percent']
        return users_total_utilization
    except Exception as e:
        logger.error(e)

def alloc_nodes_users_utilization( nodelists, username ):
    cpu_cores = chakshu_conf.CPU_CORES
    alloc_nodes_users_utils = []
    parsed_nodelist = utils.parseNodelists(nodelists)
    for nodename in parsed_nodelist:
        users_util = users_node_utilization(nodename, username)
        temp = {"name" : nodename}
        if users_util is None:
            continue
        temp[username] = round( users_util[username]/cpu_cores, 2 )
        temp['others'] = round( users_util['others']/cpu_cores, 2 )
        temp['idle'] = round(100 - (temp[username] + temp['others']),2)
        alloc_nodes_users_utils.append(temp)
    return alloc_nodes_users_utils


# alloc-node-procs/ endpoint data
def alloc_nodes_running_procs(nodelists):
    nodelist = utils.parseNodelists(nodelists)
    alloc_nodes_procs = []
    for nodename in nodelist:
        node_procs = None
        try:
            node_procs = utils.running_processes(nodename)
        except Exception as e:
            logger.error(e)
        if node_procs is None:
            continue
        node_procs = sorted( node_procs, key=lambda i: i['cpu_percent'], reverse=True )
        alloc_nodes_procs.append({
            "name" : nodename,
            "procs" : node_procs
        })
    return alloc_nodes_procs


# getnodeload/ endpoint data
def node_load(nodename):
    try:
        loads = utils.get_loads(nodename)
        return loads
    except Exception as e:
        logger.error(e)

# nodeinfo/ ednpoint data
def node_info(nodename):
    node_info = None
    try:
        meminfo = utils.get_memory_info(nodename)
        node_info = {
            'cpupercent' : utils.get_cpu_percent(nodename),
            'mempercent' : meminfo['percent'],
            'total' : round(meminfo['total'],2),
            'used' : round(meminfo['used'],2),
            'available' : round(meminfo['available'],2)
        }
        return node_info
    except Exception as e:
        logger.error(e)


# cputemp/ endpoint data
def cpu_avg_temp(nodename):
    try:
        return utils.get_temperature(nodename)
    except Exception as e:
        logger.error(e)

# networkio/ endpoint data
def network_io(nodename):
    try:
        return utils.get_network_io(nodename)
    except Exception as e:
        logger.error(e)

# serviceinfo/ endpoint data
def services_info(nodename):
    try:
        return utils.get_service_info(nodename)
    except Exception as e:
        logger.error(e)

# cputime/ endpoint data
def total_cpu_times_percentage(nodename):
    totalcputime = []
    try:
        result =  utils.get_total_cpu_times(nodename)
        for key in result:
            totalcputime.append( {'name':key, 'value':result[key]} )
        return totalcputime
    except Exception as e:
        logger.error(e)

# diskio/ endpoint data
def disk_io(nodename):
    try:
        return utils.get_diskio_info(nodename)
    except Exception as e:
        logger.error(e)

# gpuinfo/ endpoint data
def gpu_cards_info(nodename):
    try:
        return utils.get_gpu_info(nodename)
    except Exception as e:
        logger.error(e)


# coreutilchartdata/ endpoint data
def per_core_utilizations(nodename):
    try:
        return utils.get_per_core_utilizations(nodename)    
    except Exception as e:
        logger.error(e)


# userprocesslist/<int:id>/<str:nodename>/ endpoint data
def user_processes(userid, nodename):
    try:
        node_procs = utils.running_processes(nodename)
        username = utils.get_user_info(userid)['username']
        user_processes = []
        for process in node_procs:
            if username == process['username']:
                process['cpu_percent'] = round( process['cpu_percent'], 2 )
                process['memory_percent'] = round( process['memory_percent'], 2 )
                user_processes.append(process)
        return user_processes
    except Exception as e:
        logger.error(e)

# userwiseutil/<str:nodename>/ endpoint data
def user_node_utilizations(nodename):
    try:
        user_utilz = []
        node_procs = utils.running_processes(nodename)
        procs_names = set( [p['name'] for p in node_procs] )
        usernames = set( [p['username'] for p in node_procs] )
        for uname in usernames:
            for pname in procs_names:
                cputotal = 0.0
                memtotal = 0.0
                tempdict = {}
                proc_cnt = 0
                for proc in node_procs:
                    if proc['username'] in uname and proc['name'] in pname:
                        proc_cnt += 1
                        tempdict['username'] = uname
                        tempdict['process'] = pname
                        cputotal += proc['cpu_percent']
                        memtotal += proc['memory_percent']
                tempdict['cpu'] = round( cputotal/proc_cnt, 2)
                tempdict['mempercent'] = round( memtotal/proc_cnt, 2)
                tempdict['memgb'] = round( getMemUse(tempdict['mempercent'], nodename) , 2)
                user_utilz.append(tempdict)
        return user_utilz
    except Exception as e:
        logger.error(e)

def getMemUse(mempercent, nodename):
    try:
        total_nodemem = utils.get_memory_info(nodename)['total']
        retMem = (mempercent / 100) * float(total_nodemem)
        return retMem
    except Exception as e:
        logger.error(e)
    

# singleuserprocessutil/<int:id>/<str:nodename>/ endpoint data
def single_user_utilization(userid, nodename):
    try:
        user_util =[]
        alluserutil = user_node_utilizations(nodename)
        username = utils.get_user_info(userid)['username']
        for util in alluserutil:
            if  username in util['username']:
                user_util.append(util)
        return user_util
    except Exception as e:
        logger.error(e)


def nodes_power_status():
    cpu = []
    gpu = []
    hm = []
    nodes = list(db.nodes.find({ 'hostname':{'$not': {'$regex':'^knl.*'} } }, { '_id':False, 'hostname':True, 'power_status':True, 'state':True }))
    for node in nodes:
        value = 50
        if node['power_status'] == 'Up':
            value = 100 
        node['value'] = value
        if 'cn' in node['hostname']:
            cpu.append(node)
        elif 'gpu' in node['hostname']:
            gpu.append(node)
        elif 'hm' in node['hostname']:
            hm.append(node)
    return { 'cpu_nodes' : cpu, 'gpu_nodes':gpu, 'hm_nodes':hm }

