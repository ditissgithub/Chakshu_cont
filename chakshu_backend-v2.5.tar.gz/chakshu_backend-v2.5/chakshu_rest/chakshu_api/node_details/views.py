from .utilities import * 
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics
from django.db.models import *

from job_details.serializers import SlurmJobTableSerializer
from job_details.models import SlurmJobTable
from .serializers import UserNodesSerializer
import common_utilities as utils
from rest_framework.permissions import AllowAny




class AllNodesQuickInfoView(APIView):
    permission_classes = (AllowAny,)
    authentication_classes = ()
    
    def get(self,request):
        return Response(all_nodes_quick_info())

class SelectedNodesQuickInfoView(APIView):
    def get(self, request, state):
        return Response(selected_state_nodes_quick_info(state))
    

class AllocNodeUsersUtilView(APIView):
    def post(self, request, username):
        nodelist = request.data
        return Response( alloc_nodes_users_utilization(nodelist, username) )



class LoadNodeView(APIView):
    def get(self,request,nodename):
        result =  node_load(nodename)
        if result is None:
            return Response({ "message" : "error" })
        return Response(result)

class CPUAvgTempView(APIView):
    def get(self,request,nodename):
        return Response({ "temp" : cpu_avg_temp(nodename)})


class NodeInfoView(APIView):
    def get(self,request,nodename):
        return Response(node_info(nodename))


class RunningProcessView(APIView):
    def get(self,request,nodename):
        return Response(utils.running_processes(nodename))

class AllocNodesRunningProcessView(APIView):
    def post(self,request):
        nodelist = request.data
        return Response(alloc_nodes_running_procs(nodelist))


class UserWiseUtilization(APIView):
        def get(self,request,nodename):
                return Response(user_node_utilizations(nodename))


class ChassisIdentificationView(APIView):
        def get(self, request, ip):
                return Response(identifyTheChassis(ip))

class ChassisIdentificationStatusView(APIView):
        def get(self, request, ip):
                return Response(getChassisIdentifyStatus(ip))



class NodeJobsListApiView(generics.ListAPIView):
    serializer_class = SlurmJobTableSerializer

    def get_queryset(self):
        nodename = self.kwargs['nodename']
        queryset = SlurmJobTable.objects.annotate(status=Case(
            When(state=3, then=Value('Completed')),
            When(state=5, then=Value('Failed')),
            When(state=1, then=Value('Running')),
            default=Value('Unknown'),output_field=CharField(),),).filter(status="Running")
        toreturn  = []
        
        for query in queryset:
            utnodelist = []
            utnodelist = utils.parseNodelists( [{"nodelist":query.nodelist}])
            if nodename in utnodelist:
                toreturn.append(query.id_job)
                                                
        return SlurmJobTable.objects.filter(id_job__in = toreturn).annotate(status=Case(
            When(state=3, then=Value('Completed')),
            When(state=5, then=Value('Failed')),
            When(state=1, then=Value('Running')),
            default=Value('Unknown'),output_field=CharField(),),).filter(status="Running")
            

class NetworkIoView(APIView):
    def get(self,request,nodename):
        return Response(network_io(nodename))


class ServiceInfoView(APIView):
    def get(self,request,nodename):
        return Response(services_info(nodename))

class CPUTimeView(APIView):
    def get(self,request,nodename):
        return Response(total_cpu_times_percentage(nodename))

class DiskIOView(APIView):
    def get(self,request,nodename):
        result =  disk_io(nodename)
        if result is None:
            return Response({ "message" : "error" })
        return Response(result)

class GPUInfoView(APIView):
    def get(self,request,nodename):
        return Response(gpu_cards_info(nodename))

class CoreUtilChartView(APIView):
    def get(self,request,nodename):
        return Response(per_core_utilizations(nodename))



class UserNodesView(generics.ListAPIView):
    serializer_class = UserNodesSerializer

    def get_queryset(self):
        userid = self.kwargs['userid']
        serializer = SlurmJobTable.objects.annotate(status=Case(When(state=3, then=Value('Completed')),When(state=5, then=Value('Failed')),When(state=1, then=Value('Running')),default=Value('Unknown'),output_field=CharField(),),).filter(status="Running",id_user=userid)
        return serializer



class ParsedNodesView(APIView):
    def post(self,request):
        final = []
        nodelist = request.data
        final = utils.parseNodelists(nodelist)
        result = []
        for i in range(0,len(final)):
            mydict = {}
            mydict['name'] = "alloc"
            mydict['value'] = final[i]
            result.append(mydict)
        return Response(result)



class UserProcessListApi(APIView):
    def get(self,request,id,nodename):
        return Response(user_processes(id,nodename))

class SingleUserUtilization(APIView):
    def get(self,request,id,nodename):
        return Response(single_user_utilization(id,nodename))


class UserNodeJobsListApiView(generics.ListAPIView):
    serializer_class = SlurmJobTableSerializer

    def get_queryset(self):
        nodename = self.kwargs['nodename']
        id = self.kwargs['id']
        queryset = SlurmJobTable.objects.annotate(status=Case(When(state=3, then=Value('Completed')),When(state=5, then=Value('Failed')),When(state=1, then=Value('Running')),default=Value('Unknown'),output_field=CharField(),),).filter(status="Running")
        toreturn  = []
        for query in queryset:
            utnodelist = []
            utnodelist = utils.parseNodelists( [{"nodelist":query.nodelist}])
            if nodename in utnodelist:
                toreturn.append(query.id_job)
        return SlurmJobTable.objects.filter(id_job__in = toreturn).annotate(status=Case(When(state=3, then=Value('Completed')),When(state=5, then=Value('Failed')),When(state=1, then=Value('Running')),default=Value('Unknown'),output_field=CharField(),),).filter(status="Running",id_user=id)
                
              

class NodesPowerStatusListView(APIView):
    def get(self,request):
        return Response(nodes_power_status())












################# DEPRECATED VIEWS #####################

# unused endpoint view   
class AllNodeUtilizationChartData(APIView):
    def get(self,request):
        return Response(getNodeCpuMemUtil())

# unused endpoint view  
class LineChartNodeUtilView(APIView):
    def get(self,request):
        return Response(getLineChartNodeUtilData())

# unused endpoint view   
class GPUsUtilizationView(APIView):
    def get(self, request, node):
        return Response(gpuUtilizations(node))

# unused endpoint view   
class NodeStatePlotView(APIView):
    def get(self,request):
        return Response(plotNodeState())

# unused endpoint view   
class SelectedNodeStatePlotView(APIView):
    def get(self,request,state):
        return Response(plotSelectedNodeState(state))

# unused endpoint view

class UserNodeUtilizationChartData(APIView):

    def post(self,request):
        chartdata = []
        final = []
        info = []
        cpulist = []
        memlist = []
        
        nodelist = request.data #json.loads(request.body)
        #id = self.kwargs['id']
        id = nodelist[0]['id']
        for i in range(1,len(nodelist)):
            nodelistarg = nodelist[i]['nodelist']
            resList = getParsedNodeList(nodelistarg)
            for j in range(0,len(resList)):
                final.append(resList[j])
        for node in final:
            data = getUserUtilChartData(id,node)
            datalist = []
            mydict1 = {}
            mydict2 = {}
            mydict3 = {}
            cpu = 0
            mem = 0
            for item in data:
                cpu = cpu + item['cpu']
                mem = mem + item['mem']
                #mydict['name'] = node
                    
            # mydict1['name'] = "cpu"
            # mydict1['value'] = cpu / len(data)
            # mydict2['name'] = 'memory'
            # mydict2['value'] = mem / len(data)
            # datalist.append(mydict1)
            # datalist.append(mydict2)
            mydict2['name'] = node
            mydict2['value'] = mem / len(data)
            mydict3['name'] = node
            # mydict3['series'] = datalist
            mydict3['value'] = cpu / len(data)

            memlist.append(mydict2)
            cpulist.append(mydict3)
        info.append(cpulist)
        info.append(memlist)
        return Response(info)


# class UsersAllocNodesQuickInfoView(APIView):
#     def get(self, request, userid):
#         data = SlurmJobTable.objects.annotate(status=Case(When(state=3, then=Value('Completed')),When(state=5, then=Value('Failed')),When(state=1, then=Value('Running')),default=Value('Unknown'),output_field=CharField(),),).filter(status="Running",id_user=userid)
#         serializer = UserNodesSerializer(data, many=True)
#         nodelist = usersAllocNodesQuickInfo(serializer.data)
#         return Response(nodelist)

############################################################
