from django.apps import AppConfig


class Rack3DConfig(AppConfig):
    name = 'rack_3d'
