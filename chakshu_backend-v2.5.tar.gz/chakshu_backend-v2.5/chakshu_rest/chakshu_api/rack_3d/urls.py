from django.urls import path

from .views import RackNodeInfoView

urlpatterns = [
    path('rackinfo/', RackNodeInfoView.as_view()),
   
]
