import node_details.utilities as node_utils
from os import environ

import common_utilities as utils
from chakshu_api import settings
# Assigned chakshu configs and logger
chakshu_conf = settings.chakshu_conf
logger = settings.LOGGER

# Get database connection for operations
db = utils.get_mongodb_connecion()


def rack_info():
    allnodesinfo = node_utils.all_nodes_quick_info()
    rackinfo = []
    for node in allnodesinfo:
        nodename = node['hostname']
        try:
            meminfo = utils.get_memory_info(nodename)
            node['load'] = utils.get_loads(nodename)['load1']
            node['total'] = round(meminfo['total'], 2)
            node['available'] = round(meminfo['available'], 2)
            rackinfo.append(node)
        except Exception as e:
            node['load'] = 0.0
            node['total'] = 0.0
            node['available'] = 0.0
            rackinfo.append(node)
            logger.error(e)
    return rackinfo




















############### DEPRECATED METHODS #############################
# rack_info()
def getRackViewInfo():
    mylist = node_utils.plotNodeState()
    final = []

    for i, item in enumerate(mylist):
        mydict = {}
        mydict['name'] = item['name']
        mydict['value'] = item['value']
        if node_utils.nodeload(item['value']):
            mydict['load'] = node_utils.nodeload(item['value'])['load1']
        temp = node_utils.cpuAvgTemp(item['value'])
        if not temp:
            temp = 45.5
        mydict['temp'] = temp
        #mydict['temp'] = node_utils.getCpuTemp(item['value'])
        temp = node_utils.getnodeinfo(item['value'])
        if 'cpupercent' not in temp:
            temp['cpupercent'] = 0.0
        if 'available' not in temp:
            temp['available'] = None
        if 'total' not in temp:
            temp['total'] = None
        mydict['cpu_percent'] = temp['cpupercent']
        mydict['mem_avail'] = temp['available']
        mydict['mem_total'] = temp['total']
        final.append(mydict)
    return final
################################################################
