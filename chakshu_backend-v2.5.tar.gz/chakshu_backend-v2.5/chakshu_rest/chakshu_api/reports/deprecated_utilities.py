import common_utilities as utils
import json
import os
import paramiko
from datetime import datetime
import re
import calendar
from security.utilities import *

DATA_DIR = chakshu_conf.CHAKSHU_DATA_DIR



def old_walltimeVsElapsedTimeByUsers(data):
    useroccurences = {}
    timediffbyusers = []
    for d in data:
        walltime_hrs = d['timelimit'] // 60
        timestamp_start = d['time_start']
        timestamp_end = d['time_end']
        userid = d['id_user']

        starttime = datetime.fromtimestamp(timestamp_start)
        endtime = datetime.fromtimestamp(timestamp_end)
        # starttime = t1.hour*60*60 + t1.minute*60 + t1.second
        # endtime = t2.hour*60*60 + t2.minute*60 + t2.second
        td = endtime - starttime
        elapsed_hrs = td.days*24 + td.seconds // 3600
        if userid in useroccurences:
            useroccurences[userid]["elapsed"] += elapsed_hrs
            useroccurences[userid]["walltime"] += walltime_hrs
        else:
            useroccurences.update(
                {
                    userid :{
                        "walltime" : walltime_hrs,
                        "elapsed" : elapsed_hrs
                    } 
                }
            )
    for user in useroccurences:
        temp = {
            "name": getUsername(user),
            "series": [
            {
                "name": "walltime",
                "value": useroccurences[user]['walltime'],
            },
            {
                "name": "elapsed",
                "value": useroccurences[user]['elapsed'],
            }]
        }
        timediffbyusers.append(temp)
    return timediffbyusers 

# daywise_tickets_event_counts()
def daywiseTicketStatusCount():
    try:
        with open(DATA_DIR + 'master/ticket-data.json') as file:tickets_count = json.load(file)
        return tickets_count
    except Exception as e:
        logger.error(e
)


def waitTimeByJobs(data):
    joboccurences = {}
    jobs_waittimes = []
    for d in data:
        jobid = d['id_job']
        jobname = d['job_name']
        submit = d['time_submit']
        start = d['time_start']
        t1 = datetime.fromtimestamp(submit)
        t2 = datetime.fromtimestamp(start)
        waittime = t2 - t1
        # only hours are taken
        diff_hr = divmod(waittime.days*24*3600 + waittime.seconds, 3600)[0]
        if jobname in joboccurences:
            joboccurences[jobname] += diff_hr
        else:
            joboccurences.update({jobname: diff_hr})
    for job in joboccurences:
        jobs_waittimes.append(
            {
                "name": job,
                "value": joboccurences[job]
            }
        )
    return jobs_waittimes