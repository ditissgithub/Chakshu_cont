from rest_framework import serializers
import common_utilities as utils



class UsageUserSerializer(serializers.Serializer):
    value = serializers.IntegerField(source='id_job__count')
    name = serializers.SerializerMethodField()

    def get_name(self, obj):
        try:
            userinfo = utils.get_user_info(obj['id_user'])
            return userinfo['username']
        except Exception as e:
            pass
        return 'system'
    

class AccountUsageSerializer(serializers.Serializer):
    value = serializers.IntegerField(source='id_job__count')
    name = serializers.CharField(source = "account")


class PartitionUsageSerializer(serializers.Serializer):
    value = serializers.IntegerField(source='id_job__count')
    name = serializers.CharField(source = "partition")



class JobByNodesSerialzer(serializers.Serializer):
    jobname = serializers.CharField(source='job_name')
    state = serializers.IntegerField()
    nodelist = serializers.CharField()

class JobUsageSerializer(serializers.Serializer):
    value = serializers.IntegerField()
    name = serializers.DateField()