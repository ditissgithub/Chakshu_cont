from django.urls import path
from common_utilities import chakshu_conf

clustername = chakshu_conf.CLUSTER_NAME.lower().replace(' ','')

from .views import (
    userUsageApiView,
    accountUsageApiView,
    partitionUsageView,
    jobTimeUsageApiView,
    UserpartitionUsageView,
    UserjobTimeUsageApiView,
    JobsByNodeView,
    WalltimeVsElapsedTimeView,
    HighMemoryJobsView,
    ClusterUtilizationView,
    ComputeUsersUtilizationView,
    DaywiseTicketStatusCount,
    UserLastWeekUsageView,
    UsersTillMonthlyJobsView,
    UserJobsByNNodesView,
    JobsByCPUsView,
    UserJobsByCPUSizeView,
    TotalUsersCreatedView,
    ListUsageBillsView,
    ListMonthWeeklyUsageBills,
    WaitTimeByJobAPIView,
    TotalLDAPUsersAPIView,
    CreatedVsClosedAPIView,
    SuccessJobsView,
    NSMClusterStatsAPIView,
    JobUsageReportView

)

urlpatterns = [
    # No of jobs submitted by users 
    path('userusage/<str:from>/<str:to>/', userUsageApiView.as_view()),
    # No of of jobs submitted by account
    path('accountusage/<str:from>/<str:to>/', accountUsageApiView.as_view()),
    # No of jobs by partition type (cpu, gpu, standard)
    path('partitionusage/<str:from>/<str:to>/', partitionUsageView.as_view()),
    # No of jobs by Date
    path('jobusagereport/<str:from>/<str:to>/', jobTimeUsageApiView.as_view()),
    # No of jobs by partition type (cpu, gpu, standard) - Logged in user
    path('userpartusagereport/<str:time>/<int:id>/', UserpartitionUsageView.as_view()),
    # No of of jobs submitted by Logged in user
    path('userjobsreport/<str:time>/<int:id>/', UserjobTimeUsageApiView.as_view()),
    # No of jobs by Node
    path('jobscountbynode/<str:from>/<str:to>/', JobsByNodeView.as_view()),
    # Total walltime vs elapsed time by users
    path('walltime-vs-elapsed/<str:from>/<str:to>/', WalltimeVsElapsedTimeView.as_view()),
    path('jobwaittime/<str:from>/<str:to>/', WaitTimeByJobAPIView.as_view()),
    path('high-mem-jobs/<str:from>/<str:to>/', HighMemoryJobsView.as_view()),
    path('users-monthly-jobs/<str:from>/<str:to>/<int:userid>/', UsersTillMonthlyJobsView.as_view()),
    path('user-jobsby-nnodes/<str:from>/<str:to>/<int:userid>/', UserJobsByNNodesView.as_view()),
    path('tickets-report/', DaywiseTicketStatusCount.as_view()),
    path('total-users-created/<str:from>/<str:to>/', TotalUsersCreatedView.as_view()),
    path('list-usage-bills/<str:username>/', ListUsageBillsView.as_view()),
    path('month-usage/<str:username>/<str:month>/', ListMonthWeeklyUsageBills.as_view()),
    
    # sreports & slurm tool
    path('cluster-utilization/<str:from>/<str:to>/', ClusterUtilizationView.as_view()),
    path('users-compute-utilization/<str:from>/<str:to>/', ComputeUsersUtilizationView.as_view()),
    path('user-lastweek-usage/<str:username>/', UserLastWeekUsageView.as_view()),
    path('jobs-by-cpus/<str:from>/<str:to>/', JobsByCPUsView.as_view()),
    path('jobs-by-cpus/<str:from>/<str:to>/<str:username>/', UserJobsByCPUSizeView.as_view()),

    # NSM cluster stats APIs
    path('total-ldap-users/', TotalLDAPUsersAPIView.as_view()),
    path('created-vs-closed-tickets/', CreatedVsClosedAPIView.as_view()),
    path('success-jobs/', SuccessJobsView.as_view()),
    path('nsm-cluster-stats/', NSMClusterStatsAPIView.as_view()),
    path(clustername + '/daywise-jobs/', JobUsageReportView.as_view()),
 
]
