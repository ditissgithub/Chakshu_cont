import common_utilities as utils
import os
import paramiko
from datetime import datetime, date, timedelta
import dateutil.relativedelta
import re
import calendar
from security.utilities import *
from pymongo import DESCENDING

# deprecated utility methods
# from .deprecated_utilities import *

from chakshu_api import settings
# Assigned chakshu configs and logger
chakshu_conf = settings.chakshu_conf
logger = settings.LOGGER

# Get database connection for operations
db = utils.get_mongodb_connecion()


# Create ssh session
def sshClientLogin(username, password):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect('localhost', port=22, username=username, password=password)
    return client

# Generate profiling scripts for user input


def generateProfilingBashScript(form_data):
    # Data collecting from POST request
    app_exe_path = form_data['app_exe']
    analysis_type = form_data['analysis_type']
    nodes = form_data['nodes']
    nodes = form_data['nodes']
    username = form_data['username']
    password = form_data['password']
    base_path, app = app_exe_path.rsplit('/', 1)
    # Defining Standard directories and filenames
    dir_name = '/home/' + username + '/chakshu_profiling'
    filename = dir_name+'/'+app+'_'+analysis_type+'.sh'
    out_dir = dir_name+'/'+app+'_'+analysis_type+'.result'
    # SSH login with user credentials
    user = sshClientLogin(username, password)
    # Creating profiling dir directory
    if not os.path.exists(dir_name):
        user.exec_command("mkdir " + dir_name)
        user.exec_command("chmod 775 " + dir_name)
        print(dir_name + "directory Created !")
    else:
        print(dir_name + "directory already exists!")
    # opening FTP session form file operations
    ftp = user.open_sftp()
    file = ftp.file(filename, "w+")
    file.write("#!/bin/sh \n\n")
    line1 = "source "+chakshu_conf.VTUNE_PATH+"amplxe-vars.sh"
    line2 = "amplxe-cl -c " + analysis_type + " -r "+out_dir+" "+app_exe_path
    file.write(line1 + "\n\n")
    file.write(line2 + "\n\n")
    file.flush()
    ftp.close()
    print("@@SCRIPT CREATED..!")
    script_content = {
        "line1": line1,
        "line2": line2
    }
    user.close()
    return {"status": "ok", "script": filename, "content": script_content}


def jobCountsByNode(data):
    jobcounts = []
    nodeoccurences = {}
    for d in data:
        nodelist = d['nodelist']
        parsedNodes = utils.parseNodelists([{'nodelist': nodelist}])
        for node in parsedNodes:
            if node in nodeoccurences:
                nodeoccurences[node] += 1
            else:
                nodeoccurences.update({node: 1})
    for name in nodeoccurences:
        jobcounts.append(
            {
                "name": name,
                "value": nodeoccurences[name]
            }
        )
    return sorted(jobcounts, key=lambda i: i['name'])


def walltimeVsElapsedTimeByUsers(data):
    useroccurences = {}
    timediffbyusers = []
    for d in data:
        walltime_hrs = d['timelimit'] // 60
        timestamp_start = d['time_start']
        timestamp_end = d['time_end']
        userid = d['id_user']
        starttime = datetime.fromtimestamp(timestamp_start)
        endtime = datetime.fromtimestamp(timestamp_end)
        td = endtime - starttime
        elapsed_hrs = td.days*24 + td.seconds // 3600
        if userid in useroccurences:
            useroccurences[userid]["elapsed"] += elapsed_hrs
            useroccurences[userid]["walltime"] += walltime_hrs
        else:
            useroccurences.update(
                {
                    userid: {
                        "walltime": walltime_hrs,
                        "elapsed": elapsed_hrs
                    }
                }
            )
    for user in useroccurences:
        temp = {
            "uname": getUsername(user),
            "walltime": useroccurences[user]['walltime'],
            "elapsed": useroccurences[user]['elapsed']
        }
        timediffbyusers.append(temp)
    return timediffbyusers



def listHighMemoryJobs(data):
    total_mem = 125
    for d in data:
        jobid = d['id_job']
        out = utils.runStringCommand(
            "seff "+str(jobid)+" | grep -e 'Memory Utilized'")
        k, v = out.split(':')
        if '(' in v:
            v = v.split('(')[0]
        unit = None
        if 'MB' in v:
            v = re.sub('[^\d\.]', '', v)
            percent = (float(v) / (total_mem * 1024)) * 100
            unit = 'MB'
        elif 'KB' in v:
            v = re.sub('[^\d\.]', '', v)
            percent = (float(v) / (total_mem * 2048)) * 100
            unit = 'KB'
        elif 'GB' in v:
            v = re.sub('[^\d\.]', '', v)
            percent = (float(v) / total_mem) * 100
            unit = 'GB'

        if percent >= 5:
            print("Mem Util = ", round(percent, 2), "JOB=", jobid, )


def clusterUtilization(since_date, till_date):
    command = 'sreport cluster Utilization Start='+since_date+' End='+till_date + \
        ' -t percent | sed -n \'$p\' |awk \'{print$2"|"$3"|"$4"|"$5"|"$6"|"$7}\''
    out = utils.runStringCommand(command)
    metrics = out.split("|")
    cluster_util = []
    names = ['allocated', 'down', 'planed_down',
             'idle', 'reserved', 'reported']
    for i, value in enumerate(metrics):
        value = float(value.replace('%', '').strip())
        if names[i] == 'reported':
            continue
        temp_dict = {"name": names[i], "value": value}
        cluster_util.append(temp_dict)
    return cluster_util


def usersCpuUtilization(since_date, till_date):
    users_utilization = []
    reportfile = chakshu_conf.CHAKSHU_HOME + "slurm_reports/ChakshuSacct"
    utils.runStringCommand(chakshu_conf.CHAKSHU_HOME+"scripts/slurmtool/slurmacct -s " +
                           since_date+" -e "+till_date+" -r " + reportfile)
    command = "cat "+reportfile+since_date+"_"+till_date + \
        " | sed -n '/TOTAL/,$p' | tail -n+2 | awk -F' ' '{print$1\"|\"$5}' | grep -ve 'TOTAL'"
    lines = []
    try:
        out = utils.runStringCommand(command)
        lines = out.split('\n')
    except Exception as e:
        logger.error(e)
    for l in lines:
        if not l:
            continue
        uname, cpu_percent = l.split('|')
        cpu_percent = float(cpu_percent.strip())
        if cpu_percent > 0.1:
            temp_dict = {"name": uname, "value": cpu_percent}
            users_utilization.append(temp_dict)
        else:
            continue
    users_utilization.append({"name": "others", "value": 0.0})
    return users_utilization


def daywise_tickets_event_counts():
    ticket_events = []
    try:
        ticket_events = list(db.ost_events.find({}, {'_id': False}))
        return ticket_events
    except Exception as e:
        logger.error(e)


def usersLastWeekUsage(username):
    reportfile = chakshu_conf.CHAKSHU_HOME + "slurm_reports/ChakshuSacct"
    utils.runStringCommand(chakshu_conf.CHAKSHU_HOME +
                           "scripts/slurmtool/slurmacct -w -r " + reportfile)
    cmd = "cat "+reportfile + \
        "Last_week |  awk '{print$1,$3,$5}' | grep "+username
    out = utils.runStringCommand(cmd)
    if out == 1 or not out:
        return {"uname": username, "jobs": 0, "cpu": 0.0}
    else:
        uname, jobs, cpu = out.split(' ')
        return {"uname": uname.strip(), "jobs": jobs.strip(), "cpu": float(cpu)}


def usersTillMonthlyJobs(data):
    for d in data:
        d['month'] = calendar.month_abbr[d['month']] + " " + str(d['year'])
        del d['year']
    return data


def jobs_percentage_by_cpus(since_date, till_date):
    command = 'sreport job sizesbyaccount PrintJobCount start='+since_date + \
        ' End='+till_date + \
        ' | sed -n \'$p\' |awk \'{print$3"|"$4"|"$5"|"$6"|"$7}\''
    out = utils.runStringCommand(command)
    metrics = out.split("|")
    jobsbycpus = []
    names = ['0-49 CPUs', '50-249 CPUs',
             '250-499 CPUs', '500-999 CPUs', '>=1000 CPUs']
    for i, value in enumerate(metrics):
        value = int(value.strip())
        temp_dict = {"cpurange": names[i], "njobs": value}
        jobsbycpus.append(temp_dict)
    return jobsbycpus


def user_jobs_by_cpusize(since_date, till_date, username):
    command = 'sreport job sizesbyaccount PrintJobCount users='+username+' start=' + \
        since_date+' End='+till_date + \
        ' | sed -n \'$p\' |awk \'{print$3"|"$4"|"$5"|"$6"|"$7}\''
    out = utils.runStringCommand(command)
    metrics = out.split("|")
    jobsbycpus = []
    names = ['0-49 CPUs', '50-249 CPUs',
             '250-499 CPUs', '500-999 CPUs', '>=1000 CPUs']
    for i, value in enumerate(metrics):
        value = int(value.strip())
        temp_dict = {"cpurange": names[i], "njobs": value}
        jobsbycpus.append(temp_dict)
    return jobsbycpus


def total_users_created(since_date, till_date):
    cmd = 'ldapsearch -x -H '+ chakshu_conf.LDAP_SERVER +' "(&(createTimestamp>='+since_date+')(createTimestamp<='+till_date+'))" -LLL uid=* uid | grep -w "uid:" | wc -l'
    out = utils.runStringCommand( cmd )
    nusers = int(out.strip())
    total_users_ldap = 0
    try:
        total_users_ldap = db.users.count_documents({})
    except Exception as e:
        logger.error(e)
    return {'category':'Users', 'created' : nusers, 'total':total_users_ldap }


def get_usage_bills(username):
    try:
        bills = list(db.usage_bills.find({'username':username}, {'_id':False}, limit=10).sort('_id', DESCENDING))
        return bills
    except Exception as e:
        logger.error(e)

def get_month_bills(username, month):
    try:
        if month == 'C':
            till = datetime.now()
            since = till.replace(day=7, hour=0, minute=0)
        elif month == 'M':
            current_month_start = datetime.now().replace(day=1, hour=0, minute=0)
            since =  current_month_start - dateutil.relativedelta.relativedelta(months=1)
            till = current_month_start - timedelta(days=2)
        bills = list( db.usage_bills.find({'username':username, 'date':{'$gte':since, '$lt':till}, 'invoice_duration':{'$regex': '.*Week.*'} }, {'_id':False, 'njobs':True, 'emoney_consumed':True, 'invoice_duration':True, 'date':True}) )
        for b in bills: 
            b.update({'tresmins': b['emoney_consumed']*100})
        return bills    
    except Exception as e:
        logger.error(e)


# NSM Clusters statstics for NSM India site

# Collect users from LDAP entries
def total_ldap_users():
    return db.users.count_documents({})


def closed_tickets():
    db =  utils.ost_mysql_connection(logger)
    db_cursor = db.cursor()
    db_cursor.execute(
        '''
        SELECT COUNT(*) as closed from `ost_thread_event` WHERE `event_id`=2;
        '''
    )
    closed_tickets = int(db_cursor.fetchall()[0][0])
    db_cursor.close()
    db.close()
    return closed_tickets


def created_tickets():
    db =  utils.ost_mysql_connection(logger)
    db_cursor = db.cursor()
    db_cursor.execute(
        '''
        SELECT COUNT(*) as created from `ost_thread_event` WHERE `event_id` in (1,3);
        '''
    )
    created_tickets = int(db_cursor.fetchall()[0][0])
    db_cursor.close()
    db.close()
    return created_tickets



