from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics
from django.db.models import *
from datetime import datetime, timedelta, time
from django.db.models.expressions import RawSQL
from rest_framework.permissions import AllowAny, IsAuthenticated

import common_utilities as utils
from .utilities import *
from job_details.models import SlurmJobTable
from .serializers import (
    UsageUserSerializer,
    AccountUsageSerializer,
    PartitionUsageSerializer,
    JobUsageSerializer,
    JobByNodesSerialzer
)



class userUsageApiView(generics.ListAPIView):
    serializer_class = UsageUserSerializer

    def get_queryset(self):
        since_date = self.kwargs['from']
        till_date = self.kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = int(since_date.strftime('%s'))
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%s")
        return SlurmJobTable.objects.select_related().values('id_user').filter(time_start__range=(int(since_date), int(till_date))).annotate(Count('id_job'))


class accountUsageApiView(generics.ListAPIView):
    serializer_class = AccountUsageSerializer

    def get_queryset(self):
        since_date = self.kwargs['from']
        till_date = self.kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = int(since_date.strftime('%s'))
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%s")
        return SlurmJobTable.objects.select_related().values('account').filter(time_start__range=(int(since_date), int(till_date))).annotate(Count('id_job'))


class partitionUsageView(generics.ListAPIView):
    serializer_class = PartitionUsageSerializer

    def get_queryset(self):
        since_date = self.kwargs['from']
        till_date = self.kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = int(since_date.strftime('%s'))
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%s")
        return SlurmJobTable.objects.select_related().values('partition').filter(time_start__range=(int(since_date), int(till_date))).annotate(Count('id_job')).exclude(partition=' ')


class jobTimeUsageApiView(generics.ListAPIView):
    serializer_class = JobUsageSerializer

    def get_queryset(self):
        since_date = self.kwargs['from']
        till_date = self.kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d').date()
        since_date = int(since_date.strftime('%s'))
        till_date = datetime.strptime(till_date, '%Y-%m-%d').date()
        till_date = till_date.strftime("%s")
        return SlurmJobTable.objects.filter(time_start__range=(since_date, till_date)).annotate(name=RawSQL('DATE(FROM_UNIXTIME(time_start))', [])).values('name').annotate(value=Count('id_job'))


class UserpartitionUsageView(generics.ListAPIView):
    serializer_class = PartitionUsageSerializer

    def get_queryset(self):
        range = self.kwargs['time']
        id = self.kwargs['id']

        todays_date = datetime.today().replace(hour=0, minute=0, second=0)
        todays_date = datetime.combine(todays_date, time.max)
        last_day = todays_date - timedelta(days=int(range))
        till_day = int(todays_date.strftime('%s'))
        since_day = int(last_day.strftime('%s'))
        return SlurmJobTable.objects.select_related().values('partition').filter(time_start__range=(int(since_day), int(till_day))).annotate(Count('id_job')).filter(id_user=id)


class UserjobTimeUsageApiView(generics.ListAPIView):
    serializer_class = JobUsageSerializer

    def get_queryset(self):
        range = self.kwargs['time']
        id = self.kwargs['id']
        todays_date = datetime.today().replace(hour=0, minute=0, second=0)
        todays_date = datetime.combine(todays_date, time.max)
        last_day = todays_date - timedelta(days=int(range))
        till_day = int(todays_date.strftime('%s'))
        since_day = int(last_day.strftime('%s'))
        return SlurmJobTable.objects.filter(time_start__range=(since_day, till_day)).annotate(name=RawSQL('DATE(FROM_UNIXTIME(time_start))', [])).values('name').annotate(value=Count('id_job')).filter(id_user=id)



class JobsByNodeView(APIView):
    """
    This endpoint lists the total jobs completed per node since provided date.
    """

    def get(self,request, **kwargs):
        since_date = kwargs['from']
        till_date = kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = int(since_date.strftime('%s'))
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%s")
        data = SlurmJobTable.objects.filter(time_start__range=(since_date, till_date)).exclude( Q(state=0) | Q(state=1) | Q(state=5) | Q(nodelist='None assigned')).values('nodelist')
        return Response(jobCountsByNode(data))


class WalltimeVsElapsedTimeView(APIView):
    """
    Provides the comparision data for walltime requested by users vs elapsed time.
    """
    
    def get(self,request, **kwargs):
        since_date = kwargs['from']
        till_date = kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = int(since_date.strftime('%s'))
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%s")
        data = SlurmJobTable.objects.filter(time_start__range=(since_date, till_date)).filter( state=3 ).values('timelimit','time_start','time_end','id_user')
        return Response(walltimeVsElapsedTimeByUsers(data))


class HighMemoryJobsView(APIView):
    
    def get(self,request, **kwargs):
        since_date = kwargs['from']
        till_date = kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = int(since_date.strftime('%s'))
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%s")
        data = SlurmJobTable.objects.filter(time_start__range=(since_date, till_date)).filter( Q(state=3) ).values('id_job','job_name')       
        listHighMemoryJobs(data) 
        return Response(data)



class AppProfileFormDataView(APIView):

    def post(self, request):
        form_data = request.data
        return Response(generateProfilingBashScript(form_data))



class ClusterUtilizationView(APIView):
    
    def get(self, request, **kwargs):
        since_date = kwargs['from']
        till_date = kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = since_date.strftime("%-m/%-d/%y-%H:%M:%S")
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%-m/%-d/%y-%H:%M:%S")
        data = clusterUtilization(since_date,till_date)
        return Response(data)
        
        
class ComputeUsersUtilizationView(APIView):
    
    def get(self, request, **kwargs):
        since_date = kwargs['from']
        till_date = kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = since_date.strftime("%m%d%y")
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%m%d%y")
        data = usersCpuUtilization(since_date,till_date)
        return Response(data)


class DaywiseTicketStatusCount(APIView):
    def get(self, request):
        data = daywise_tickets_event_counts()
        if data is None:
            return Response({"message":"error"})
        return Response(data)


class UserLastWeekUsageView(APIView):
    def get(self, request, username):
        return Response(usersLastWeekUsage(username))


class UsersTillMonthlyJobsView(APIView):
    def get(self, request,  **kwargs):
        userid = kwargs['userid']
        since_date = kwargs['from']
        till_date = kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = int(since_date.strftime('%s'))
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%s")
        queryset = SlurmJobTable.objects.filter(id_user=userid, time_start__range=(since_date, till_date)).annotate( month=RawSQL('MONTH(FROM_UNIXTIME(time_submit))',[])).values('month').annotate(year=RawSQL('YEAR(FROM_UNIXTIME(time_submit))',[]), jobs=Count('id_job'))
        data = usersTillMonthlyJobs(queryset)
        return Response(data)


class UserJobsByNNodesView(APIView):
    def get(self, request, **kwargs):
        userid = kwargs['userid']
        since_date = kwargs['from']
        till_date = kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = int(since_date.strftime('%s'))
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%s")
        queryset = SlurmJobTable.objects.filter(id_user=userid, time_start__range=(since_date, till_date)).values('nodes_alloc').annotate(jobs=Count('id_job')).exclude(nodes_alloc=0)
        userjobsbynnodes = list(queryset)
        data = sorted(userjobsbynnodes, key= lambda i: i['nodes_alloc'])
        return Response(data)

class JobsByCPUsView(APIView):
    def get(self, request, **kwargs):
        since_date = kwargs['from']
        till_date = kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = since_date.strftime("%-m/%-d/%y-%H:%M:%S")
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%-m/%-d/%y-%H:%M:%S")
        data = jobs_percentage_by_cpus(since_date,till_date)
        return Response(data)

class UserJobsByCPUSizeView(APIView):
    def get(self, request, **kwargs):
        username = kwargs['username']
        since_date = kwargs['from']
        till_date = kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = since_date.strftime("%-m/%-d/%y-%H:%M:%S")
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%-m/%-d/%y-%H:%M:%S")
        data = user_jobs_by_cpusize(since_date, till_date, username)
        return Response(data)


class TotalUsersCreatedView(APIView):
    def get(self, request, **kwargs):
        since_date = kwargs['from']
        till_date = kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = since_date.strftime("%Y%m%d000000Z")
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%Y%m%d235900Z")
        data = total_users_created(since_date, till_date)
        return Response(data)   

class ListUsageBillsView(APIView):
    def get( self, request, username ):
        data = get_usage_bills(username)
        return Response(data)


class ListMonthWeeklyUsageBills(APIView):
    def get(self, request, username, month):
        data = get_month_bills(username, month)
        return Response(data)




class JobWaitTimeView(APIView):
    """
    [DEPRECATED] Lists jobs (jobnames) with there total sum of of waittime.
    """
    def get(self,request, **kwargs):
        since_date = kwargs['from']
        till_date = kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = int(since_date.strftime('%s'))
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%s")
        data = SlurmJobTable.objects.filter(time_start__range=(since_date, till_date)).values('id_job','job_name','time_submit','time_start')
        return Response(waitTimeByJobs(data))


class WaitTimeByJobAPIView(APIView):

    def get(self,request, **kwargs):
        since_date = kwargs['from']
        till_date = kwargs['to']
        since_date = datetime.strptime(since_date, '%Y-%m-%d')
        since_date = int(since_date.strftime('%s'))
        till_date = datetime.strptime(till_date, '%Y-%m-%d')
        till_date = till_date.strftime("%s")
        data = SlurmJobTable.objects.values('job_name').filter(Q(time_submit__range=(since_date, till_date)), ~Q(time_start=0))\
            .annotate(name=F('job_name'), value=Sum(F('time_start') - F('time_submit')))\
                .filter(~Q(value__lte=1))
        return Response(data)



# NSM Clusters statstics for NSM India site

class TotalLDAPUsersAPIView(APIView):
    def get(self, request):
            return Response({'total_users':total_ldap_users()})


class CreatedVsClosedAPIView(APIView):
    def get(self, request):
        return Response({
            'created': created_tickets(),
            'closed': closed_tickets()
        })


class SuccessJobsView(APIView):

    def get(self, request):
        successfully_completed = SlurmJobTable.objects.filter(Q(exit_code=0)).count()
        return Response({'success_jobs':successfully_completed})


class NSMClusterStatsAPIView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        lm_start, lm_end = utils.previous_month_range(datetime.today())
        lm_start = lm_start.strftime("%-m/%-d/%y-%H:%M:%S")
        lm_end = lm_end.strftime("%-m/%-d/%y-%H:%M:%S")
        utilization = clusterUtilization(lm_start, lm_end)

        successfully_completed = SlurmJobTable.objects.filter(Q(exit_code=0)).count()
        waitjobs = SlurmJobTable.objects.filter(state=0).count();
        stats = {
            'total_users' : total_ldap_users(),
            'tickets' : {'created': created_tickets(),'closed': closed_tickets()},
            'success_jobs': successfully_completed,
            'waiting_jobs': waitjobs,
            'last_month_allocation': utilization[0]['value']
        }
        return Response( stats )


class JobUsageReportView(generics.ListAPIView):
    serializer_class = JobUsageSerializer

    def get_queryset(self):
        lm_start, lm_end = utils.previous_month_range(datetime.today())
        since_date = lm_start.strftime('%s')
        till_date = lm_end.strftime("%s")
        return SlurmJobTable.objects.filter(time_start__range=(since_date, till_date)).annotate(name=RawSQL('DATE(FROM_UNIXTIME(time_start))', [])).values('name').annotate(value=Count('id_job'))
