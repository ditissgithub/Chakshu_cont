#!/bin/bash

NAME="chakshu_api"
DJANGODIR=$CHAKSHU_ROOT/chakshu_rest/chakshu_api
WORKERS=4
DJANGO_SETTINGS_MODULE=chakshu_api.settings
DJANGO_WSGI_MODULE=chakshu_api.wsgi

cd $DJANGODIR

$CHAKSHU_ROOT/venv_chakshu/bin/gunicorn $DJANGO_WSGI_MODULE:application \
--name $NAME \
--workers $WORKERS \
--bind 0.0.0.0:8096 \
--log-config log.conf \
--certfile=$CHAKSHU_ROOT/ssl/chakshu_api.crt \
--keyfile=$CHAKSHU_ROOT/ssl/chakshu_api.key


