from .utilities import *
from rest_framework.views import APIView
from rest_framework.response import Response
from django.views.decorators.csrf import csrf_exempt
from rest_framework.authtoken.models import Token
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout



class LoginView(APIView):
    """Class to authenticate a user and then creating a login session"""
    authentication_classes = ()

    def post(self, request):
        try:
            salt = request.query_params['userverify']
            uname = request.data['username']
            encpasswd = request.data['password']

            decpasswd = decrypt_passwd(encpasswd, salt)
            user = authenticate(username=uname, password=decpasswd)
            if user is None:
                data = {
                    "status": "error",
                    "message": "The credentials are invalid"
                }
                return Response(data, status=401)
            login(request, user)
            token, created = Token.objects.get_or_create(user=user)
            new_token = token.generate_key()
            role = 'user'
            if user.username == 'cadmin':
                role = 'admin'
            data = {
                "token": new_token,
                "role": role,
                "username": user.username,
                "userid": getID(user.username),
                "email": user.email
            }
            return Response(data, status=200)
        except Exception as e:
            logger.error(e)
            data = {"status": "error", "message": "The credentials are invalid"}
            return Response(data, status=401)


class LogoutView(APIView):
    """
    Class for logging out a user by clearing his/her session
    """
    def post(self, request):
        """
        Api to logout a user
        """
        logout(request)
        data={'status': 'success'}
        return Response(data, status=200)