from django.urls import path
# from rest_framework_jwt.blacklist.views import BlacklistView
from rest_framework_jwt.views import verify_jwt_token

from .views import (
    GetIDView,
    getName,
    getUserView,
    LogoutView,
    UserLogin
)

urlpatterns = [
    #--jwt 
    path('login/', UserLogin.as_view()), 
    # path('blacklist/', BlacklistView.as_view({"post": "create"})),
    path('token-verify/', verify_jwt_token),
    #--

    path('logout/', LogoutView.as_view()),
    path('getID/<str:username>/', GetIDView.as_view()),
    path('getName/', getName),
    path('getuser/', getUserView.as_view())
]