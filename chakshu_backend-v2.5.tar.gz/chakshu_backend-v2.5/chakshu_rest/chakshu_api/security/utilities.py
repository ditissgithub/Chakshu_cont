import common_utilities as utils

from chakshu_api import settings
# Assigned chakshu configs and logger
chakshu_conf = settings.chakshu_conf
logger = settings.LOGGER


# Get database connection for operations
db = utils.get_mongodb_connecion()
from pymongo import ASCENDING


# /getuser/ endpoint data
def get_users():
    try:
        users = list(db.users.find({},{'_id':False, 'userid':True, 'username':True}).sort('userid',ASCENDING))
        return users 
    except Exception as e:
        logger.error(e)



def getID(username):
    res = utils.runOsCommand(['id','-u',username])
    return res

def getName():
    res = utils.runOsCommand(['whoami'])
    return res

def getUsername(id):
    res = utils.runStringCommand("getent passwd '"+str(id)+"' | cut -d: -f1")
    return res.replace('\n','')

def getUsersList():
    users = []
    uid_min = utils.runStringCommand("cat /etc/login.defs | grep -w UID_MIN | awk '{print$2}'")
    uid_max = utils.runStringCommand("cat /etc/login.defs | grep -w UID_MAX | awk '{print$2}'")
    command = "getent passwd | awk -F ':' -v 'min="+uid_min+"' -v 'max="+uid_max+"' '{if ($3 > min && $3 <=max ) print $0}' | cut -d ':' -f 1,3 --output-delimiter='=='  | awk '!x[$0]++'"
    out = utils.runStringCommand(command)
    lines = out.split('\n')
    for l in lines:
        if not l:
            continue
        uname,uid = l.split('==')
        user = {}
        user['userid'] = uid.strip()
        user['username'] = uname.strip()
        users.append(user)
    return sorted(users, key=lambda i: i['userid'])


from base64 import b64decode
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
KEY = chakshu_conf.PASSKEY
def decrypt_passwd(encpasswd, salt):
    data = b64decode(encpasswd)
    bytes = PBKDF2(KEY.encode("utf-8"), salt.encode("utf-8"), 48, 128)
    iv = bytes[0:16]
    key = bytes[16:48]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    text = cipher.decrypt(data)
    text = text[:-text[-1]].decode("utf-8")
    return text


def blacklist_token(token, user):
    result = utils.db.token_blacklist.insert_one({
        "timestamp": datetime.now(),
        "token": token,
        "user": user
    })
    logger.info("Token blacklisted: " + token)

