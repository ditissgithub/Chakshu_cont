from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import authenticate, login, logout
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_jwt.settings import api_settings

from .utilities import *
from .deprecated_views import *
from chakshu_api import settings

# Assigned chakshu configs and logger
chakshu_conf = settings.chakshu_conf
logger = settings.LOGGER


jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER

class UserLogin(APIView):
    """
        POST login/
        JWT Authentication with LDAP
    """	
    permission_classes = (AllowAny,)

    def post(self, request, *args, **kwargs):
        username, encpasswd, salt = None, None, None
        try:
            username = request.data.get('username', '')
            encpasswd = request.data.get('password', '')
            salt = request.query_params['userverify']
        except Exception as e:
            logger.error(e)
            return Response({"status":"error", "message": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)

        decpasswd = decrypt_passwd(encpasswd, salt)
        user = authenticate(request, username=username, password=decpasswd)
        if user is not None:
            role = 'user'
            if user.username in chakshu_conf.ADMIN_USERS:
                role = 'admin'
            login(request, user)
            payload = jwt_payload_handler(user)
            token = jwt_encode_handler(payload)
            return Response({
               'token': token,
               'username': username,
                "role": role,
                "userid": getID(user.username),
                "email": user.email
               
            }, status=status.HTTP_200_OK)

        return Response({"status":"error", "message": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)


class GetIDView(APIView):
    def get(self, request, username):
        return Response({"uid": getID(username)})


def getUserName(self):
    check = str(getName())
    return HttpResponse(check)


class getUserView(APIView):
    def get(self, request):
        return Response(get_users())
