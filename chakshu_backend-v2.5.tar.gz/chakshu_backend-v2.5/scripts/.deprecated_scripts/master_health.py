#!/usr/bin/python

## Health monitoring script 

import __future__
import os
import socket
import json
from threading import Timer
import commands
import subprocess
import imp



chakshu_conf = None
CHAKSHU_ROOT = os.environ['CHAKSHU_ROOT']
filepath = CHAKSHU_ROOT+'/.secret/chakshu_admin_conf.py'
with open(filepath, 'rb') as fp:
    chakshu_conf = imp.load_module('chakshu_conf', fp, filepath, \
    ('.py', 'rb', imp.PY_SOURCE))

# Define path for storing data.
basepath = chakshu_conf.CHAKSHU_DATA_DIR	# '/opt/ohpc/pub/apps/chakshu/data/'
storepath = basepath + 'master'
if not os.path.exists(storepath):
	os.makedirs(storepath)

# IMPI network id
ipmi_net_id = chakshu_conf.IPMI_NETWORK_ID

# IPMI credentials
_username_ = chakshu_conf.__IPMI_USERNAME
_password_ = chakshu_conf.__IPMI_PASSWORD


# Utility method for executing string command on linux.
def runStringCommand(command):
    try:
        data = subprocess.check_output(command,  stderr=subprocess.STDOUT, shell=True )
        return data.decode('utf-8')
    except subprocess.CalledProcessError as e:
        return e.returncode

# Return all the slave nodes with BMC IPs
def getEntHosts():
    nodelist = []
    delim = "=="
    command = os.environ['HOSTS_CMD'] + " | awk '{print$1\"==\"$2}'"
    output = runStringCommand(command)
    for line in output.split('\n'):
        if not line:
            continue
        ip, node = line.split('==')
        ip = ip.strip().replace('172.10', ipmi_net_id)
        node = {"host": node.strip(), "ip":ip }
        nodelist.append(node)
    return sorted(nodelist, key=lambda i: i['host'])



def generateCNIpmiIPLists():
    ipmi_netwk_id = net_id
    cn_ipmi_iplist = splitIPRanges(cn_ipranges, ipmi_netwk_id)
    return cn_ipmi_iplist


def generateGPUIpmiIPLists():
    ipmi_netwk_id = net_id
    gpu_ipmi_iplist = splitIPRanges(gpu_ipranges, ipmi_netwk_id)
    return gpu_ipmi_iplist

def generateHMIpmiIPLists():
    ipmi_netwk_id = net_id
    hm_ipmi_iplist = splitIPRanges(hm_ipranges, ipmi_netwk_id)
    return hm_ipmi_iplist

def splitIPRanges(hostids, netwk_id):
    iplist = []
    ipranges = hostids.split(',')
    for iprange in ipranges:
		if '-' not in iprange:
			start = end = iprange
		else:
			start, end = iprange.split('-')
		start = int(start) 
		end = int(end)
		for hostid in range(start, end+1):
			ip = netwk_id +"."+ str(hostid)
			iplist.append(ip)
    return sorted(iplist)

def checkIpmiChassisPower(node):
    kill = lambda process: process.kill()
    command = ['ipmitool', '-I','lanplus','-H', node['ip'], '-U', _username_ ,'-P', _password_, 'chassis', 'power', 'status']
    ipmi = subprocess.Popen(
         command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    my_timer = Timer(1, kill, [ipmi])
    try:
        my_timer.start()
        stdout, stderr = ipmi.communicate()
        if stdout:
            return stdout
        else:
            return 1
    finally:
        my_timer.cancel()




# Returns power status for all the input nodes.
def get_power_status(nodelist):
	power_info = []
	out = None
	for idx, node in enumerate(nodelist): 
		out = checkIpmiChassisPower(node)
		if out == 1 :
			power_status = 'Down'
			power_info.append({'host':node['host'],'power_status':power_status })
    			continue

		if 'on' in out:
			power_status = 'Up'
		else:
			power_status = 'Down'

		power_info.append({'host':node['host'],'power_status':power_status})
		out = None
	return power_info




# Main method which will be called in defined interval.
def execute():
	# Opne file in writing mode for returned power-status data..
	myFile1 = open(storepath+'/power_status.json','w')
	power_info_data = get_power_status(getEntHosts())
	myFile1.write(json.dumps(power_info_data))
	myFile1.close()
	# This method will be called in every 5 min.
	Timer(300.0,execute).start()

execute()





