#!/home/apps/chakshu/venv_chakshu/bin/python

import os
import subprocess
import json
import socket
from threading import Timer
import json
import imp


chakshu_conf = None
CHAKSHU_ROOT = os.environ['CHAKSHU_ROOT']
filepath = CHAKSHU_ROOT+'/.secret/chakshu_admin_conf.py'
with open(filepath, 'rb') as fp:
    chakshu_conf = imp.load_module('chakshu_conf', fp, filepath, \
    ('.py', 'rb', imp.PY_SOURCE))


# Define data directory for aggregated data.
hostname = socket.gethostname()
basepath = chakshu_conf.CHAKSHU_DATA_DIR        
storePath = basepath + 'master'
if not os.path.exists(storePath):
        os.makedirs(storePath)

backup1 =[{'cpu':0,'mem':0}]
backup2 =None
backup3 =None
total_nodes = chakshu_conf.TOTAL_NODES
print("Total Nodes = ", total_nodes)


# Utility method for executing string command on linux.
def runStringCommand(command):
        try:
            data = subprocess.check_output(command,  stderr=subprocess.STDOUT, shell=True )
            return data.decode('utf-8')
        except subprocess.CalledProcessError as e:
            return e.returncode


# Return all the nodes with theie resource states.
def getAllNodes():
        nodelist = []
        cmd = "sinfo -N | grep -vw -e standard-low -e hm -e gpu -e cn -e cpu -e NODELIST | awk -F' ' '{ print $1,$4 }'"
        output = runStringCommand(cmd)
        for line in output.split('\n'):
                if line:
                    node,state = line.split(' ')
                    nodelist.append({ "node":node, "state":state })
        return nodelist

# Return the nodes which are in the states other than ['down', 'drain', 'maint', 'resv']
def getUpNodesOnly():
        up_nodes = []
        down_nodes = []
        unwanted_states = ['down', 'drain', 'maint', 'resv', 'drng']
        allnodes = getAllNodes()
        for node in allnodes:
                if any(s in node['state'] for s in unwanted_states):
                        down_nodes.append(node)
                else:
                        up_nodes.append(node)
        #print("Down nodes = ",down_nodes)
        return(up_nodes)


def getCpuPercent(node):
        cpu = None
        cpu_path = basepath + node + '/cpu_percent.json'
        try:
                with open(cpu_path) as cpufile:cpu = json.load(cpufile)
                return float(cpu['percentage'])
        except Exception as e:
                pass

def getMemoryPercent(node):
        #if 'gpu' in node:
        #       memPath = basepath + nodes[i]+'/gpu_info.json'
        #       temp = json.loads(open(memPath,'r').read())
        #       for i in range(len(temp)):
        #               addtemp += temp[i]['memoryUtil'] * 100
        #       memAdd += addtemp / len(temp)
        #else:
        mem_path = basepath +node+'/mem_details.json'
        try:
                with open(mem_path) as memfile:mem = json.load(memfile)
                return float(mem['percent'])
        except Exception as e:
                pass

def getTemperature(node):
        temperatures = None
        temp_total = 0
        temp_path = basepath + node + '/core_temp.json'
        with open(temp_path) as tempfile:temperatures = json.load(tempfile)
        temp_dict = {}
        if temperatures != None:
                for j, tmp in enumerate(temperatures):
                        for item in tmp:
                                for k in list(item):
                                        if 'Physical' in k:
                                                temp_total += item[k]
                temp_dict['name'] = node
                temp_dict['value'] = temp_total / len(temperatures)
        else:
                temp_dict['name'] = node
                temp_dict['value'] = 35
        return temp_dict


def getNodeLoad(node):
        loads = None
        try:
                load_path = basepath + node + '/cpu_loadavg.json'
                with open(load_path) as loadfile:loads = json.load(loadfile)
                return loads
        except Exception as e:
                pass



def getNodesData(nodes):
        print("Up nodes : ",len(nodes))
        cpu_total = 0
        mem_total = 0
        cluster_temp = []
        try:
                for i,n in enumerate(nodes):
                        nodename = n['node']
                        #print(getCpuPercent(nodename))
                        try:
                                cpu_total += getCpuPercent(nodename)
                                mem_total += getMemoryPercent(nodename)
                                cluster_temp.append(getTemperature(nodename))
                        except:
                                pass

                # final data
                cpu_mem = [{'cpu':round(cpu_total/total_nodes,2),'mem':round(mem_total/total_nodes,2)}]
                #print("Final DATA = " , cpu_mem)
                print('storePath',storePath)
                cpuMemFile = open(storePath+'/cpuMemUtil.json','w')
                tempFile = open(storePath+'/clusterTemp.json','w')

                cpuMemFile.write(json.dumps(cpu_mem))
                tempFile.write(json.dumps(cluster_temp))
                print('Written')
                cpuMemFile.close()
                tempFile.close()

        #taking backup
        #backup1 = out
        #backup2 = clusterLoad
        #backup3 = clusterTemp
        except Exception as e:
                print(e)




def collectNodesData():
        getNodesData(getUpNodesOnly())
        Timer(10.0,collectNodesData).start()

collectNodesData()
