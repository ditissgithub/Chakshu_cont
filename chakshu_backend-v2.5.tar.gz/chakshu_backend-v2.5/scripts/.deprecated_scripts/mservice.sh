#!/bin/bash

#montoollMasterService : Service to collect montool data from each node and store it into its own specific directory
# Note : Need to be run on master node
# chkconfig: 345 99 01

RETVAL=0
HOSTNAME='master'

start(){
        /opt/ohpc/pub/apps/chakshu/scripts/montoolMasterService.py &
        echo $!>/opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolMasterService.pid
	/opt/ohpc/pub/apps/chakshu/scripts/montoolHealthMonitorMaster.py &
        echo $!>/opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolHealthMonitorMaster.pid
}

stop(){
        kill `cat /opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolNodeService.pid`
        rm /opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolNodeService.pid
	kill `cat /opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolHealthMonitorMaster.pid`
        rm /opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolHealthMonitorMaster.pid
}

case "$1" in
start)
        start
        ;;
stop)
        stop
        ;;
status)
        if [ -e /opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolNodeService.pid ]; then
                echo 'montoolMasterService is running, pid=`cat /opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolNodeService.pid`'
        else
                echo 'montoolMasterService is NOT running'
                exit 1
        fi
        ;;


reload)
        stop
        start
        ;;
restart)
        stop
        start
        ;;
*)
        echo "Usage: $0 [start|stop|status|reload|restart]"
        exit 1
esac

