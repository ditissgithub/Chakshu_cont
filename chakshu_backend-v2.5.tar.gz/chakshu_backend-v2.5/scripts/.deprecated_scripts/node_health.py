#!/usr/bin/python

import __future__
import json
from threading import Timer
import socket
import os
import commands
import imp


chakshu_conf = None
CHAKSHU_ROOT = os.environ['CHAKSHU_ROOT']
filepath = CHAKSHU_ROOT+'/.secret/chakshu_admin_conf.py'
with open(filepath, 'rb') as fp:
    chakshu_conf = imp.load_module('chakshu_conf', fp, filepath, \
    ('.py', 'rb', imp.PY_SOURCE))


hostname = socket.gethostname()
if '.' in hostname:
	hostname = hostname.split('.')[0]

basePath = chakshu_conf.CHAKSHU_DATA_DIR	# '/opt/ohpc/pub/apps/chakshu/data/'
storePath = basePath + hostname
if not os.path.exists(storePath):
        os.makedirs(storePath)



# Power Status & Consumption 
def get_power_info():

	#1 power status
	power_info = {}
	out = commands.getoutput('ipmitool -U root -P calvin power status')
	power_status = { 'power_status':out.strip() }
	power_info.update(power_status)
	out = None

	#2 power consumption
	#out = commands.getoutput('ipmi-oem -u root -p calvin intelnm get-node-manager-statistics | grep -i "current power" | awk {print$4}')
	#k,v = out.split(':')
	#power_usage = { 'current_power' : v.strip() }
	#power_info.update(power_usage)
	#out = None
	# print json.dumps(power_info)
	return power_info


# Node Fanspeeds 
def get_fan_speeds():
	fan_speeds = {}
	out = commands.getoutput("ipmitool -U root -P calvin sdr | grep -i  'fan'")
	lines = out.split('\n')
	for l in lines:
		k, v, s = l.split('|')
		k = k.replace(' ' , '')
		fan_speed = { k : v.strip() }
		fan_speeds.update(fan_speed)
	out = None
	# print json.dumps(fan_speeds)
	return fan_speeds


# Chassis Tempratures 
def get_chassis_temps():
	temperatures = {}
	out = commands.getoutput("ipmitool -U root -P calvin sdr | grep -i -w 'temp'")
	lines = out.split('\n')
	for l in lines:
		k, v, s = l.split('|')
		k = k.replace(' ','')
		temp = { k : v.strip() }
		temperatures.update(temp)
	out = None
	# print json.dumps(temperatures)
	return temperatures



def execute():
	#myFile15 = open(storePath+'/power_info.json', 'w')
	myFile1 = open(storePath+'/fanspeeds.json','w')
	myFile2 = open(storePath+'/chassis_temps.json','w')

	#myFile15.write(json.dumps(power_info))
	myFile1.write(json.dumps(get_fan_speeds()))
	myFile2.write(json.dumps(get_chassis_temps()))

	#myFile15.close()
	myFile1.close()
	myFile2.close()

	Timer(10.0,execute).start()


execute()


