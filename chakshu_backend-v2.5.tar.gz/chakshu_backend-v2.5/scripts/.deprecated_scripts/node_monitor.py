#!/home/apps/chakshu/venv_chakshu/bin/python

#  Node Complete Performance Monitoring Script

import __future__
import json
import psutil
import socket
import os
import socket
import subprocess
import GPUtil
from threading import Timer
import imp


chakshu_conf = None
filepath = '/home/apps/chakshu/.secret/chakshu_admin_conf.py'
with open(filepath, 'rb') as fp:
    chakshu_conf = imp.load_module('chakshu_conf', fp, filepath, \
    ('.py', 'rb', imp.PY_SOURCE))


# Define data directory for this-->node.
hostname = socket.gethostname()
if '.' in hostname:
	hostname = hostname.split('.')[0]
basePath = chakshu_conf.CHAKSHU_DATA_DIR	
storePath = basePath + hostname

if not os.path.exists(storePath):
	os.makedirs(storePath)
	

# Valid users
uid_min = os.popen("cat /etc/login.defs | grep -w UID_MIN | awk '{print$2}'").read()
uid_max = os.popen("cat /etc/login.defs | grep -w UID_MAX | awk '{print$2}'").read()
users = os.popen("getent passwd | awk -F ':' -v 'min=1000' -v 'max="+uid_max+"' '{if ($3 > min && $3 <=max ) print $0}' | cut -d ':' -f 1 | awk '!x[$0]++'").read().split('\n')

# Services status check 
services_to_check = ["chronyd","crond","gmond","lnet","mdmonitor","munge","nrpe","nslcd","rsyslog","slapd","slurmd","snmpd","sshd","syslog"]
def is_service_running(name):
    with open(os.devnull, 'wb') as hide_output:
        exit_code = subprocess.Popen(['service', name, 'status'], stdout=hide_output, stderr=hide_output).wait()
        return exit_code == 0

# Processes details of users
def running_process_info():
	runProc = []
	for proc in psutil.process_iter():
		global pinfo
		pinfo = proc.as_dict(['pid','username','name','memory_percent','cpu_percent','status','num_threads','uids','gids'])
		if pinfo.get('username') in users:
			runProc.append(pinfo)
	return runProc

# Job utilization details
def job_details():
	top_procs = psutil.process_iter()
	job_details = {}
	cpupercent_avg = 0.0
	mempercent_avg = 0.0
	num_threads = 0
	num_procs = 0
	proc_names = []
	for proc in top_procs:
		proc = proc.as_dict(['pid','username','name','memory_percent','cpu_percent','status','num_threads'])
		if proc['status'] == 'running' and proc['username'] in users:
			if proc['name'] not in proc_names:
				proc_names.append(proc['name'])
			num_threads +=  proc['num_threads']
			num_procs += 1
			mempercent_avg += round(proc['memory_percent'], 2)
			# cpupercent_avg += round(proc['cpu_percent'], 2)
	job_details['mempercent'] = mempercent_avg  #psutil.virtual_memory().percent
	job_details['cpupercent'] = psutil.cpu_percent()
	job_details['num_threads'] = num_threads
	job_details['num_procs'] = num_procs
	job_details['procs'] = proc_names
	return job_details

# Cpu / Cpu Cores Temperature Details (Socket Wise)
def cpu_temperatures():
	raw_data = psutil.sensors_temperatures()
	temp_list = raw_data['coretemp']
	temperatures = []
	coretemp = []
	coretemp_0 = []
	coretemp_1 = []
	var = 0
	for i in range(len(temp_list)):
       		 data = temp_list[i]
       		 coretemp.append({data.label:data.current})
	for i in range(len(coretemp)):
        	if(coretemp[i].get('Physical id 1') or var==1):
                	var = 1
                	coretemp_1.append(coretemp[i])
        	if var == 0:
                	coretemp_0.append(coretemp[i])
	coretemp = []
	coretemp.append(coretemp_0)
	coretemp.append(coretemp_1)
	return coretemp

# Cpu Statistics
def cpu_stats():
	cpuStat = []
	try:
		temp = psutil.cpu_stats()

		cpuStat=[
			{'ctx_switches':temp.ctx_switches,
			'interrupts':temp.interrupts,
			'soft_interrupts':temp.soft_interrupts,
			'syscalls':temp.syscalls,
	        }
		]
	except:
		cpuStat=[
			{'ctx_switches':0,
			'interrupts':0,
			'soft_interrupts':0,
			'syscalls':0,
			}
        ]
	return cpuStat

# Memory details
def memory_details():
	memory = {}
	try:
		temp = psutil.virtual_memory()
		memory = {
			'total':temp.total /(1024*1024*1024),
	   		'available':temp.available /(1024*1024*1024),
	   		'percent':temp.percent,
	   		'used':temp.used /(1024*1024*1024),
			'free':temp.free /(1024*1024*1024),
	   		'active':temp.active /(1024*1024*1024),
	   		'inactive':temp.inactive /(1024*1024*1024),
			'buffers':temp.buffers /(1024*1024*1024),
	   		'cached':temp.cached /(1024*1024*1024),
			'shared':temp.shared /(1024*1024*1024),
			'slab':temp.slab /(1024*1024*1024)
		}
	except:
		memory = {
			'total': 0,
			'available': 0,
			'percent': 0,
			'used': 0,
			'free': 0,
			'active': 0,
			'inactive': 0,
			'buffers': 0,
			'cached': 0,
			'shared':0,
			'slab': 0
		}
	return memory


# Swap Memory Details
def swap_memory_details():
	swap = []
	try:
		temp = psutil.swap_memory()
		swap = [{
			'total':temp.total /(1024*1024),
			'used':temp.used /(1024*1024) ,
			'free':temp.free /(1024*1024),
			'percent':temp.percent /(1024*1024),
			'sin':temp.sin /(1024*1024),
			'sout':temp.sout /(1024*1024),
		}]
	except:
		swap = [{
			'total': 0,
			'used': 0 ,
			'free': 0,
			'percent': 0,
			'sin': 0,
			'sout': 0,
		}]
	return swap


# Disk IO
def disk_io():
	disk_io = []
	try:
		temp = psutil.disk_io_counters()
		disk_io = [{
			'read_count':temp.read_count,
			'write_count':temp.write_count,
			'read_bytes':temp.read_bytes,
			'write_bytes':temp.write_bytes,
			'read_time':temp.read_time,
			'write_time':temp.write_time,
			'busy_time':temp.busy_time,
			'read_merged_count':temp.read_merged_count,
			'write_merged_count':temp.write_merged_count, 
		}]
	except:
		disk_io = [{
			'read_count':0,
			'write_count':0,
			'read_bytes':0,
			'write_bytes':0,
			'read_time':0,
			'write_time':0,
			'busy_time':0,
			'read_merged_count':0,
			'write_merged_count':0,
		}]
	return disk_io


# Active Users Details on Node
def active_users():
	temp = psutil.users()
	#print(temp)

	usersActive = [{
          	'name':temp[i].name,
          	'terminal':temp[i].terminal,
          	'host':temp[i].host,
          	'started':temp[i].started,
          	'pid':temp[i].pid,
         	}
          	for i in range(len(temp)) ]
	return usersActive



# cpu core utilizations
def get_core_utilizations():
	count = 0
	core_utilizations = []

	for proc in psutil.cpu_times_percent(interval=None,percpu=True):
		count += 1
		temp = {
				'user':round(proc.user,2),
				'system':round(proc.system,2),
				'idle':round(proc.idle,2),
				'core': 'cpu' + str(count)
		}
		core_utilizations.append(temp)
	return core_utilizations

# Get Information of available GPUs
gpus = GPUtil.getGPUs()
def gpu_info():
	gpuinfo = [{
           	'id':gpus[i].id,
            	'uuid':gpus[i].uuid,
            	'load':gpus[i].load,
            	'memoryUtil':gpus[i].memoryUtil,
            	'memoryTotal':gpus[i].memoryTotal,
            	'memoryUsed':gpus[i].memoryUsed,
            	'memoryFree':gpus[i].memoryFree,
            	'driver':gpus[i].driver,
            	'name':gpus[i].name,
            	'serial':gpus[i].serial,
            	'display_mode':gpus[i].display_mode,
            	'display_active':gpus[i].display_active,
           	}
           	for i in range(len(gpus))
           	]
	return gpuinfo

# Node Load Average
def load_average():
	temp = os.getloadavg()
	loadavg = [{'load1':temp[0],'load5':temp[1],'load15':temp[2]}]
	return loadavg

# CPU Percent
def cpu_percent():
	percent = psutil.cpu_percent(interval=1)
	cpuPercent = {'percentage': percent}
	return cpuPercent

# Network IO Counters 
def network_io_details():
	temp = json.loads(json.dumps(psutil.net_io_counters(pernic=True)))
	net_io =[{
		'name' : item,
		'MByte_sent' : temp.get(item)[0]/(1024*1024),
		'MByte_recv' :temp.get(item)[1]/(1024*1024),
		'packets_sent' : temp.get(item)[2],
		'packets_recv' : temp.get(item)[3],
		'errin' : temp.get(item)[4],
		'errout' : temp.get(item)[5],
		'dropin' : temp.get(item)[6],   
		'dropout' : temp.get(item)[7]
	}for item in temp.keys()]
	return net_io

# Service Status
def service_status():
	serviceStatus = []
	for i in range(len(services_to_check)):
		if not is_service_running(services_to_check[i]):
			temp = {
				'name' : services_to_check[i],
				'value' : 'inactive'
			}                
			serviceStatus.append(temp)
		else:
			temp = {
				'name' : services_to_check[i],
				'value' : 'active'
			}  
			serviceStatus.append(temp)
	return serviceStatus



# Main method which is is called in defined interval.
def execute1():        

	# Storing output file to Node Specific Directory
	myFile2 = open(storePath+'/core_temp.json','w')
	myFile4 = open(storePath+'/mem_details.json','w')
	myFile5 = open(storePath+'/swap_details.json','w')
	myFile8 = open(storePath+'/active_users.json','w')
	myFile12 = open(storePath+'/cpu_loadavg.json','w')
	myFile13 = open(storePath+'/cpu_percent.json','w')
	job_file = open(storePath + '/job_details.json', 'w')
	
	
	myFile2.write(json.dumps(cpu_temperatures()))
	json.dump(memory_details(), myFile4) #changed
	myFile5.write(json.dumps(swap_memory_details()))
	myFile8.write(json.dumps(active_users()))
	myFile12.write(json.dumps(load_average()))
	json.dump(cpu_percent(),myFile13) # changed
	json.dump(job_details(), job_file)

	# End with writting Closing File
	myFile2.close()
	myFile4.close()
	myFile5.close()
	myFile8.close()
	myFile12.close()
	myFile13.close()
	job_file.close()

	if gpus:
		myFile11 = open(storePath+'/gpu_info.json','w')
		myFile11.write(json.dumps(gpu_info()))
		myFile11.close()
	Timer(10.0,execute1).start()


def execute2():
	myFile14 = open(storePath+'/services_status.json','w')

	myFile14.write(json.dumps(service_status()))
	
	myFile14.close()
	Timer(600.0,execute2).start()
	

def execute3():
	myFile6 = open(storePath+'/disk_io.json','w')
	myFile7 = open(storePath+'/net_io.json','w')
	myFile9 = open(storePath+'/cpu_core_util.json','w')
	# myFile10 = open(storePath+'/cpu_total_util.json','w')

	myFile6.write(json.dumps(disk_io()))
	myFile7.write(json.dumps(network_io_details()))
	myFile9.write(json.dumps(get_core_utilizations()))
	# myFile10.write(json.dumps(cpu_details()['cpuTotal']))

	myFile6.close()
	myFile7.close()
	myFile9.close()
	# myFile10.close()
	Timer(120.0,execute2).start()

def execute4():
	myFile1 = open(storePath+'/running_proc.json','w')
	myFile3 = open(storePath+'/cpu_stats.json','w')

	myFile1.write(json.dumps(running_process_info()))
	myFile3.write(json.dumps(cpu_stats()))

	myFile1.close()
	myFile3.close()
	Timer(300.0,execute2).start()



execute1()
execute2()
execute3()
execute4()




