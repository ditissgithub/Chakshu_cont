#!/home/apps/chakshu/venv_chakshu/bin/python

#  Node Complete Performance Monitoring Script

import __future__
import json
import psutil
import os
import socket
import subprocess
import GPUtil
from threading import Timer
import imp


chakshu_conf = None
filepath = '/home/apps/chakshu/.secret/chakshu_admin_conf.py'
with open(filepath, 'rb') as fp:
    chakshu_conf = imp.load_module('chakshu_conf', fp, filepath, \
    ('.py', 'rb', imp.PY_SOURCE))


# Define data directory for this-->node.
hostname = socket.gethostname()
if '.' in hostname:
	hostname = hostname.split('.')[0]
basePath = chakshu_conf.CHAKSHU_DATA_DIR	# '/opt/ohpc/pub/apps/chakshu/data/'
storePath = basePath + hostname

if not os.path.exists(storePath):
	os.makedirs(storePath)
	


# Services status check 
services_to_check = ["chronyd","crond","gmond","lnet","mdmonitor","munge","nrpe","nslcd","rsyslog","slapd","slurmd","snmpd","sshd","syslog"]

def is_service_running(name):
    with open(os.devnull, 'wb') as hide_output:
        exit_code = subprocess.Popen(['service', name, 'status'], stdout=hide_output, stderr=hide_output).wait()
        return exit_code == 0

# Main method which is is called in defined interval.
def execute():        
	# Processes details of users
	uid_min = os.popen("cat /etc/login.defs | grep -w UID_MIN | awk '{print$2}'").read()
	uid_max = os.popen("cat /etc/login.defs | grep -w UID_MAX | awk '{print$2}'").read()
	users = os.popen("getent passwd | awk -F ':' -v 'min="+uid_min+"' -v 'max="+uid_max+"' '{if ($3 > min && $3 <=max ) print $0}' | cut -d ':' -f 1 | awk '!x[$0]++'").read().split('\n')
	runProc = []
	for proc in psutil.process_iter():
		global pinfo
		pinfo = proc.as_dict(['pid','username','name','memory_percent','cpu_percent','status','num_threads','uids','gids'])
		if pinfo.get('username') in users:
			runProc.append(pinfo)


	# Job utilization details
	top_procs = psutil.process_iter()
	job_details = {}
	cpupercent_avg = 0.0
	mempercent_avg = 0.0
	num_threads = 0
	num_procs = 0
	proc_names = []
	for proc in top_procs:
		proc = proc.as_dict(['pid','username','name','memory_percent','cpu_percent','status','num_threads'])
		if proc['status'] == 'running' and proc['username'] in users:
			if proc['name'] not in proc_names:
				proc_names.append(proc['name'])
			num_threads +=  proc['num_threads']
			num_procs += 1
			mempercent_avg += round(proc['memory_percent'], 2)
			# cpupercent_avg += round(proc['cpu_percent'], 2)


	job_details['mempercent'] = mempercent_avg  #psutil.virtual_memory().percent
	job_details['cpupercent'] = psutil.cpu_percent()
	job_details['num_threads'] = num_threads
	job_details['num_procs'] = num_procs
	job_details['procs'] = proc_names




	# Cpu / Cpu Cores Temperature Details (Socket Wise)
	raw_data = psutil.sensors_temperatures()
	temp_list = raw_data['coretemp']
	temperatures = []
	coretemp = []
	coretemp_0 = []
	coretemp_1 = []
	var = 0

	for i in range(len(temp_list)):
       		 data = temp_list[i]
       		 coretemp.append({data.label:data.current})

	for i in range(len(coretemp)):
        	if(coretemp[i].get('Physical id 1') or var==1):
                	var = 1
                	coretemp_1.append(coretemp[i])
        	if var == 0:
                	coretemp_0.append(coretemp[i])

	coretemp = []
	coretemp.append(coretemp_0)
	coretemp.append(coretemp_1)

	# Cpu Statistics
	try:
		temp = psutil.cpu_stats()

		cpuStat=[
		   	{'ctx_switches':temp.ctx_switches,
		    	'interrupts':temp.interrupts,
		    	'soft_interrupts':temp.soft_interrupts,
		    	'syscalls':temp.syscalls,
	           	}
		  	]
	except:
		cpuStat=[
                        {'ctx_switches':0,
                        'interrupts':0,
                        'soft_interrupts':0,
                        'syscalls':0,
                        }
                        ]

		
	# Memory details
	try:

		temp = psutil.virtual_memory()

		memory = {'total':temp.total /(1024*1024*1024),
	   		'available':temp.available /(1024*1024*1024),
	   		'percent':temp.percent,
	   		'used':temp.used /(1024*1024*1024),
           		'free':temp.free /(1024*1024*1024),
	   		'active':temp.active /(1024*1024*1024),
	   		'inactive':temp.inactive /(1024*1024*1024),
           		'buffers':temp.buffers /(1024*1024*1024),
	   		'cached':temp.cached /(1024*1024*1024),
           		'shared':temp.shared /(1024*1024*1024),
           		'slab':temp.slab /(1024*1024*1024)
          		}
	except:
		memory = {'total': 0,
                    'available': 0,
                    'percent': 0,
                    'used': 0,
                    'free': 0,
                    'active': 0,
                    'inactive': 0,
                    'buffers': 0,
                    'cached': 0,
                    'shared':0,
                    'slab': 0
                    }
                        


	# Swap Memory Details
	try:

		temp = psutil.swap_memory()

		swap = [
        		{'total':temp.total /(1024*1024),
         		'used':temp.used /(1024*1024) ,
         		'free':temp.free /(1024*1024),
         		'percent':temp.percent /(1024*1024),
         		'sin':temp.sin /(1024*1024),
         		'sout':temp.sout /(1024*1024),
        		}
       			]
	except:
		swap = [
                        {'total': 0,
                        'used': 0 ,
                        'free': 0,
                        'percent': 0,
                        'sin': 0,
                        'sout': 0,
                        }
                        ]

	#print(swap)

	#--------------------------Disk Usage------------------------

	#users = pwd.getpwall()
	#home = []
	#scratch = []
	#for i in range(len(users)):
	#        if os.path.exists('/home/'+users[i].pw_name):
	#		home.append(json.dumps(psutil.disk_usage('/home/'+users[i].pw_name)))
	#	if os.path.exists('/scratch/'+users[i].pw_name):
	#		scratch.append(psutil.disk_usage('/scratch/'+users[i].pw_name))

	#print(home)
	#print(scratch)


	# Disk IO
	try:

		temp = psutil.disk_io_counters()
		#print(temp)

		disk_io = [{
             		'read_count':temp.read_count,
	     		'write_count':temp.write_count,
	     		'read_bytes':temp.read_bytes,
	     		'write_bytes':temp.write_bytes,
	     		'read_time':temp.read_time,
	     		'write_time':temp.write_time,
	     		'busy_time':temp.busy_time,
	     		'read_merged_count':temp.read_merged_count,
	     		'write_merged_count':temp.write_merged_count, 
            		}]
	except:
		disk_io = [{
                        'read_count':0,
                        'write_count':0,
                        'read_bytes':0,
                        'write_bytes':0,
                        'read_time':0,
                        'write_time':0,
                        'busy_time':0,
                        'read_merged_count':0,
                        'write_merged_count':0,
                        }]


	# Active Users Details on Node
	temp = psutil.users()
	#print(temp)

	usersActive = [{
          	'name':temp[i].name,
          	'terminal':temp[i].terminal,
          	'host':temp[i].host,
          	'started':temp[i].started,
          	'pid':temp[i].pid,
         	}
          	for i in range(len(temp)) ]

	#print(usersActive)

	# Cpu Usage Total and Per Core
	total = []
	data = []
	with open ('/proc/stat','r') as myfile:  #Reading /proc/stat file
        	for line in myfile:                  #Iterating Upto intr   
                	if 'intr' in line:               #If found break
                        	break
                	row = line.split()               #split the column on the basis of spilt
                	data.append(row[:-3])            #ommitting last 3 unused columns
                	total.append(0)
	#Calculating total of all rows
	for i in range(len(data)):
        	for j in range(1,len(data[i])):
                	total[i] =  total[i] + float(data[i][j])

	for i in range(len(data)):                                    #interating row wise
        	for j in range(1,len(data[i])):                           #iterating column wise
                	data[i][j] = round(100 * (float(data[i][j])/total[i]),2) #updating percentage value calculated
                	#data[i][j] = 100 * (float(data[i][j])/total[i]) #updating percentage value calculated
                	#data[i][j] = float('{0:.1f}'.format(100 * (int(data[i][j])/total[i]))) #updating percentage value calculated

	cpuCore = {
        	'multi':
        	[
        	{
        	'name':data[index][0],
        	'series':
        	[
        	{'name':'user','value':data[index][1]},
        	#{'name':'nice','value':data[index][2]},
        	{'name':'system','value':data[index][3]},
        	{'name':'idle','value':data[index][4]},
        	#{'name':'iowait','value':data[index][5]},
        	#{'name':'irq','value':data[index][6]},
        	#{'name':'softirq','value':data[index][7]},
        	]
        	}
        	for index in range(1,len(data))
        	]}

	cpuTotal = {
                	data[0][0]:
                	[
                	{'name':'user','value':data[0][1]},
                	#{'name':'nice','value':data[0][2]},
                	{'name':'system','value':data[0][3]},
                	{'name':'idle','value':data[0][4]},
                	#{'name':'iowait','value':data[0][5]},
                	#{'name':'irq','value':data[0][6]},
                	#{'name':'softirq','value':data[0][7]},
                	]
        	}

	# Get Information of available GPUs
	gpus = GPUtil.getGPUs()
	gpuinfo = [{
           	'id':gpus[i].id,
            	'uuid':gpus[i].uuid,
            	'load':gpus[i].load,
            	'memoryUtil':gpus[i].memoryUtil,
            	'memoryTotal':gpus[i].memoryTotal,
            	'memoryUsed':gpus[i].memoryUsed,
            	'memoryFree':gpus[i].memoryFree,
            	'driver':gpus[i].driver,
            	'name':gpus[i].name,
            	'serial':gpus[i].serial,
            	'display_mode':gpus[i].display_mode,
            	'display_active':gpus[i].display_active,
           	}
           	for i in range(len(gpus))
           	]
       
 
	# Node Load Average
	temp = os.getloadavg()
	loadavg = [{'load1':temp[0],'load5':temp[1],'load15':temp[2]}]
	
	# CPU Percent
	percent = psutil.cpu_percent(interval=1)
	cpuPercent = {'percentage': percent}
	
	# Network IO Counters 
	temp = json.loads(json.dumps(psutil.net_io_counters(pernic=True)))
	net_io =[ 
        		{
				'name' : item,
                		'MByte_sent' : temp.get(item)[0]/(1024*1024),
                		'MByte_recv' :temp.get(item)[1]/(1024*1024),
                		'packets_sent' : temp.get(item)[2],
                		'packets_recv' : temp.get(item)[3],
                		'errin' : temp.get(item)[4],
                		'errout' : temp.get(item)[5],
                		'dropin' : temp.get(item)[6],   
                		'dropout' : temp.get(item)[7]
                	}
        		for item in temp.keys()
        	
		]
	
	# Service Status
	serviceStatus = []
	for i in range(len(services_to_check)):
       		 if not is_service_running(services_to_check[i]):
                	temp = {
				 'name' : services_to_check[i],
				 'value' : 'inactive'
				}                
                	serviceStatus.append(temp)
        	 else:
                	temp = {
                                 'name' : services_to_check[i],
                                 'value' : 'active'
                                }  
                	serviceStatus.append(temp)


	
	# Storing output file to Node Specific Directory
	myFile1 = open(storePath+'/running_proc.json','w')
	myFile2 = open(storePath+'/core_temp.json','w')
	myFile3 = open(storePath+'/cpu_stats.json','w')
	myFile4 = open(storePath+'/mem_details.json','w')
	myFile5 = open(storePath+'/swap_details.json','w')
	myFile6 = open(storePath+'/disk_io.json','w')
	myFile7 = open(storePath+'/net_io.json','w')
	myFile8 = open(storePath+'/active_users.json','w')
	myFile9 = open(storePath+'/cpu_core_util.json','w')
	myFile10 = open(storePath+'/cpu_total_util.json','w')
	myFile12 = open(storePath+'/cpu_loadavg.json','w')
	myFile13 = open(storePath+'/cpu_percent.json','w')
	myFile14 = open(storePath+'/services_status.json','w')
	job_file = open(storePath + '/job_details.json', 'w')
	
	
	myFile1.write(json.dumps(runProc))
	myFile2.write(json.dumps(coretemp))
	myFile3.write(json.dumps(cpuStat))
	json.dump(memory, myFile4) #changed
	myFile5.write(json.dumps(swap))
	myFile6.write(json.dumps(disk_io))
	myFile7.write(json.dumps(net_io))
	myFile8.write(json.dumps(usersActive))
	myFile9.write(json.dumps(cpuCore))
	myFile10.write(json.dumps(cpuTotal))
	myFile12.write(json.dumps(loadavg))
	json.dump(cpuPercent,myFile13) # changed
	myFile14.write(json.dumps(serviceStatus))
	json.dump(job_details, job_file)

	# End with writting Closing File
	myFile1.close()
	myFile2.close()
	myFile3.close()
	myFile4.close()
	myFile5.close()
	myFile6.close()
	myFile7.close()
	myFile8.close()
	myFile9.close()
	myFile10.close()
	myFile12.close()
	myFile13.close()
	myFile14.close()
	job_file.close()

	if gpus:
		myFile11 = open(storePath+'/gpu_info.json','w')
		myFile11.write(json.dumps(gpuinfo))
		myFile11.close()
		# myFile15 = open(storePath+ '/gpu_usage.json', 'w')
		# myFile15.write(json.dumps(gpu_utilization))
		# myFile15.close()
	Timer(7.0,execute).start()

execute()




