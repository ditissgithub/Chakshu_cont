#!/bin/bash

# montoolNodeService : Service to collect montool data and store it into specific directory
# Note : Need to be run on each node
# chkconfig: 345 99 01
RETVAL=0
HOSTNAME=`hostname`
start(){
	source /opt/ohpc/pub/apps/chakshu/py_env/bin/activate
	/opt/ohpc/pub/apps/chakshu/scripts/montoolNodeService.py &
	echo $!>/opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolNodeService.pid
	/opt/ohpc/pub/apps/chakshu/scripts/montoolHealthMonitor.py &
	echo $!>/opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolHealthMonitor.pid
}

stop(){
	kill `cat /opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolNodeService.pid` 
	rm /opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolNodeService.pid
	kill `cat /opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolHealthMonitor.pid` 
	rm /opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolHealthMonitor.pid	
}

case "$1" in
start)
	start
	;;
stop)
	stop
	;;
status)
        if [ -e /opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolNodeService.pid ]; then
                echo "montoolNodeService is Running, pid=`cat /opt/ohpc/pub/apps/chakshu/data/$HOSTNAME/montoolNodeService.pid`"
        else
                echo "montoolNodeService is Not Running"
                exit 1
        fi
        ;;


reload)
	stop
	start
	;;
restart)
	stop
	start
	;;
*)
	echo "Usage: $0 [start|stop|status|reload|restart]"
	exit 1
esac

