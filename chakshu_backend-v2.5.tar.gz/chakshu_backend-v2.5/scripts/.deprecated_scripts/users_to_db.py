#!/home/apps/chakshu/venv_chakshu/bin/python

## Set the required environment variables befor running this script.
## Make sure the script is executable.
## Copy this script to cron.{hourly/weekly/daily} directory for upading on regular basis.

import subprocess
import mysql.connector
import logging
import os
import imp

chakshu_conf = None
filepath = '/home/apps/chakshu/.secret/chakshu_admin_conf.py'
with open(filepath, 'rb') as fp:
    chakshu_conf = imp.load_module('chakshu_conf', fp, filepath, \
    ('.py', 'rb', imp.PY_SOURCE))


# Confguring logging 
logging.basicConfig(filename=chakshu_conf.CHAKSHU_HOME+'logs/users_count.log', format='%(asctime)s : %(levelname)s - %(message)s')
logger=logging.getLogger()
logger.setLevel(logging.DEBUG)

db_connection = None
db_cursor = None
users = None


def runStringCommand(command):
    try:
        data = subprocess.check_output(command,  stderr=subprocess.STDOUT, shell=True )
        return data.decode('utf-8')
    except subprocess.CalledProcessError as e:
        logger.error(e)
        return e.returncode

def getUsersList():
    users = []
    # Reading UID limits from /etc/login.defs
    uid_min = runStringCommand("cat /etc/login.defs | grep -w UID_MIN | awk '{print$2}'")
    uid_max = runStringCommand("cat /etc/login.defs | grep -w UID_MAX | awk '{print$2}'")
    command = "getent passwd | awk -F ':' -v 'min=1000' -v 'max="+uid_max+"' '{if ($3 > min && $3 <=max ) print $0}' | cut -d ':' -f 1,3 --output-delimiter='=='  | awk '!x[$0]++'"
    out = runStringCommand(command)
    lines = out.split('\n')
    for l in lines:
        if not l:
            continue
        uname,uid = l.split('==')
        user = {}
        user['userid'] = uid.strip()
        user['username'] = uname.strip()
        users.append(user)
    return sorted(users, key=lambda i: i['userid'])

try:
    users = getUsersList()
    # Connecting to configured database.
    logger.info("-----------------------------------------------------------")
    db_connection = mysql.connector.connect(
        host=chakshu_conf.DB_SERVER,
        user=chakshu_conf.__DB_USERNAME,
        passwd=chakshu_conf.__DB_PASSWORD,
        database=chakshu_conf.SCHEDULER_DB_NAME
    )
    logger.info("Connected. "+ str(db_connection))
    db_cursor = db_connection.cursor()

    # Insert or Update the new records. 
    for user in users:
        uid = user['userid']
        uname = user['username']
        query = "INSERT INTO userid_username VALUES(%s, %s) ON DUPLICATE KEY UPDATE username=VALUES(username)"
        params = (uid, uname)
        db_cursor.execute(query, params)
    db_connection.commit()
    db_cursor.execute('SELECT userid  FROM userid_username')
    db_cursor.fetchall()
    logger.info("Users updated!")
    logger.info("TotalUsers="+str(db_cursor.rowcount))
except mysql.connector.Error as e:
    logger.error(e)
    logger.warning("Changes rolled back.")

finally:
    db_cursor.close()
    db_connection.close()
    logger.info("Database connection closed!")






