#!/home/apps/chakshu/venv_chakshu/bin/python

from pymongo import DESCENDING
from datetime import datetime, timedelta
from timeloop import Timeloop
from threading import Timer
import logging
from logging.handlers import TimedRotatingFileHandler


from utilities import *


LOGPATH = os.environ['CHAKSHU_LOGPATH']

if not os.path.exists(LOGPATH):
    os.makedirs(LOGPATH)

# Confguring logging 
logFormatter = logging.Formatter('%(asctime)s : %(levelname)s - %(message)s')
logHandler = TimedRotatingFileHandler(filename= LOGPATH + 'general_data.log', when="midnight")
logHandler.setFormatter(logFormatter)
# Create logger and attach handlers
logger=logging.getLogger()
logger.setLevel(logging.DEBUG)
logger.addHandler(logHandler)


# Create Timeloop for executing tasks at different time intervals.
tl = Timeloop()


# Conecting to database.
client, db = mongo_connection(logger)


# Return all the slave nodes with IPs
def getent_hosts():
    nodelist = []
    delim = "=="
    command = os.environ['HOSTS_CMD']
    output = runStringCommand(command)
    for line in output.split('\n'):
        if not line:
            continue
        ip, node = line.split('==')
        ip_nums = ip.split('.')
        orig_net_id = str(ip_nums[0]) + '.' + str(ip_nums[1]) + '.' + str(ip_nums[2])
        hostname = node.strip()
        ipmi_ip = None
        if 'cn' in hostname:
            ipmi_ip = ip.strip().replace(chakshu_conf.CN_NETID, chakshu_conf.CN_IPMI_NETID) 
        elif 'gpu' in hostname:
            ipmi_ip = ip.strip().replace(chakshu_conf.GPU_NETID, chakshu_conf.GPU_IPMI_NETID)
        elif 'hm' in hostname:
            ipmi_ip = ip.strip().replace(chakshu_conf.HM_NETID, chakshu_conf.HM_IPMI_NETID)

        node = {"hostname": hostname, "ip": ip.strip(), "ipmi_ip":ipmi_ip}
        nodelist.append(node)
    return sorted(nodelist, key=lambda i: i['hostname'])


def get_allnodes_states():
    """
    Return all the nodes with their resource states.
    """
    nodelist = []
    cmd = os.environ['SLURM_NODES'] 
    output = runStringCommand(cmd)
    for line in output.split('\n'):
        if line:
            node,state = line.split(' ')
            nodelist.append({ "node":node, "state":state })
    return sorted(nodelist, key=lambda i: i['node'])


def get_up_nodes_only():
    """
    Return the nodes which are in the states other than ['down', 'drain', 'maint', 'resv', 'drng']
    """
    up_nodes = []
    down_nodes = []
    unwanted_states = ['down', 'drain', 'maint', 'resv', 'drng']
    allnodes = get_allnodes_states()
    for node in allnodes:
        if any(s in node['state'] for s in unwanted_states):
            down_nodes.append(node)
        else:
            up_nodes.append(node)
    return(up_nodes)



# IPMI credentials
_username_ = chakshu_conf.__IPMI_USERNAME
_password_ = chakshu_conf.__IPMI_PASSWORD
def get_power_status(node):
    """
    Check power status using ipmitool
    """
    kill = lambda process: process.kill()
    command = ['ipmitool', '-I','lanplus','-H', node['ipmi_ip'], '-U', _username_ ,'-P', _password_, 'chassis', 'power', 'status']
    ipmi = subprocess.Popen(
         command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    my_timer = Timer(1, kill, [ipmi])
    power_status = 'Down'
    try:
        my_timer.start()
        stdout, stderr = ipmi.communicate()
        stdout = stdout.decode('utf-8')
        if stdout:
            if 'on' in stdout:
                power_status = 'Up'
            else:
                power_status= 'Down'
            return power_status
        else:
            return power_status
    finally:
        my_timer.cancel()


def get_exit_air_temp(node):
    kill = lambda process: process.kill()
    command_list = ["ipmitool", "-I", "lanplus", "-H", node['ipmi_ip'], "-U",  _username_, "-P", _password_, "sdr", "type", "temperature"]
    ipmi = subprocess.Popen(
          command_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    power_status = 'Down'
    my_timer = Timer(2, kill, [ipmi])
    chassis_exit_air_temp = 0.0
    try:
        my_timer.start()
        stdout, stderr = ipmi.communicate()
        for l in stdout.decode('utf-8').split('\n'):
            if 'Exit Air' in l:
                l = l.split('|')
                chassis_exit_air_temp  =  float(l[-1].strip().split(' ')[0])
        return chassis_exit_air_temp
    finally:
        my_timer.cancel()


def starttime():
    return datetime.now() - timedelta(minutes=5)


def get_cpu_percent(nodename):
    """
    Retrive nodename's cpu_percent
    """
    cpu_percent = 0.0
    result = db.cpu_info.find( {'node':nodename, 'timestamp':{ '$gt':starttime()}}, limit=1).sort('timestamp', DESCENDING)[0]
    if result:
        cpu_percent = result['cpu_percent']
    return cpu_percent


def get_memory_percent(nodename):
    """
    Retrive nodename's memory_percent
    """
    mem_percent = 0.0
    result = db.memory_info.find({'node':nodename})[0]
    if result:    
        mem_percent = result['main_memory']['percent']
    return mem_percent



def get_loads(nodename):
    """
    Retrive nodename's loadavg
    """
    loads = None
    result = db.load_info.find({'node':nodename})[0]
    if result:
        loads = result['loadavg']
    return loads


def get_temperature(nodename):
    """
    Retrive nodename's core temperatures
    """
    avg_temp = 0.0
    result = db.temperature_info.find({'node':nodename, 'timestamp':{ '$gt':starttime()}}, limit=1).sort('timestamp', DESCENDING)[0]
    if result:
        avg_temp = result['avg_temperature']
    return avg_temp


 
@tl.job(interval=timedelta(seconds=30))
def nodes_info():
    """
    Nodes information to collection: nodes, upsert, 30s
    """
    modified_cnt = 0
    inserted = []
    hosts = getent_hosts()
    nodestates = get_allnodes_states()
    for i,node in enumerate(hosts):
        nodeinfo = node
        state = None
        try:
            state = nodestates[i]['state']
        except Exception as e:
            logger.error(e)
            state = "down"
        # get power status 
        power_status = get_power_status(node)
        result = db.nodes.update_one(nodeinfo, { 
            '$set':{ 
                "power_status":power_status, 
                'state':state, 
                'timestamp':datetime.now()
            } }, upsert=True)
        modified_cnt += result.modified_count
        if result.upserted_id:
            inserted.append(result.upserted_id)
        
    logger.info("nodes - Modified : "+ str(modified_cnt))
    logger.info("nodes - Inserted : " + str(len(inserted)) +" " + str(inserted))


# Insert aggregated general data to collection general_info
# Register job to timeloop
@tl.job(interval=timedelta(seconds=5))
def aggr_performance_info():
    """
    Aggregated performance metrics data to collection: general_info, insert, 5s
    """
    avg_cpu = 0.0
    avg_mem = 0.0
    avg_load1 = 0.0
    avg_load5 = 0.0
    avg_load15 = 0.0
    up_nodes = get_up_nodes_only()
    if not up_nodes:
        result = db.general_info.insert_one( { 'avg_cpu':0.0, 'avg_memory':0.0, 'avg_load':{ 'load1':0.0,  'load5':0.0, 'load15':0.0 }, 'timestamp':datetime.now() } )
        logger.info("db.general_info :" + str(result))
        return 0
    for host in up_nodes:
        try:
            avg_cpu += get_cpu_percent(host['node'])
            avg_mem += get_memory_percent(host['node'])
            loads = get_loads(host['node'])
            avg_load1 += loads['load1']
            avg_load5 += loads['load5']
            avg_load15 += loads['load15']
        except Exception as e:
            logger.error(str(e) + " (item=" +host['node']+")")
    load_avg = {
        'load1': round( avg_load1/len(up_nodes), 2 ),
        'load5': round( avg_load5/len(up_nodes), 2 ),
        'load15': round( avg_load15/len(up_nodes), 2 )
    }
    avg_cpu = round( avg_cpu/len(up_nodes), 2 )
    avg_mem = round( avg_mem/len(up_nodes), 2 )
    result = db.general_info.insert_one( { 'avg_cpu':avg_cpu, 'avg_memory':avg_mem, 'avg_load':load_avg, 'timestamp':datetime.now() } )
    logger.info("db.general_info :" + str(result))


# IPMI & health information to collection health_info
# @tl.job(interval=timedelta(minutes=5))
def system_health_info():
    modified_cnt = 0
    inserted = []
    for node in getent_hosts():
        power_status = get_power_status(node)
        exit_air_temp = get_exit_air_temp(node)
        healthinfo = { "hostname" : node['hostname'] }
        result = db.health_info.update_one(healthinfo, { 
            '$set':{ 
                "power_status":power_status, 
                'exit_air_temp':exit_air_temp, 
                'timestamp':datetime.now()
            } }, upsert=True)
        modified_cnt += result.modified_count
        if result.upserted_id:
            inserted.append(result.upserted_id)
        
    logger.info("health_info - Modified : "+ str(modified_cnt))
    logger.info("health_info - Inserted : " + str(len(inserted)) +" " + str(inserted))
            

# Initial upsert to database
aggr_performance_info()
nodes_info()



if __name__ == "__main__":
    """
    Will automatically shut down the jobs(worker threads) gracefully when the program is killed,
    so no need to call tl.stop() 
    """
    tl.start(block=True)