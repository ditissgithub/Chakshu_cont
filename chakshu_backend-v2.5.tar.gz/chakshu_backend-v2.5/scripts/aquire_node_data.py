#!/home/apps/chakshu/venv_chakshu/bin/python

import subprocess
import psutil
import GPUtil
from datetime import datetime, timedelta
from timeloop import Timeloop
import socket
import logging
from logging.handlers import TimedRotatingFileHandler


from utilities import *

LOGPATH = os.environ['CHAKSHU_LOGPATH']

if not os.path.exists(LOGPATH):
    os.makedirs(LOGPATH)

# Confguring logging
logFormatter = logging.Formatter('%(asctime)s : %(levelname)s - %(message)s')
logHandler = TimedRotatingFileHandler(
    filename=LOGPATH + 'data_aquisition.log', when="midnight")
logHandler.setFormatter(logFormatter)
# Create logger and attach handlers
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
logger.addHandler(logHandler)

# Create Timeloop for executing tasks at different time intervals.
tl = Timeloop()

# Get hostname
hostname = socket.gethostname()
if '.' in hostname:
    hostname = hostname.split('.')[0]


# Connect to database
client, db = mongo_connection(logger)

# Valid users from LDAP
users = [u['username']
         for u in db.users.find({}, {'_id': False, 'username': True})]


# Services status check
services_to_check = chakshu_conf.SERVICES


def is_service_running(name):
    with open(os.devnull, 'wb') as hide_output:
        exit_code = subprocess.Popen(
            ['service', name, 'status'], stdout=hide_output, stderr=hide_output).wait()
        return exit_code == 0


# Node Load Average
def get_load_average():
    temp = os.getloadavg()
    loadavg = {'load1': temp[0], 'load5': temp[1], 'load15': temp[2]}
    return loadavg


# Service Status
def get_service_status():
    serviceStatus = []
    for i in range(len(services_to_check)):
        if not is_service_running(services_to_check[i]):
            temp = {
                'name': services_to_check[i],
                'value': 'inactive'
            }
            serviceStatus.append(temp)
        else:
            temp = {
                'name': services_to_check[i],
                'value': 'active'
            }
            serviceStatus.append(temp)
    return serviceStatus



def load_info():
    """ 
    Load info to collection load_info, upsert, 5s 
    """
    load_info = db.load_info
    result = load_info.update_one(
        {"node": hostname},
        {"$set": {"timestamp": datetime.now(),"loadavg": get_load_average()}},
        upsert=True
    )
    return result
    # logger.info(hostname + " - db.load_info :" + str(result))


def services_info():
    """
    Service status info to collection services_info, upsert, 45s
    """
    services_info = db.services_info
    result = services_info.update_one(
        {"node": hostname},
        {"$set": {"timestamp": datetime.now(), "services": get_service_status()}},
        upsert=True
    )
    return result
    # logger.info(hostname + " - db.services_info :" + str(result))



def running_process_info():
    """ 
    Processes details of users to collection process_info, upsert, 5s 
    """
    runProc = []
    for proc in psutil.process_iter():
        pinfo = proc.as_dict(
            ['pid', 'username', 'name', 'memory_percent', 'cpu_percent', 'status', 'num_threads'])
        if pinfo.get('username') in users:
            if 'running' in pinfo.get('status'):
                runProc.append(pinfo)

    process_info = db.process_info
    result = process_info.update_one(
        {"node": hostname},
        {"$set": {"timestamp": datetime.now(),"procs": runProc}},
        upsert=True
    )
    return result
    # logger.info(hostname + " - db.process_info :" + str(result))



def job_utilizations():
    """ 
    Job utilization details to collecion job_utilizations, upsert, 45s 
    """
    top_procs = psutil.process_iter()
    job_details = {}
    cpupercent_avg = 0.0
    mempercent_avg = 0.0
    num_threads = 0
    num_procs = 0
    proc_names = []
    for proc in top_procs:
        proc = proc.as_dict(
            ['pid', 'username', 'name', 'memory_percent', 'cpu_percent', 'status', 'num_threads'])
        if proc['status'] == 'running' and proc['username'] in users:
            if proc['name'] not in proc_names:
                proc_names.append(proc['name'])
                num_threads += proc['num_threads']
                num_procs += 1
                mempercent_avg += round(proc['memory_percent'], 2)
                # cpupercent_avg += round(proc['cpu_percent'], 2)
    # psutil.virtual_memory().percent
    job_details['mempercent'] = mempercent_avg
    job_details['cpupercent'] = psutil.cpu_percent()
    job_details['num_threads'] = num_threads
    job_details['num_procs'] = num_procs
    job_details['procs'] = proc_names
    result = db.job_utilizations.update_one(
        {'node': hostname},
        {"$set": {'timestamp': datetime.now(),'job_details': job_details}},
        upsert=True
    )
    return result
    # logger.info(hostname + " - db.job_utilizations :" + str(result))


#  Main Memory details in GB
def get_main_memory():
    temp = psutil.virtual_memory()
    memory = {
        'total': temp.total / (1024*1024*1024),
        'available': temp.available / (1024*1024*1024),
        'percent': temp.percent,
        'used': temp.used / (1024*1024*1024),
        'free': temp.free / (1024*1024*1024)
    }
    return memory


# Swap Memory Details in MB
def get_swap_memory():
    swap = {}
    temp = psutil.swap_memory()
    swap = {
        'total': temp.total / (1024*1024),
        'used': temp.used / (1024*1024),
        'free': temp.free / (1024*1024),
        'percent': temp.percent / (1024*1024)
    }
    return swap


def memory_info():
    """ 
    Memory details to collection memory_info, upsert, 5s 
    """
    main_mem = get_main_memory()
    swap_mem = get_swap_memory()
    memory_info = db.memory_info
    result = memory_info.update_one(
        {"node": hostname},
        {"$set": {"timestamp": datetime.now(), "main_memory": main_mem,"swap_memory": swap_mem}},
        upsert=True
    )
    return result
    # logger.info(hostname + " - db.memory_info :" + str(result))


def disk_io_info():
    """ 
    Disk IO details to collection diskio_info, upsert, 15s 
    """
    temp = psutil.disk_io_counters()
    if temp is None:
        return None
    disk_io = {
        'read_count': temp.read_count,
        'write_count': temp.write_count,
        'read_bytes': temp.read_bytes,
        'write_bytes': temp.write_bytes,
        'read_time': temp.read_time,
        'write_time': temp.write_time,
        'busy_time': temp.busy_time,
        'read_merged_count': temp.read_merged_count,
        'write_merged_count': temp.write_merged_count,
    }
    diskio_info = db.diskio_info
    result = diskio_info.update_one(
        {"node": hostname},
        {"$set": {"timestamp": datetime.now(), "diskio": disk_io}},
        upsert=True
    )
    return result
    # logger.info(hostname + " - db.diskio_info :" + str(result))


# Cpu Statistics
def get_cpu_stats():
    temp = psutil.cpu_stats()

    cpuStat = {
        'ctx_switches': temp.ctx_switches,
        'interrupts': temp.interrupts,
        'soft_interrupts': temp.soft_interrupts,
        'syscalls': temp.syscalls,
    }
    return cpuStat


# total cpu utilzations
def get_total_cpu_utilizations():
    total_cpu_times = psutil.cpu_times_percent(interval=None)
    total_cpu_util = {
        "user": total_cpu_times.user,
        "system": total_cpu_times.system,
        "idle": total_cpu_times.idle
    }
    return total_cpu_util


# cpu per core utilizations
def get_core_utilizations():
    count = 0
    core_utilizations = []
    for proc in psutil.cpu_times_percent(interval=None, percpu=True):
        count += 1
        total = proc.user+proc.system+proc.idle+proc.guest_nice + \
            proc.guest+proc.steal+proc.softirq+proc.irq+proc.iowait+proc.nice
        temp = {
            'user': round(proc.user*100/total, 2),
            'system': round(proc.system*100/total, 2),
            'idle': round(proc.idle*100/total, 2),
            'core': 'cpu' + str(count)
        }
        core_utilizations.append(temp)
    return core_utilizations


# CPU Percent
def get_cpu_percent():
    percent = psutil.cpu_percent()
    return percent



def cpu_info():
    """ 
    cpu info to collections cpu_info, insert, 5s 
    """
    cpu_info = db.cpu_info
    result = cpu_info.insert_one({
        "node": hostname,
        "timestamp": datetime.now(),
        "cpu_percent": get_cpu_percent(),
        "core_utilizations": get_core_utilizations(),
        "total_cpu_util": get_total_cpu_utilizations(),
        "cpu_stats": get_cpu_stats()
    })
    return result
    # logger.info(hostname + " - db.cpu_info :" + str(result))


def network_io_info():
    """
    Network IO Counters to collection network_info, upsert, 15s
    """
    temp = psutil.net_io_counters(pernic=True)
    net_io = [{
        'name': item,
        'MByte_sent': temp.get(item)[0]/(1024*1024),
        'MByte_recv':temp.get(item)[1]/(1024*1024),
        'packets_sent': temp.get(item)[2],
        'packets_recv': temp.get(item)[3],
        'errin': temp.get(item)[4],
        'errout': temp.get(item)[5],
        'dropin': temp.get(item)[6],
        'dropout': temp.get(item)[7]
    }for item in temp.keys()]
    network_info = db.network_info
    result = network_info.update_one(
        {"node": hostname},
        {"$set": {"timestamp": datetime.now(), "netio": net_io}},
        upsert=True
    )
    return result
    # logger.info( hostname + " - db.network_info :" + str(result))



gpus = None
try:
    gpus = GPUtil.getGPUs()
except Exception as e:
    logger.error(e)

def gpu_info():
    """ 
    GPU Information to collection gpu_info, upsert, 5s
    """
    gpuinfo = [{
        'id': gpus[i].id,
        'uuid':gpus[i].uuid,
        'load':gpus[i].load,
        'memoryUtil':gpus[i].memoryUtil,
        'memoryTotal':gpus[i].memoryTotal,
        'memoryUsed':gpus[i].memoryUsed,
        'memoryFree':gpus[i].memoryFree,
        'driver':gpus[i].driver,
        'name':gpus[i].name,
        'serial':gpus[i].serial,
        'display_mode':gpus[i].display_mode,
        'display_active':gpus[i].display_active,
    }for i in range(len(gpus))]
    gpu_info = db.gpu_info
    result = gpu_info.update_one(
        {"node": hostname},
        {"$set": {"timestamp": datetime.now(),"gpuinfo": gpuinfo}},
        upsert=True
    )
    return result
    # logger.info( hostname + " - db.gpu_info :" + str(result))



def cpu_temperature_info():
    """ 
    CPU Temperature to collection temperature_info, insert, 5s 
    """
    data = psutil.sensors_temperatures(fahrenheit=False)['coretemp']
    temperatures = [{
        'label': data[i].label,
        'current':data[i].current,
        'high':data[i].high,
        'critical': data[i].critical
    } for i in range(len(data))]
    avg_temperature = 0.0
    id_cnt = 0
    for d in data:
        if 'Physical' in d[0]:
            id_cnt += 1
            avg_temperature += d[1]  # 'current' value

    result = db.temperature_info.insert_one({
        "node": hostname,
        "timestamp": datetime.now(),
        "coretemp": temperatures,
        "avg_temperature": round(avg_temperature/id_cnt, 2)
    })
    return result
    # logger.info( hostname + " - db.temperature_info :" + str(result))


@tl.job(interval=timedelta(seconds=5))
def performancejob():
    """ 
    Worker thread for collecting performance related metrics 
    after a defined interval. 
    """
    logger.info(cpu_info())
    logger.info(cpu_temperature_info())
    logger.info(load_info().raw_result)
    logger.info(memory_info().raw_result)
    logger.info(running_process_info().raw_result)
    if gpus is not None and 'gpu' in hostname:
        logger.info(gpu_info().raw_result)
    logger.info(hostname + " - <performancejob> db insert success.")
    # threading.Timer(5.0, performancejob).start()


@tl.job(interval=timedelta(seconds=15))
def io_utiljob():
    """ 
    Worker thread for collecting IO related metrics 
    after a defined interval. 
    """
    logger.info(network_io_info().raw_result)
    logger.info(disk_io_info().raw_result)
    logger.info(hostname + " - <io_utiljob> db upsert success.")


@tl.job(interval=timedelta(seconds=30))
def jobutilizationstask():
    """ 
    Worker thread for collecting job's aggregated utilization 
    after a defined interval. 
    """
    logger.info(job_utilizations().raw_result)
    logger.info(hostname + " - <jobutilizationstask> db insert success.")


@tl.job(interval=timedelta(seconds=45))
def servicestatusjob():
    """ 
    Worker thread for collecting defined services status 
    after a defined interval. 
    """
    logger.info(services_info().raw_result)
    logger.info(hostname + " - <servicestatusjob> db upsert success.")



if __name__ == "__main__":
    """
    Will automatically shut down the jobs(worker threads) gracefully when the program is killed,
    so no need to call tl.stop() 
    """
    tl.start(block=True)
