#!/home/apps/chakshu/venv_chakshu/bin/python
import imp
import logging
import os
import subprocess
import pymongo

chakshu_conf = None
filepath = os.environ['CHAKSHU_ROOT'] + '/.secret/chakshu_admin_conf.py'
with open(filepath, 'rb') as fp:
    chakshu_conf = imp.load_module('chakshu_conf', fp, filepath,
                                   ('.py', 'rb', imp.PY_SOURCE))


# Confguring logging
logging.basicConfig(filename='/var/log/chakshu/slurmreportsdata.log',
                    format='%(asctime)s : %(levelname)s - %(message)s')
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)


def runStringCommand(command):
    try:
        data = subprocess.check_output(
            command,  stderr=subprocess.STDOUT, shell=True)
        return data.decode('utf-8')
    except subprocess.CalledProcessError as e:
        logger.error(e)
        return e.returncode


client = None
db = None

try:
    client = pymongo.MongoClient(chakshu_conf.MONGO_CONN_URI)
    db = client[chakshu_conf.MONGO_DBNAME]
    logger.info("Connected. " + str(db))
except pymongo.errors.OperationFailure as e:
    logger.error(e)
