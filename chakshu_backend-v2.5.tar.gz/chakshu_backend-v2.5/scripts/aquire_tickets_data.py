#!/home/apps/chakshu/venv_chakshu/bin/python

## Set the required environment variables befor running this script.
## Make sure the script is executable.
## Copy this script to cron.{hourly/weekly/daily} directory for upading on regular basis.

import logging


from utilities import *


# Confguring logging 
logging.basicConfig(filename='/var/log/chakshu/tickets_data.log', format='%(asctime)s : %(levelname)s - %(message)s')
logger=logging.getLogger()
logger.setLevel(logging.DEBUG)



def get_ticket_event_count():
    db = ost_mysql_connection(logger)
    db_cursor = db.cursor()
    db_cursor.execute(
        '''
        SELECT H.name, DATE_FORMAT(timestamp, '%Y-%m-%d'), COUNT(DISTINCT E.id) 
        FROM ost_thread_event E LEFT JOIN ost_event H ON(E.event_id = H.id) 
        WHERE E.event_id IN(1,2,3,4,8) 
        GROUP BY E.event_id, DATE_FORMAT(E.timestamp, '%Y-%m-%d') 
        ORDER BY 2,1
        '''
    )
    event_counts = []
    dates = []
    for row in db_cursor.fetchall():
        event, date, count = row
        temp = {
            "date" : date,
            "created": 0,
            "reopened" : 0,
            "closed" : 0,
            "assigned": 0,
            "overdue": 0
        }
        if date not in dates:
            dates.append(date)
            temp[event] += count
            event_counts.append(temp)
            continue
        for ec in event_counts:
            if ec['date'] == date:
                ec[event] += count
    close_db_connection(db, cursor=db_cursor, logger=logger)
    return event_counts

# Ticket event counts by date to mongo collection ost_events
def ticket_events_to_mongo(event_counts):
    matched_cnt = 0
    inserted = []
    client, db = mongo_connection(logger)
    for e in event_counts:
        result =  db.ost_events.update_one( 
            {'date' : e['date'] }, 
            { '$set':{
            "created": e['created'],
            "reopened" : e['reopened'],
            "closed" : e['closed'],
            "assigned": e['assigned'],
            "overdue": e['overdue']
           }}, 
           upsert=True
        )
        matched_cnt += result.matched_count
        if result.upserted_id:
            inserted.append(result.upserted_id)

    logger.info("Matched : "+ str(matched_cnt))
    logger.info("Inserted : " + str(len(inserted)) +" " + str(inserted))
    close_db_connection(client, logger=logger)


ticket_events_to_mongo(get_ticket_event_count())



