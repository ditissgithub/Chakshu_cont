#!/bin/bash

## Make sure the script is executable.
## Add this script to crontab with suitable interval
## e.g.- 0 1 * * * /home/apps/chakshu/scripts/chakshu_daily_cron.sh > /dev/null 2>&1 (daily at 1am) 

# To insert/update ldap users data to chakshu mongodb
/home/apps/chakshu/scripts/get_users.py

# To insert tickets related data to chakshu mongodb
/home/apps/chakshu/scripts/aquire_tickets_data.py
