#!/bin/bash

## Make sure the script is executable.
## Add this script to crontab with suitable interval
## e.g. 0 * * * * /home/apps/chakshu/scripts/chakshu_hourly_cron.sh > /dev/null 2>&1 


# To restart chakshu services on slave nodes
/home/apps/chakshu/scripts/nodeutilities restart

