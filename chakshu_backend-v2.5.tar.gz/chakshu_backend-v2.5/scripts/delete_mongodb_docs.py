#!/home/apps/chakshu/venv_chakshu/bin/python

import argparse
from datetime import datetime, date
from dateutil.relativedelta import *

from utilities import mongo_connection, close_db_connection

def parse_args():
    parser = argparse.ArgumentParser(
        prog='delete_mongodb_docs.py', description='Deletes MongoDB documents older than specified number of months/days.')
    parser.add_argument(
        '-m', '--months', action = 'store', default=0, help = "Number of months", required=True)
    parser.add_argument(
        '-d', '--days', action = 'store', default=0, help = "Number of days")
    parser.add_argument(
        '-w', '--weeks', action = 'store', default=0, help = "Number of weeks")
    parser.add_argument(
        '-y', '--yes', dest='confirm', action='store_true', help="If passed this flag confirmation prompt won't be displayed and proceed to deletion.")


    return parser.parse_args()

args = parse_args()

# Conecting to database.
client, db =  mongo_connection()

today = datetime.today()
before_date = today + relativedelta(months=-int(args.months), weeks=-int(args.weeks), days=-int(args.days))

dbstats = db.command("dbstats")
print("Database : ", dbstats['db'])
print("Storage Size : ",round( dbstats['storageSize'] / (1024 ** 3), 2) , 'GB\n' )

def docs_to_delete():
    collectionstodel = ['cpu_info', 'job_utilizations', 'temperature_info'] # ['users','nodes','ost_events']
    collections = db.list_collection_names()
    for c in collections:
        if  any(uc in c for uc in collectionstodel):
            print(c," = " ,db[c].count_documents({"timestamp":{"$lt": before_date}}))

def delete_documents():
    response = {}
    response['deleted_count'] = 0
    response['collection_count'] = 0
    collections = ['cpu_info', 'job_utilizations', 'temperature_info'] # ['users','nodes','ost_events']
    collections = db.list_collection_names()
    for c in collections:
        if  any(uc in c for uc in collections):
            result = db[c].delete_many({"timestamp":{"$lt": before_date}})
            print(result.deleted_count, 'documents deleted from', c, '\t...OK')
            response['deleted_count'] += result.deleted_count
            response['collection_count'] += 1
    return response

def confirm():
    """
    Ask user to enter Y or N (case-insensitive).
    :return: True if the answer is Y.
    :rtype: bool
    """
    before_date_formatted = before_date.strftime('%d %b %Y')
    answer = ""
    while answer not in ["y", "n"]:
        if args.confirm:
            answer = "y"
            break
        answer = input("Are you sure you want to delete above documets older than '"+str(before_date_formatted)+"' [Y/N]? ").lower()
    return answer == "y"

docs_to_delete()

if confirm():
    result = delete_documents()
    print("[SUCCESS] Total "+str(result['deleted_count'])+" documents deleted from "+str(result['collection_count'])+" collections.")
else:
    print('[DECLINED] Not a single document deleted.')


# Close database connection
close_db_connection(client)