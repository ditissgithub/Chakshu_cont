#!/bin/bash

export CHAKSHU_ROOT=/home/apps/chakshu
export DJANGO_SETTINGS_MODULE=chakshu_api.settings
export CHAKSHU_LOGPATH=/var/log/chakshu/
export CLUSTER_NAME=sangam
export HOSTS_CMD="getent hosts | grep -e cn -e hm -e gpu | grep -v -e ib0 -e bmc | awk '{print\$1\"==\"\$2}'"
export SLURM_NODES="sinfo -N | grep -v -e standard -e NODELIST | awk -F' ' '{ print \$1,\$4 }'"


