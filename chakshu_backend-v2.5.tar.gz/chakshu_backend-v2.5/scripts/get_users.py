#!/home/apps/chakshu/venv_chakshu/bin/python

## Make sure the script is executable.
## Copy this script to cron.{hourly/weekly/daily} directory for upading on regular basis.

import logging
from datetime import datetime

from utilities import chakshu_conf, runStringCommand, mongo_connection, close_db_connection


# Confguring logging 
logging.basicConfig(filename='/var/log/chakshu/users.log', format='%(asctime)s : %(levelname)s - %(message)s')
logger=logging.getLogger()
logger.setLevel(logging.DEBUG)



# Collect users using /etc/passwd file
def getUsersList():
    users = []
    # Reading UID limits from /etc/login.defs
    uid_min = runStringCommand("cat /etc/login.defs | grep -w UID_MIN | awk '{print$2}'")
    uid_max = runStringCommand("cat /etc/login.defs | grep -w UID_MAX | awk '{print$2}'")
    command = "getent passwd | awk -F ':' -v 'min=1000' -v 'max="+uid_max+"' '{if ($3 > min && $3 <=max ) print $0}' | cut -d ':' -f 1,3,6 --output-delimiter=','  | awk '!x[$0]++'"
    out = runStringCommand(command)
    lines = out.split('\n')
    for l in lines:
        if not l:
            continue
        uname,uid,homedir = l.split(',')
        user = {}
        user['userid'] = int(uid.strip())
        user['username'] = uname.strip()
        user['home'] = homedir.strip()
        users.append(user)
    return sorted(users, key=lambda i: i['userid'])


# Collect users from LDAP entries
def get_ldap_users():
    all_users = []
    #all_dns = "ldapsearch -x -H ldap://login1 uid=* uid | grep -w 'uid:' | awk -F' ' '{print$2}' | wc -l"
    alluids = "ldapsearch -x -H "+ chakshu_conf.LDAP_SERVER +" uid=* uid | grep -w 'uid:' | awk -F' ' '{print$2}'"
    out = runStringCommand(alluids)
    uids = [ uid.strip() for uid in out.split('\n')]
    for uid in uids:
        if not uid:
            continue
        #uid = [d.strip() for d in user.split(',')][0].split('=')[1]
        single_user = "ldapsearch -x -H "+ chakshu_conf.LDAP_SERVER +" 'uid="+uid+"' -LLL | grep -w -e mail -e homeDirectory -e uidNumber"
        out = runStringCommand(single_user)
        # ldap unable to search for user
        if out == 1:
            continue
        userdetails = {'username':uid, 'mail':''}
        for l in out.split('\n'):
            details = [ d.strip() for d in l.split(':') ]
            if 'mail'in l:
                userdetails['mail'] = details[1]
            if 'homeDirectory' in l:
                userdetails['home'] = details[1]
            if 'uidNumber' in l:
                userdetails['userid'] = int(details[1])
        all_users.append(userdetails)
    return sorted(all_users, key=lambda i: i['userid'])


client, db = mongo_connection(logger)


matched_cnt = 0
inserted = []
allldapusers = get_ldap_users()
for user in allldapusers:
    result =  db.users.update_one(user, { '$set':{ "home":user['home']} }, upsert=True)
    matched_cnt += result.matched_count
    if result.upserted_id:
        inserted.append(result.upserted_id)

logger.info("Matched : "+ str(matched_cnt))
logger.info("Inserted : " + str(len(inserted)) +" " + str(inserted))
logger.info("Total users : " + str(db.users.count_documents({})))
close_db_connection(client, logger=logger)

