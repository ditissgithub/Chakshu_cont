#!/home/apps/chakshu/venv_chakshu/bin/python

from pymongo import ASCENDING
import logging

from utilities import mongo_connection, close_db_connection


# Confguring logging 
logging.basicConfig(filename= '/var/log/chakshu/indexing_mdb.log', format='%(asctime)s : %(levelname)s - %(message)s')
logger=logging.getLogger()
logger.setLevel(logging.DEBUG)

client, db = mongo_connection(logger)
collections = db.list_collection_names()

# To create index with keys  {node:1,timestamp:1}
def createindex_node_1_timestamp_1( collection ):
    try:
        resp = db[collection].create_index([('node', ASCENDING), ('timestamp', ASCENDING)])
        logger.info( "Index created/exists for "+collection+" : "+str(resp) )
    except Exception as e:
        logger.error(e)

# NO need for index for these collections so skip them
colstoindex = ['cpu_info', 'temperature_info', 'job_utilizations']
for c in collections:
    if c in colstoindex:
        createindex_node_1_timestamp_1(c)

close_db_connection(client, logger=logger)
