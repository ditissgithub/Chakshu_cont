-- To be run via 'root' user.
CREATE USER 'chakshu'@'localhost' IDENTIFIED BY 'chakshumanager';
CREATE USER 'chakshu'@'%' IDENTIFIED BY 'chakshumanager';

GRANT  ALL PRIVILEGES ON  slurm_acct_db.* TO 'chakshu'@'localhost';
GRANT  ALL PRIVILEGES ON  slurm_acct_db.* TO 'chakshu'@'%';

FLUSH PRIVILEGES;

-- Tickets event count as per date (osTicket v1.14.2)
-- SELECT H.name, DATE_FORMAT(timestamp, '%Y-%m-%d'), COUNT(DISTINCT E.id) FROM ost_thread_event E LEFT JOIN ost_event H ON(E.event_id = H.id) WHERE E.event_id IN(1,2,3,4,8) GROUP BY E.event_id, DATE_FORMAT(E.timestamp, '%Y-%m-%d') ORDER BY 2,1;


-- To be run via 'chakshu' user .

-- USE slurm_acct_db;
-- CREATE TABLE userid_username(userid char(10) PRIMARY KEY, username VARCHAR(150));

