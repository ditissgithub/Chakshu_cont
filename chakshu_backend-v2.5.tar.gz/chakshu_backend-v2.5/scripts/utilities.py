#!/home/apps/chakshu/venv_chakshu/bin/python

import mysql.connector
import subprocess
import imp
import pymongo
import os

chakshu_conf = None
filepath = '/home/apps/chakshu/.secret/chakshu_admin_conf.py'
with open(filepath, 'rb') as fp:
    chakshu_conf = imp.load_module('chakshu_conf', fp, filepath, \
    ('.py', 'rb', imp.PY_SOURCE))


# Utility method for executing string command on linux.
def runStringCommand(command):
    try:
        data = subprocess.check_output(command,  stderr=subprocess.STDOUT, shell=True )
        return data.decode('utf-8')
    except subprocess.CalledProcessError as e:
        return e.returncode


# Conecting to mongodb database.
# Call as : client, db =  mongo_connection(logger)
collections = None
def mongo_connection(logger=None):
    client = None
    db = None
    try:
        client = pymongo.MongoClient(chakshu_conf.MONGO_CONN_URI)
        db = client[chakshu_conf.MONGO_DBNAME]
        mongo_collections = db.list_collection_names()
        if logger is not None:
            logger.info("Connected to chakshu mongodb "+ str(db))
        return client, db   
    except pymongo.errors.OperationFailure as e:
        if logger is not None:
            logger.error(e)
        


# Conecting to ost mysql database.
def ost_mysql_connection(logger=None):
    db = None
    try:
        db = mysql.connector.connect(
            host=chakshu_conf.OST_DB_SERVER,
            user=chakshu_conf.OST_DB_USER,
            passwd=chakshu_conf.OST_DB_PASSWORD,
            database=chakshu_conf.OST_DB_NAME
        )
        if logger is not None:
            logger.info("Connected to ost database "+ str(db))
        return db
    except mysql.connector.Error as e:
        if logger is not None:
            logger.error(e)


# For mongodb cursor will be None and connection -> client
def close_db_connection(connection, cursor=None, logger=None):
    connection.close()
    if cursor is not None:
        cursor.close()
    if logger is not None:
        logger.info('Database connection closed.')
    
